<?php
// Front controller - roteador simples (em português)
// Inicia sessão para autenticação por sessão
session_start();

require_once __DIR__ . '/../src/modelo/DAO/Configuracao.php';
require_once __DIR__ . '/../src/modelo/DAO/BancoDeDados.php';
require_once __DIR__ . '/../src/ajudantes/Resposta.php';

// Autoload simplificado
spl_autoload_register(function($classe){
    $caminhos = [
        __DIR__ . '/../src/modelo/' . $classe . '.php',
        __DIR__ . '/../src/controle/' . $classe . '.php',
        __DIR__ . '/../src/' . $classe . '.php',
    ];
    foreach ($caminhos as $p) if (file_exists($p)) { require_once $p; return; }
});

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$metodo = $_SERVER['REQUEST_METHOD'];
$basePath = '/';
$path = substr($uri, strlen($basePath));
$segmentos = array_values(array_filter(explode('/', $path)));

header('Content-Type: application/json; charset=utf-8');

try {
    // Endpoints em português
    if ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'registrar') {
        $c = new ControladorAutenticacao(); $c->registrar();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'entrar') {
        $c = new ControladorAutenticacao(); $c->entrar();
    } elseif ($metodo === 'GET' && isset($segmentos[0]) && $segmentos[0] === 'perfil') {
        $c = new ControladorPerfil(); $c->verPerfil();
    } elseif ($metodo === 'PUT' && isset($segmentos[0]) && $segmentos[0] === 'perfil') {
        $c = new ControladorPerfil(); $c->atualizarPerfil();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'alimentos') {
        $c = new ControladorAlimento(); $c->criar();
    } elseif ($metodo === 'GET' && isset($segmentos[0]) && $segmentos[0] === 'alimentos') {
        $c = new ControladorAlimento(); $c->listar();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'refeicoes') {
        $c = new ControladorRefeicao(); $c->criar();
    } elseif ($metodo === 'GET' && isset($segmentos[0]) && $segmentos[0] === 'refeicoes') {
        $c = new ControladorRefeicao(); $c->listar();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'objetivos') {
        $c = new ControladorObjetivo(); $c->criar();
    } elseif ($metodo === 'GET' && isset($segmentos[0]) && $segmentos[0] === 'conquistas') {
        $c = new ControladorConquista(); $c->listar();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'sincronizar' && isset($segmentos[1]) && $segmentos[1] === 'dispositivo') {
        $c = new ControladorDispositivo(); $c->sincronizar();
    } elseif ($metodo === 'POST' && isset($segmentos[0]) && $segmentos[0] === 'notificacoes') {
        $c = new ControladorNotificacao(); $c->enviar();
    } elseif ($metodo === 'GET' && isset($segmentos[0]) && $segmentos[0] === 'notificacoes') {
        $c = new ControladorNotificacao(); $c->listar();
    } else {
        http_response_code(404);
        echo json_encode(['erro' => 'Endpoint não encontrado']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['erro' => $e->getMessage()]);
}
?>