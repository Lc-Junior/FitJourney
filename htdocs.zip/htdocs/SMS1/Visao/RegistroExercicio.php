<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['email'])) {
    header('Location: Login.php');
    exit();
}

include_once('../Modelo/DAO/conexao.php');

$email = $_SESSION['email'];
$sqlUser = "SELECT id FROM usuario WHERE email = '$email'";
$resultUser = $conexao->query($sqlUser);
if ($resultUser->num_rows < 1) {
    echo "Usuário não encontrado.";
    exit();
}
$user = $resultUser->fetch_assoc();
$userId = $user['id'];

if (isset($_POST['submit'])) {
    $tipo = $_POST['tipo'];
    $duracao = intval($_POST['duracao']);
    $data_hora = $_POST['data_hora'];

    // Updated calorie burn calculation based on new MET values and formula
    $met_values = [
        'Corrida' => 8.3,
        'Musculação' => 6.0,
        'Caminhada' => 3.5,
        'Outro' => 4.0
    ];

    $met = $met_values[$tipo] ?? 4.0;

    // Fetch user weight from perfil table
    $peso = 70; // default weight
    $sqlPerfil = "SELECT peso FROM perfil WHERE usuarioperfil_id = $userId LIMIT 1";
    $resultPerfil = $conexao->query($sqlPerfil);
    if ($resultPerfil && $resultPerfil->num_rows > 0) {
        $perfilData = $resultPerfil->fetch_assoc();
        if (!empty($perfilData['peso'])) {
            $peso = floatval($perfilData['peso']);
        }
    }

    // Calculate calories burned using the formula: (MET * weight * duration) / 60
    $calorias_gastas = intval(($met * $peso * $duracao) / 60);

    $sqlInsert = "INSERT INTO exercicio (tipo, duracao, calorias_gastas, data_hora, usuarioexercicio_id) 
                  VALUES ('$tipo', $duracao, $calorias_gastas, '$data_hora', $userId)";

    if ($conexao->query($sqlInsert) === TRUE) {
        $msg = "Exercício registrado com sucesso! Calorias gastas: $calorias_gastas.";
    } else {
        $msg = "Erro ao registrar exercício: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Registro de Exercício</title>
    <link rel="stylesheet" href="assets/css/styleCadastro.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="box">
        <h2>Registrar Exercício</h2>
        <?php if (isset($msg)) echo "<p>$msg</p>"; ?>
        <form method="POST" action="RegistroExercicio.php">
            <label for="tipo">Tipo de Exercício:</label>
            <select id="tipo" name="tipo" required>
                <option value="Corrida">Corrida</option>
                <option value="Musculação">Musculação</option>
                <option value="Caminhada">Caminhada</option>
                <option value="Outro">Outro</option>
            </select><br><br>

            <label for="duracao">Duração (minutos):</label>
            <input type="number" id="duracao" name="duracao" min="1" required><br><br>

            <label for="data_hora">Data e Hora:</label>
            <input type="datetime-local" id="data_hora" name="data_hora" required><br><br>

            <input type="submit" name="submit" value="Registrar">
        </form>
    </div>
    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="PaginaInicial.php" class="btn btn-primary">Voltar</a>
    </div>
</body>
</html>
