<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['email'])) {
    header('Location: Login.php');
    exit();
}

include_once('../Modelo/DAO/conexao.php');

// Nutritionix API credentials
define('NUTRITIONIX_APP_ID', '984f7f09');
define('NUTRITIONIX_APP_KEY', '83fc632482633d379264f1cabf563c9d');

function getCaloriesFromNutritionix($query) {
    $url = 'https://trackapi.nutritionix.com/v2/natural/nutrients';
    $data = json_encode(['query' => $query]);

    $headers = [
        'Content-Type: application/json',
        'x-app-id: ' . NUTRITIONIX_APP_ID,
        'x-app-key: ' . NUTRITIONIX_APP_KEY,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        curl_close($ch);
        return 0;
    }
    curl_close($ch);

    $result = json_decode($response, true);
    if (isset($result['foods'][0]['nf_calories'])) {
        return (int)round($result['foods'][0]['nf_calories']);
    }
    return 0;
}

// Get user id from email
$email = $_SESSION['email'];
$sqlUser = "SELECT id FROM usuario WHERE email = '$email'";
$resultUser = $conexao->query($sqlUser);
if ($resultUser->num_rows < 1) {
    echo "Usuário não encontrado.";
    exit();
}
$user = $resultUser->fetch_assoc();
$userId = $user['id'];

if (isset($_POST['submit'])) {
    $data_hora = $_POST['data_hora'];
    // Convert datetime-local format "YYYY-MM-DDTHH:MM" to "YYYY-MM-DD HH:MM:SS"
    $data_hora = str_replace('T', ' ', $data_hora) . ':00';

    $cafe = $_POST['cafe_foods'] ?? [];
    $cafe_quantidade = $_POST['cafe_quantities'] ?? [];
    $almoco = $_POST['almoco_foods'] ?? [];
    $almoco_quantidade = $_POST['almoco_quantities'] ?? [];
    $lanche = $_POST['lanche_foods'] ?? [];
    $lanche_quantidade = $_POST['lanche_quantities'] ?? [];
    $janta = $_POST['janta_foods'] ?? [];
    $janta_quantidade = $_POST['janta_quantities'] ?? [];

    // Helper function to calculate calories for multiple foods with individual quantities
    function getCaloriesForMultipleFoodsWithQuantities($foods, $quantities) {
        $totalCalories = 0;
        for ($i = 0; $i < count($foods); $i++) {
            $food = trim($foods[$i]);
            $quantity = isset($quantities[$i]) ? (int)$quantities[$i] : 0;
            if ($food !== '' && $quantity > 0) {
                $totalCalories += getCaloriesFromNutritionix($quantity . 'g ' . $food);
            }
        }
        return $totalCalories;
    }

    // Get calories from API for multiple foods with quantities
    $cafe_calorias = getCaloriesForMultipleFoodsWithQuantities($cafe, $cafe_quantidade);
    $almoco_calorias = getCaloriesForMultipleFoodsWithQuantities($almoco, $almoco_quantidade);
    $lanche_calorias = getCaloriesForMultipleFoodsWithQuantities($lanche, $lanche_quantidade);
    $janta_calorias = getCaloriesForMultipleFoodsWithQuantities($janta, $janta_quantidade);

    // Sum total calories
    $calorias = $cafe_calorias + $almoco_calorias + $lanche_calorias + $janta_calorias;

    // Convert arrays to comma-separated strings for database storage
    $cafe_str = is_array($cafe) ? implode(', ', $cafe) : $cafe;
    $almoco_str = is_array($almoco) ? implode(', ', $almoco) : $almoco;
    $lanche_str = is_array($lanche) ? implode(', ', $lanche) : $lanche;
    $janta_str = is_array($janta) ? implode(', ', $janta) : $janta;

    $sqlInsert = "INSERT INTO alimentacao (usuariorefeicao_id, data_hora, cafe, almoco, lanche, janta, calorias, agua) 
                  VALUES ($userId, '$data_hora', '$cafe_str', '$almoco_str', '$lanche_str', '$janta_str', $calorias, 0)";

    if ($conexao->query($sqlInsert) === TRUE) {
        $msg = "Refeição registrada com sucesso! Calorias totais: $calorias";
    } else {
        $msg = "Erro ao registrar refeição: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Registro de Refeição</title>
    <link rel="stylesheet" href="assets/css/styleCadastro.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="box">
        <h2>Registrar Refeição</h2>
        <?php if (isset($msg)) echo "<p>$msg</p>"; ?>
        <form method="POST" action="RegistroRefeicao.php" id="mealForm">
            <label for="data_hora">Data e Hora:</label>
            <input type="datetime-local" id="data_hora" name="data_hora" required><br><br>

            <label>Café da Manhã:</label>
            <div id="cafeContainer">
                <div class="food-quantity-pair">
                    <input type="text" name="cafe_foods[]" placeholder="Comida">
                    <input type="number" name="cafe_quantities[]" min="0" value="0" placeholder="Quantidade (g)">
                    <button type="button" onclick="removeFoodQuantityPair(this)">Remover</button>
                </div>
            </div>
            <button type="button" onclick="addFoodQuantityPair('cafeContainer', 'cafe_foods[]', 'cafe_quantities[]')">Adicionar Comida</button>
            <br><br>

            <label>Almoço:</label>
            <div id="almocoContainer">
                <div class="food-quantity-pair">
                    <input type="text" name="almoco_foods[]" placeholder="Comida">
                    <input type="number" name="almoco_quantities[]" min="0" value="0" placeholder="Quantidade (g)">
                    <button type="button" onclick="removeFoodQuantityPair(this)">Remover</button>
                </div>
            </div>
            <button type="button" onclick="addFoodQuantityPair('almocoContainer', 'almoco_foods[]', 'almoco_quantities[]')">Adicionar Comida</button>
            <br><br>

            <label>Lanche:</label>
            <div id="lancheContainer">
                <div class="food-quantity-pair">
                    <input type="text" name="lanche_foods[]" placeholder="Comida">
                    <input type="number" name="lanche_quantities[]" min="0" value="0" placeholder="Quantidade (g)">
                    <button type="button" onclick="removeFoodQuantityPair(this)">Remover</button>
                </div>
            </div>
            <button type="button" onclick="addFoodQuantityPair('lancheContainer', 'lanche_foods[]', 'lanche_quantities[]')">Adicionar Comida</button>
            <br><br>

            <label>Janta:</label>
            <div id="jantaContainer">
                <div class="food-quantity-pair">
                    <input type="text" name="janta_foods[]" placeholder="Comida">
                    <input type="number" name="janta_quantities[]" min="0" value="0" placeholder="Quantidade (g)">
                    <button type="button" onclick="removeFoodQuantityPair(this)">Remover</button>
                </div>
            </div>
            <button type="button" onclick="addFoodQuantityPair('jantaContainer', 'janta_foods[]', 'janta_quantities[]')">Adicionar Comida</button>
            <br><br>

            <input type="submit" name="submit" value="Registrar">
        </form>
    </div>
    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="PaginaInicial.php" class="btn btn-primary">Voltar</a>
        <a href="Dashboard.php" class="btn btn-primary">Dashboard</a>
    </div>
<script>
    function addFoodQuantityPair(containerId, foodName, quantityName) {
        const container = document.getElementById(containerId);
        const div = document.createElement('div');
        div.className = 'food-quantity-pair';
        div.innerHTML = `
            <input type="text" name="${foodName}" placeholder="Comida">
            <input type="number" name="${quantityName}" min="0" value="0" placeholder="Quantidade (g)">
            <button type="button" onclick="removeFoodQuantityPair(this)">Remover</button>
        `;
        container.appendChild(div);
    }

    function removeFoodQuantityPair(button) {
        const div = button.parentNode;
        div.parentNode.removeChild(div);
    }
</script>
</body>
</html>
