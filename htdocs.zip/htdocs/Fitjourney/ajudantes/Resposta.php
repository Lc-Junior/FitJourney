<?php
class Resposta {
    public static function json($dados, $codigo = 200){
        http_response_code($codigo);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($dados);
        exit;
    }
    public static function erro($mensagem, $codigo = 400){
        self::json(['erro' => $mensagem], $codigo);
    }
}
