<?php
session_start();
require_once __DIR__ . '/../modelo/DAO/Configuracao.php';
require_once __DIR__ . '/../modelo/DAO/BancoDeDados.php';
require_once __DIR__ . '/../ajudantes/Resposta.php';
require_once __DIR__ . '/../ajudantes/Validador.php';
spl_autoload_register(function($classe){
    $paths = [
        __DIR__ . '/../Fitjourney/modelo/' . $classe . '.php',
        __DIR__ . '/../Fitjourney/controle/' . $classe . '.php',
    ];
    foreach ($paths as $p) if (file_exists($p)) { require_once $p; return; }
});

$metodo = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$segments = array_values(array_filter(explode('/', $uri)));

header('Content-Type: application/json; charset=utf-8');

if($metodo === 'POST' && isset($segments[2]) && $segments[2] === 'registrar'){
    $c = new ControladorAutenticacao(); $c->registrarEndpoint();
} elseif($metodo === 'POST' && isset($segments[2]) && $segments[2] === 'entrar'){
    $c = new ControladorAutenticacao(); $c->entrarEndpoint();
} else {
    http_response_code(404);
    echo json_encode(['erro'=>'Endpoint API não encontrado']);
}
?>