<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FitJourney</title>
<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<header class="cabecalho">
  <div class="container">
    <h1>FitJourney</h1>
    <nav>
      <?php if(!empty($_SESSION['id_usuario'])): ?>
        <a href="index.php?pagina=dashboard">Painel</a>
        <a href="index.php?pagina=perfil">Perfil</a>
        <a href="index.php?pagina=refeicoes">Refeições</a>
        <a href="index.php?pagina=objetivos">Objetivos</a>
        <a href="index.php?pagina=conquistas">Conquistas</a>
        <a href="index.php?pagina=sair" style="color:#e74c3c">Sair</a>
      <?php else: ?>
        <a href="../visao/login.php">Entrar</a>
        <a href="../visao/formcadastro.php">Cadastrar</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="container">