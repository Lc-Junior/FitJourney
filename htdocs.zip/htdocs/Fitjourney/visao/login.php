<div class="card">
<h2>Entrar</h2>
<?php if(!empty($_SESSION['mensagem_feed'])){ $m = json_decode($_SESSION['mensagem_feed'], true); if(isset($m['erro'])) echo '<small class="msg">'.$m['erro'].'</small>'; unset($_SESSION['mensagem_feed']); } ?>
<form method="post" action="LoginTeste.php">
  <input type="hidden" name="acao" value="entrar">
  <div class="form-group"><label>E-mail</label><input type="email" name="email" required></div>
  <div class="form-group"><label>Senha</label><input type="password" name="senha" required></div>
  <button type="submit">Entrar</button>
</form>
<p>Não tem conta? <a href="index.php?pagina=cadastro">Cadastre-se</a></p>
</div>