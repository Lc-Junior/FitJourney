<?php
if(empty($_SESSION['id_usuario'])){ header('Location: index.php?pagina=login'); exit; }
$alimentoModel = new Alimento();
$listaAlimentos = $alimentoModel->listar();
?>
<div class="card">
<h2>Refeições</h2>
<p>Para registrar refeições completas use API (cliente ou Postman). Lista de refeições:</p>
<?php
    $r = new Refeicao();
    $lista = $r->listarPorUsuario($_SESSION['id_usuario']);
    if(empty($lista)) echo '<p>Nenhuma refeição.</p>';
    else {
      foreach($lista as $it){ echo '<div class="card"><strong>'.htmlspecialchars($it['tipo']).'</strong> - '.htmlspecialchars($it['data_refeicao']).' - Cal: '.htmlspecialchars($it['total_calorias']).'</div>'; }
    }
?>
</div>