<?php


require_once '../controle/ControladorPerfil.php';
require_once '../modelo/Perfil.php';


$perfilModel = new Perfil();
//$medidaModel = new Medida();
$perfil = $perfilModel->obterPorUsuario(['1']);
$medidas = $medidaModel->listarPorUsuario(['1']);
?>
<div class="card">
<h2>Perfil</h2>

<form method="post" action="index.php">
  <input type="hidden" name="acao" value="atualizar_perfil">
  <div class="form-group"><label>Idade</label><input type="text" name="idade" value="<?php echo htmlspecialchars($perfil['idade'] ?? '') ?>"></div>
  <div class="form-group"><label>Sexo</label>
    <select name="sexo">
      <option value="">--</option>
      <option value="masculino" <?php if(($perfil['sexo'] ?? '')==='masculino') echo 'selected' ?>>Masculino</option>
      <option value="feminino" <?php if(($perfil['sexo'] ?? '')==='feminino') echo 'selected' ?>>Feminino</option>
      <option value="outro" <?php if(($perfil['sexo'] ?? '')==='outro') echo 'selected' ?>>Outro</option>
    </select>
  </div>
  <div class="form-group"><label>Altura (cm)</label><input type="text" name="altura_cm" value="<?php echo htmlspecialchars($perfil['altura_cm'] ?? '') ?>"></div>
  <div class="form-group"><label>Peso atual (kg)</label><input type="text" name="peso_atual_kg" value="<?php echo htmlspecialchars($perfil['peso_atual_kg'] ?? '') ?>"></div>
  <div class="form-group"><label>Nível de atividade</label>
    <select name="nivel_atividade">
      <option value="sedentário" <?php if(($perfil['nivel_atividade'] ?? '')==='sedentário') echo 'selected' ?>>Sedentário</option>
      <option value="leve" <?php if(($perfil['nivel_atividade'] ?? '')==='leve') echo 'selected' ?>>Leve</option>
      <option value="moderado" <?php if(($perfil['nivel_atividade'] ?? '')==='moderado') echo 'selected' ?>>Moderado</option>
      <option value="intenso" <?php if(($perfil['nivel_atividade'] ?? '')==='intenso') echo 'selected' ?>>Intenso</option>
      <option value="muito_intenso" <?php if(($perfil['nivel_atividade'] ?? '')==='muito_intenso') echo 'selected' ?>>Muito intenso</option>
    </select>
  </div>
  <button type="submit">Salvar perfil</button>
</form>

<h3>Medidas recentes</h3>
<?php if(empty($medidas)) echo '<p>Nenhuma medida registrada.</p>'; else { foreach($medidas as $m){ echo '<div class="card"><strong>'.htmlspecialchars($m['peso_kg']).' kg</strong> - '.htmlspecialchars($m['data_registro']).'</div>'; }} ?>
</div>