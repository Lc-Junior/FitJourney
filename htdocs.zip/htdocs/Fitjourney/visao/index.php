<?php

session_start();
include __DIR__ . '/cabecalho.php';

include __DIR__ . '/rodape.php';
?>