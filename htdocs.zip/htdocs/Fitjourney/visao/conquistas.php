<?php
if(empty($_SESSION['id_usuario'])){ header('Location: index.php?pagina=login'); exit; }
$conquistaModel = new Conquista();
$lista = $conquistaModel->listar();
?>
<div class="card">
<h2>Conquistas</h2>
<?php if(empty($lista)) echo '<p>Nenhuma conquista definida.</p>'; else { foreach($lista as $c){ echo '<div class="card"><strong>'.htmlspecialchars($c['titulo']).'</strong> - '.htmlspecialchars($c['descricao']).'</div>'; }} ?>
</div>