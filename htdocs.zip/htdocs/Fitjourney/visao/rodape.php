</main>
<footer class="rodape">
  <div class="container">
    <p>FitJourney &copy; 2025</p>
  </div>
</footer>
</body>
</html>