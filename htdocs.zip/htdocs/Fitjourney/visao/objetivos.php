<?php
if(empty($_SESSION['id_usuario'])){ header('Location: index.php?pagina=login'); exit; }
$objetivoModel = new Objetivo();
$lista = $objetivoModel->listarPorUsuario($_SESSION['id_usuario']);
?>
<div class="card">
<h2>Objetivos</h2>
<form method="post" action="index.php">
  <input type="hidden" name="acao" value="criar_objetivo">
  <div class="form-group"><label>Tipo</label>
    <select name="tipo"><option value="emagrecimento">Emagrecimento</option><option value="manutenção">Manutenção</option><option value="ganho_massa">Ganho de massa</option></select>
  </div>
  <div class="form-group"><label>Peso meta (kg)</label><input type="text" name="peso_meta_kg"></div>
  <div class="form-group"><label>Data início</label><input type="date" name="data_inicio" required></div>
  <div class="form-group"><label>Data fim</label><input type="date" name="data_fim"></div>
  <div class="form-group"><label>Descrição</label><textarea name="descricao"></textarea></div>
  <button type="submit">Criar objetivo</button>
</form>

<h3>Meus objetivos</h3>
<?php if(empty($lista)) echo '<p>Nenhum objetivo cadastrado.</p>'; else { foreach($lista as $o){ echo '<div class="card"><strong>'.htmlspecialchars($o['tipo']).'</strong> - '.$o['peso_meta_kg'].' kg - Início: '.htmlspecialchars($o['data_inicio']).'</div>'; }} ?>
</div>