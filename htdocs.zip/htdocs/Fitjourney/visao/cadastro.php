<div class="card">
<h2>Cadastro</h2>
<?php if(!empty($_SESSION['mensagem_feed'])){ $m = json_decode($_SESSION['mensagem_feed'], true); if(isset($m['erro'])) echo '<small class="msg">'.$m['erro'].'</small>'; if(isset($m['mensagem'])) echo '<small style="color:green">'.$m['mensagem'].'</small>'; unset($_SESSION['mensagem_feed']); } ?>
<form method="post" action="/Fitjourney/visao/index.php">
  <input type="hidden" name="acao" value="registrar">
  <div class="form-group"><label>Nome</label><input type="text" name="nome" required></div>
  <div class="form-group"><label>E-mail</label><input type="email" name="email" required></div>
  <div class="form-group"><label>Senha</label><input type="password" name="senha" required></div>
  <button type="submit">Cadastrar</button>
</form>
<p>Já tem conta? <a href="index.php?pagina=login">Entrar</a></p>
</div>