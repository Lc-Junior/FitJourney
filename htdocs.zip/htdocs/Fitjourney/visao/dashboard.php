<div class="card">
<h2>Painel</h2>
<p>Bem-vindo ao FitJourney. Use o menu para navegar entre funcionalidades.</p>
<ul>
  <li><a href="../visao/perfil.php">Meu Perfil</a></li>
  <li><a href="../visao/refeicoes.php">Refeições</a></li>
  <li><a href="../visao/objetivos.php">Objetivos</a></li>
  <li><a href="../visao/conquistas.php">Conquistas</a></li>
</ul>
</div>