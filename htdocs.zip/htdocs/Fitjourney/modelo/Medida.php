<?php
class Medida {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function adicionar($id_usuario,$dados){
        $stmt = $this->pdo->prepare('INSERT INTO medidas (id_usuario,peso_kg,cintura_cm,quadril_cm,peito_cm,observacoes) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$id_usuario,$dados['peso_kg'],$dados['cintura_cm'],$dados['quadril_cm'],$dados['peito_cm'],$dados['observacoes']]);
        return $this->pdo->lastInsertId();
    }
    public function listarPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT * FROM medidas WHERE id_usuario = ? ORDER BY data_registro DESC');
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll();
    }
}
