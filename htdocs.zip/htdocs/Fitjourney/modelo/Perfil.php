<?php
include_once('../Modelo/DAO/conexao.php');
    
class Perfil {
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    private $pdo;
    public function obterPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT * FROM perfis WHERE id_usuario = ?');
        $stmt->execute([$id_usuario]);
        return $stmt->fetch();
    }
    public function criarOuAtualizar($id_usuario, $dados){
        $existe = $this->obterPorUsuario($id_usuario);
        if($existe){
            $stmt = $this->pdo->prepare('UPDATE perfis SET idade=?, sexo=?, altura_cm=?, peso_atual_kg=?, nivel_atividade=? WHERE id_usuario=?');
            $stmt->execute([$dados['idade'],$dados['sexo'],$dados['altura_cm'],$dados['peso_atual_kg'],$dados['nivel_atividade'],$id_usuario]);
            return true;
        } else {
            $stmt = $this->pdo->prepare('INSERT INTO perfis (id_usuario,idade,sexo,altura_cm,peso_atual_kg,nivel_atividade) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$id_usuario,$dados['idade'],$dados['sexo'],$dados['altura_cm'],$dados['peso_atual_kg'],$dados['nivel_atividade']]);
            return true;
        }
    }
}
