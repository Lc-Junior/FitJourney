<?php
class Conquista {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function listar(){
        $stmt = $this->pdo->query('SELECT * FROM conquistas ORDER BY pontos DESC');
        return $stmt->fetchAll();
    }
    public function atribuir($id_usuario,$id_conquista){
        $stmt = $this->pdo->prepare('INSERT IGNORE INTO usuarios_conquistas (id_usuario,id_conquista) VALUES (?,?)');
        $stmt->execute([$id_usuario,$id_conquista]);
        return true;
    }
}
