<?php
class Objetivo {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function criar($id_usuario,$dados){
        $stmt = $this->pdo->prepare('INSERT INTO objetivos (id_usuario,tipo,peso_meta_kg,data_inicio,data_fim,descricao) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$id_usuario,$dados['tipo'],$dados['peso_meta_kg'],$dados['data_inicio'],$dados['data_fim'],$dados['descricao']]);
        return $this->pdo->lastInsertId();
    }
    public function listarPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT * FROM objetivos WHERE id_usuario = ? ORDER BY data_inicio DESC');
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll();
    }
}
