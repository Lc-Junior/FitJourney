<?php
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'Fitjourney');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_AMBIENTE', 'desenvolvimento');

?>