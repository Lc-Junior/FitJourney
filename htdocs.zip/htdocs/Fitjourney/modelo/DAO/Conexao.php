<?php

    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'Fitjourney';
    
    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

?>