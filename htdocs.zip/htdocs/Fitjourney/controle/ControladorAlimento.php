<?php
class ControladorAlimento {
    private $modelo;
    public function __construct(){ $this->modelo = new Alimento(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function criar(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        $entrada['criado_por'] = $id;
        $aid = $this->modelo->criar($entrada);
        Resposta::json(['mensagem'=>'Alimento criado','id_alimento'=>$aid],201);
    }
    public function listar(){
        $lista = $this->modelo->listar();
        Resposta::json($lista);
    }
}
