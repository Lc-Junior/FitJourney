<?php
class ControladorRefeicao {
    private $modelo;
    public function __construct(){ $this->modelo = new Refeicao(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function criar(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        if(empty($entrada['data_refeicao']) || empty($entrada['tipo']) || empty($entrada['itens'])) Resposta::erro('data_refeicao, tipo e itens são obrigatórios',422);
        $rid = $this->modelo->criar($id,$entrada);
        foreach($entrada['itens'] as $item){
            $this->modelo->adicionarItem($rid,$item);
        }
        Resposta::json(['mensagem'=>'Refeição criada','id_refeicao'=>$rid],201);
    }
    public function listar(){
        $id = $this->requerAut();
        $lista = $this->modelo->listarPorUsuario($id);
        Resposta::json($lista);
    }
}
