<?php
class ControladorAutenticacao {
    private $modeloUsuario;
    public function __construct(){ $this->modeloUsuario = new Usuario(); }

    public function registrarEndpoint(){
        $input = json_decode(file_get_contents('php://input'), true);
        if(empty($input['nome']) || empty($input['email']) || empty($input['senha'])) Resposta::erro('nome, email e senha são obrigatórios',422);
        if(!Validador::emailValido($input['email'])) Resposta::erro('E-mail inválido',422);
        if(!Validador::senhaForte($input['senha'])) Resposta::erro('Senha fraca',422);
        try {
            $id = $this->modeloUsuario->criarUsuario($input['nome'],$input['email'],$input['senha']);
            Resposta::json(['mensagem'=>'Usuário criado com sucesso','id_usuario'=>$id],201);
        } catch (Exception $e) {
            Resposta::erro($e->getMessage(),400);
        }
    }

    public function entrarEndpoint(){
        $input = json_decode(file_get_contents('php://input'), true);
        if(empty($input['email']) || empty($input['senha'])) Resposta::erro('email e senha são obrigatórios',422);
        $user = $this->modeloUsuario->buscarPorEmail($input['email']);
        if(!$user) Resposta::erro('Credenciais inválidas',401);
        if(!password_verify($input['senha'],$user['senha_hash'])) Resposta::erro('Credenciais inválidas',401);
        $_SESSION['id_usuario'] = $user['id_usuario'];
        Resposta::json(['mensagem'=>'Autenticado','session_id'=>session_id(),'id_usuario'=>$user['id_usuario']]);
    }
}
