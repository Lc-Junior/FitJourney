<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['email'])) {
    header('Location: Login.php');
    exit();
}

include_once('../Modelo/DAO/conexao.php');

$email = $_SESSION['email'];
$sqlUser = "SELECT id FROM usuario WHERE email = '$email'";
$resultUser = $conexao->query($sqlUser);
if ($resultUser->num_rows < 1) {
    echo "Usuário não encontrado.";
    exit();
}
$user = $resultUser->fetch_assoc();
$userId = $user['id'];

if (isset($_POST['submit'])) {
    $quantidade = intval($_POST['quantidade']);
    $data_hora = $_POST['data_hora'];

    $sqlInsert = "INSERT INTO lembrete_agua (quantidade, data_hora, usuariolembrete_id) 
                  VALUES ($quantidade, '$data_hora', $userId)";

    if ($conexao->query($sqlInsert) === TRUE) {
        $msg = "Lembrete de água registrado com sucesso!";
    } else {
        $msg = "Erro ao registrar lembrete: " . $conexao->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lembrete de Água</title>
    <link rel="stylesheet" href="assets/css/styleCadastro.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="box">
        <h2>Configurar Lembrete de Água</h2>
        <?php if (isset($msg)) echo "<p>$msg</p>"; ?>
        <form method="POST" action="LembreteAgua.php" id="reminderForm">
            <label for="quantidade">Quantidade (ml):</label>
            <input type="number" id="quantidade" name="quantidade" min="100" required><br><br>

            <label for="data_hora">Data e Hora:</label>
            <input type="datetime-local" id="data_hora" name="data_hora" required><br><br>

            <label for="reminder_time">Lembrete em minutos (ex: 2):</label>
            <input type="number" id="reminder_time" name="reminder_time" min="1" max="1440" placeholder="Minutos" required><br><br>

            <input type="submit" name="submit" value="Registrar">
        </form>
    </div>
    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="PaginaInicial.php" class="btn btn-primary">Voltar</a>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const form = document.getElementById('reminderForm');

        
        if ("Notification" in window && Notification.permission !== "granted") {
            Notification.requestPermission();
        }

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            const reminderMinutes = parseInt(document.getElementById('reminder_time').value);
            if (isNaN(reminderMinutes) || reminderMinutes < 1) {
                alert('Por favor, insira um tempo válido para o lembrete em minutos.');
                return;
            }

            if (!("Notification" in window)) {
                alert("Este navegador não suporta notificações.");
                return;
            }

            if (Notification.permission !== "granted") {
                alert("Permissão para notificações negada ou não concedida.");
                return;
            }

            alert('Lembrete configurado para ' + reminderMinutes + ' minuto(s) a partir de agora.');

          
            new Notification("Lembrete de Água", {
                body: "Hora de beber água! Quantidade: " + document.getElementById('quantidade').value + " ml",
                icon: "assets/image/biotipo.jpg"
            });

         
            setTimeout(function () {
                form.submit();
            }, 5000);
        });
    });
</script>
</body>
</html>
