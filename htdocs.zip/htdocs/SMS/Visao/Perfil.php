<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['email'])) {
    header('Location: Login.php');
    exit();
}

include_once('../Modelo/DAO/conexao.php');

$email = $_SESSION['email'];
$sqlUser = "SELECT id FROM usuario WHERE email = '$email'";
$resultUser = $conexao->query($sqlUser);
if ($resultUser->num_rows < 1) {
    echo "Usuário não encontrado.";
    exit();
}
$user = $resultUser->fetch_assoc();
$userId = $user['id'];

$sqlPerfil = "SELECT * FROM perfil WHERE usuarioperfil_id = $userId";
$resultPerfil = $conexao->query($sqlPerfil);
$perfil = null;
if ($resultPerfil->num_rows > 0) {
    $perfil = $resultPerfil->fetch_assoc();
}

if (isset($_POST['submit'])) {
    $altura = floatval($_POST['altura']);
    $peso = floatval($_POST['peso']);
    $atividade_fisica = $conexao->real_escape_string($_POST['atividade_fisica']);
    $objetivo = $conexao->real_escape_string($_POST['objetivo']);

    if ($perfil) {
        $sqlUpdate = "UPDATE perfil SET altura = $altura, peso = $peso, atividade_fisica = '$atividade_fisica', objetivo = '$objetivo' WHERE usuarioperfil_id = $userId";
        if ($conexao->query($sqlUpdate) === TRUE) {
            $msg = "Perfil atualizado com sucesso!";
        } else {
            $msg = "Erro ao atualizar perfil: " . $conexao->error;
        }
    } else {
        $sqlInsert = "INSERT INTO perfil (altura, peso, atividade_fisica, objetivo, usuarioperfil_id) VALUES ($altura, $peso, '$atividade_fisica', '$objetivo', $userId)";
        if ($conexao->query($sqlInsert) === TRUE) {
            $msg = "Perfil criado com sucesso!";
        } else {
            $msg = "Erro ao criar perfil: " . $conexao->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="assets/css/styleCadastro.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body>
    <div class="box">
        <h2>Editar Perfil</h2>
        <?php if (isset($msg)) echo "<p>$msg</p>"; ?>
        <form method="POST" action="Perfil.php">
            <label for="altura">Altura (m):</label>
            <input type="number" step="0.01" id="altura" name="altura" value="<?php echo $perfil['altura'] ?? ''; ?>" required><br><br>

            <label for="peso">Peso (kg):</label>
            <input type="number" step="0.1" id="peso" name="peso" value="<?php echo $perfil['peso'] ?? ''; ?>" required><br><br>

            <label for="atividade_fisica">Atividade Física:</label>
            <input type="text" id="atividade_fisica" name="atividade_fisica" value="<?php echo htmlspecialchars($perfil['atividade_fisica'] ?? ''); ?>" required><br><br>

            <label for="objetivo">Objetivo:</label>
            <select id="objetivo" name="objetivo" required>
                <option value="Emagrecer" <?php if (($perfil['objetivo'] ?? '') == 'Emagrecer') echo 'selected'; ?>>Emagrecer</option>
                <option value="Ganhar Músculo" <?php if (($perfil['objetivo'] ?? '') == 'Ganhar Músculo') echo 'selected'; ?>>Ganhar Músculo</option>
                <option value="Manter Saúde" <?php if (($perfil['objetivo'] ?? '') == 'Manter Saúde') echo 'selected'; ?>>Manter Saúde</option>
            </select><br><br>

            <input type="submit" name="submit" value="Salvar">
        </form>
    </div>
    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="PaginaInicial.php" class="btn btn-primary">Voltar</a>
    </div>
</body>
</html>
