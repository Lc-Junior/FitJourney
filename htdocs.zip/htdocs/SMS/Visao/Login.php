<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" type="text/css" href="assets/css/styleLogin.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de login</title>
    <script>
        function validateForm() {
            const email = document.forms["loginForm"]["email"].value.trim();
            const senha = document.forms["loginForm"]["senha"].value.trim();
            let errorMsg = "";

            if (email === "") {
                errorMsg += "Por favor, preencha o campo Email.\n";
            }
            if (senha === "") {
                errorMsg += "Por favor, preencha o campo Senha.\n";
            }
            if (errorMsg !== "") {
                alert(errorMsg);
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div>
        <h1>Login</h1><br>
        <?php
            if (isset($_GET['error'])) {
                echo '<p style="color:red;">' . htmlspecialchars($_GET['error']) . '</p>';
            }
        ?>
        <form name="loginForm" action="LoginTeste.php" method="POST" onsubmit="return validateForm()">
            <input type="text" name="email" placeholder="Email">
            <br><br>
            <input type="password" name="senha" placeholder="Senha">
            <br><br>
            <input class="inputSubmit" type="submit" name="submit" value="Enviar">
        </form>
        <br>
        <form action="FormCadastro.php" method="get">
            <input class="inputSubmit" type="submit" value="Cadastrar">
        </form>
    </div>
</body>
</html>
