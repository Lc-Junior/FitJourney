<?php

    if(isset($_POST['submit']))
    {
     
        include_once('../Modelo/DAO/conexao.php');

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
        $celular = $_POST['celular'];
        $sexo = $_POST['genero'];
        $data_nascimento = $_POST['data_nascimento'];
        $biotipo = $_POST['biotipo'];

        $result = mysqli_query($conexao, "INSERT INTO usuario(nome,email,senha,celular,sexo,data_nascimento,biotipo) 
        VALUES ('$nome','$email','$senha','$celular','$sexo','$data_nascimento','$biotipo')");

        header('Location: Login.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="assets/css/styleCadastro.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Cadastro</title>
</head>
<body>
    <div class="box">
        <form action="Formcadastro.php" method="POST">
            <fieldset>
                <legend><b>Cadastre-se</b></legend>
                <br>
                <div class="inputBox">
                    <input type="text" name="nome" id="nome" class="inputUser" required>
                    <label for="nome" class="labelInput">Nome</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="email" id="email" class="inputUser" required>
                    <label for="email" class="labelInput">Email</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="password" name="senha" id="senha" class="inputUser" required>
                    <label for="senha" class="labelInput">Senha</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="tel" name="celular" id="celular" class="inputUser" required>
                    <label for="celular" class="labelInput">Telefone</label>
                </div>
                <p>Sexo:</p>
                <input type="radio" id="feminino" name="genero" value="Feminino" required>
                <label for="feminino">Feminino</label>
                <input type="radio" id="masculino" name="genero" value="Masculino" required>
                <label for="masculino">Masculino</label>
                <input type="radio" id="outro" name="genero" value="Outro" required>
                <label for="outro">Outro</label>
                <br><br>
                <label for="data_nascimento"><b>Data de Nascimento:</b></label>
                <input type="date" name="data_nascimento" id="data_nascimento" required>
                <br><br><br>
                <p>Biotipo:</p>
                <img src="assets/image/biotipo.jpg" alt="Biotipo Imagem" width="300" height="200">
                <br>
                <input type="radio" id="ectomorfo" name="biotipo" value="Ectomorfo" required>
                <label for="feminino">Ectomorfo</label>
                <input type="radio" id="mesomorfo" name="biotipo" value="Mesomorfo" required>
                <label for="masculino">Mesomorfo</label>
                <input type="radio" id="endomorfo" name="biotipo" value="Endomorfo" required>
                <label for="outro">Endomorfo</label>
                <br><br>
                <input type="submit" name="submit" id="submit">
            </fieldset>
        </form>
    </div>
</body>
</html>