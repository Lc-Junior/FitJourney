<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['email'])) {
    header('Location: Login.php');
    exit();
}

include_once('../Modelo/DAO/conexao.php');

$email = $_SESSION['email'];
$sqlUser = "SELECT id FROM usuario WHERE email = '$email'";
$resultUser = $conexao->query($sqlUser);
if ($resultUser->num_rows < 1) {
    echo "Usuário não encontrado.";
    exit();
}
$user = $resultUser->fetch_assoc();
$userId = $user['id'];

// Get today's date
$today = date('Y-m-d');


// Fetch total calories for the last 24 hours
$sqlCalories = "SELECT SUM(calorias) as total_calorias FROM alimentacao WHERE usuariorefeicao_id = $userId AND data_hora >= NOW() - INTERVAL 1 DAY";
$resultCalories = $conexao->query($sqlCalories);
if (!$resultCalories) {
    echo "Error in SQL query: " . $conexao->error . "<br>";
}
$rowCalories = $resultCalories->fetch_assoc();
$totalCalories = $rowCalories['total_calorias'] ?? 0;

// Fetch total calories burned from exercise for the last 24 hours
$sqlCaloriesBurned = "SELECT SUM(calorias_gastas) as total_calorias_gastas FROM exercicio WHERE usuarioexercicio_id = $userId AND data_hora >= NOW() - INTERVAL 1 DAY";
$resultCaloriesBurned = $conexao->query($sqlCaloriesBurned);
if (!$resultCaloriesBurned) {
    echo "Error in SQL query: " . $conexao->error . "<br>";
}
$rowCaloriesBurned = $resultCaloriesBurned->fetch_assoc();
$totalCaloriesBurned = $rowCaloriesBurned['total_calorias_gastas'] ?? 0;

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Nutricional</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <h2>Resumo Nutricional Diário</h2>
    <p>Calorias consumidas hoje: <?php echo $totalCalories; ?> kcal</p>
    <p>Calorias gastas hoje: <?php echo $totalCaloriesBurned; ?> kcal</p>

    <canvas id="calorieChart" width="400" height="200"></canvas>

    <script>
        const ctx = document.getElementById('calorieChart').getContext('2d');
        const calorieChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Calorias Consumidas', 'Calorias Gastas'],
                datasets: [{
                    label: 'Calorias',
                    data: [<?php echo $totalCalories; ?>, <?php echo $totalCaloriesBurned; ?>],
                    backgroundColor: ['rgba(255, 99, 132, 0.5)', 'rgba(54, 162, 235, 0.5)'],
                    borderColor: ['rgba(255, 99, 132, 1)', 'rgba(54, 162, 235, 1)'],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="PaginaInicial.php" class="btn btn-primary">Voltar</a>
    </div>
</body>
</html>
