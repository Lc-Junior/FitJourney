<?php
    session_start();
    include_once('../Modelo/DAO/conexao.php');
    if((!isset($_SESSION['email']) == true) and (!isset($_SESSION['senha']) == true))
    {
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        header('Location: Login.php');
    }
    $logado = $_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>SISTEMA SMS</title>
    <style>
        body{
            
            background-image: url('assets/image/imagem.png');
            color: white;
            text-align: center;
        }
        .table-bg{
            background: rgba(0, 0, 0, 0.3);
            border-radius: 15px 15px 0 0;
        }

        .box-search{
            display: flex;
            justify-content: center;
            gap: .1%;
        }
    </style>
</head>
<body>

    <br>

    <div class="d-flex justify-content-center gap-3 mb-3">
        <a href="RegistroRefeicao.php" class="btn btn-primary">Registro de Refeição</a>
        <a href="RegistroExercicio.php" class="btn btn-primary">Registro de Exercício</a>
        <a href="LembreteAgua.php" class="btn btn-primary">Lembrete de Água</a>
        <a href="Dashboard.php" class="btn btn-primary">Dashboard</a>
        <a href="Perfil.php" class="btn btn-primary">Perfil</a>
        <a href="Logout.php" class="btn btn-danger ms-3">Sair</a>
    </div>

</body>
</html>
