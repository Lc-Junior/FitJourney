<?php
    session_start();
    if(isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha']))
    {
        include_once('../Modelo/DAO/conexao.php');
        $email = $_POST['email'];
        $senha = $_POST['senha'];

        $sql = "SELECT * FROM usuario WHERE email = '$email'";

        $result = $conexao->query($sql);

        if(mysqli_num_rows($result) < 1)
        {
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
            header('Location: Login.php?error=Usuário não encontrado');
            exit();
        }
        else
        {
            $row = mysqli_fetch_assoc($result);
            if (password_verify($senha, $row['senha'])) {
                $_SESSION['email'] = $email;
                header('Location: PaginaInicial.php');
                exit();
            } else {
                unset($_SESSION['email']);
                unset($_SESSION['senha']);
                header('Location: Login.php?error=Senha incorreta');
                exit();
            }
        }
    }
    else
    {
        header('Location: Login.php?error=Por favor, preencha todos os campos');
        exit();
    }
?>