<?php

    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = '';
    $dbName = 'monitoramento';
    
    $conexao = new mysqli($dbHost,$dbUsername,$dbPassword,$dbName);

?>