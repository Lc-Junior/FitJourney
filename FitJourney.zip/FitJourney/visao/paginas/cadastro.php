<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Notificacao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Refeicao.php';
require_once '../../controle/ControleUsuario.php';

$titulo = 'Cadastro';

// Redireciona se já estiver logado
if (Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('../index.php');
}

$mensagem = '';
$tipoMensagem = '';

// Processa cadastro
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controleUsuario = new ControleUsuario();
    $resposta = $controleUsuario->cadastrar(Funcoes::limparEntrada($_POST));

    if ($resposta->getSucesso()) {
        $mensagem = $resposta->getMensagem() . ' Você pode fazer login agora.';
        $tipoMensagem = 'success';
    } else {
        $mensagem = $resposta->getMensagem();
        $tipoMensagem = 'error';
    }
}

include '../includes/cabecalho.php';
?>

<div class="auth-form">
    <h2>Criar Conta</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="nome">Nome completo:</label>
            <input type="text" id="nome" name="nome" required>
        </div>

        <div class="form-group">
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required minlength="6">
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;">Cadastrar</button>
    </form>

    <p style="text-align: center; margin-top: 20px;">
        Já tem conta? <a href="../paginas/login.php">Faça login aqui</a>
    </p>
</div>

<?php include '../includes/rodape.php'; ?>
