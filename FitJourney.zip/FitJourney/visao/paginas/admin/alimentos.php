<?php
require_once '../../../modelo/DAO/conexao.php';
require_once '../../../ajudantes/Funcoes.php';
require_once '../../../ajudantes/Validador.php';
require_once '../../../ajudantes/Resposta.php';
require_once '../../../modelo/Alimento.php';
require_once '../../../controle/ControleAdmin.php';

$titulo = 'Gerenciar Alimentos - Admin';

// Verifica se está logado e é admin
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('../login.php');
}

if (!Funcoes::isAdmin()) {
    Funcoes::redirecionar('../dashboard.php');
}

$controleAdmin = new ControleAdmin();

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'cadastrar_manual':
            $resposta = $controleAdmin->cadastrarAlimento(Funcoes::limparEntrada($_POST));
            break;

        case 'cadastrar_api':
            $resposta = $controleAdmin->cadastrarAlimentoViaAPI(Funcoes::limparEntrada($_POST));
            break;

        case 'atualizar':
            $resposta = $controleAdmin->atualizarAlimento($_POST['id'], Funcoes::limparEntrada($_POST));
            break;

        case 'excluir':
            $resposta = $controleAdmin->excluirAlimento($_POST['id']);
            break;
    }

    if (isset($resposta)) {
        if ($resposta->getSucesso()) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'success';
        } else {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'error';
        }
    }
}

// Obtém dados
$alimentosResposta = $controleAdmin->listarAlimentos();
$alimentos = $alimentosResposta->getSucesso() ? $alimentosResposta->getDados() : [];

include '../../includes/cabecalho.php';
?>

<div class="card">
    <h2>Gerenciar Alimentos</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-manual').style.display='block'" class="btn btn-primary">Cadastrar Manualmente</button>
    <button onclick="document.getElementById('modal-api').style.display='block'" class="btn btn-success">Cadastrar via API</button>
</div>

<div class="card">
    <h2>Alimentos Cadastrados</h2>
    <?php if (!empty($alimentos)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Calorias (kcal/100g)</th>
                    <th>Proteínas (g)</th>
                    <th>Carboidratos (g)</th>
                    <th>Gorduras (g)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($alimentos as $alimento): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alimento['nome']); ?></td>
                        <td><?php echo $alimento['calorias']; ?></td>
                        <td><?php echo $alimento['proteinas']; ?></td>
                        <td><?php echo $alimento['carboidratos']; ?></td>
                        <td><?php echo $alimento['gorduras']; ?></td>
                        <td>
                            <button onclick="editarAlimento(<?php echo $alimento['id']; ?>, '<?php echo addslashes($alimento['nome']); ?>', <?php echo $alimento['calorias']; ?>, <?php echo $alimento['proteinas']; ?>, <?php echo $alimento['carboidratos']; ?>, <?php echo $alimento['gorduras']; ?>)" class="btn btn-secondary btn-sm">Editar</button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="id" value="<?php echo $alimento['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Excluir este alimento?')">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum alimento cadastrado ainda.</p>
    <?php endif; ?>
</div>

<!-- Modal Cadastro Manual -->
<div id="modal-manual" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-manual').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Cadastrar Alimento Manualmente</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="cadastrar_manual">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="calorias">Calorias (kcal/100g):</label>
                <input type="number" id="calorias" name="calorias" step="0.1" min="0" required>
            </div>
            <div class="form-group">
                <label for="proteinas">Proteínas (g/100g):</label>
                <input type="number" id="proteinas" name="proteinas" step="0.1" min="0">
            </div>
            <div class="form-group">
                <label for="carboidratos">Carboidratos (g/100g):</label>
                <input type="number" id="carboidratos" name="carboidratos" step="0.1" min="0">
            </div>
            <div class="form-group">
                <label for="gorduras">Gorduras (g/100g):</label>
                <input type="number" id="gorduras" name="gorduras" step="0.1" min="0">
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>
</div>

<!-- Modal Cadastro via API -->
<div id="modal-api" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-api').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Cadastrar Alimento via API</h3>
        <p><small>Exemplo: "100g banana", "50g pão", "200ml leite"</small></p>
        <form method="POST">
            <input type="hidden" name="acao" value="cadastrar_api">
            <div class="form-group">
                <label for="descricao">Descrição do Alimento:</label>
                <input type="text" id="descricao" name="descricao" placeholder="Ex: 100g banana, 50g pão" required>
            </div>
            <button type="submit" class="btn btn-success">Buscar e Cadastrar</button>
        </form>
    </div>
</div>

<!-- Modal Editar -->
<div id="modal-editar" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-editar').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Editar Alimento</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="atualizar">
            <input type="hidden" id="edit-id" name="id">
            <div class="form-group">
                <label for="edit-nome">Nome:</label>
                <input type="text" id="edit-nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="edit-calorias">Calorias (kcal/100g):</label>
                <input type="number" id="edit-calorias" name="calorias" step="0.1" min="0" required>
            </div>
            <div class="form-group">
                <label for="edit-proteinas">Proteínas (g/100g):</label>
                <input type="number" id="edit-proteinas" name="proteinas" step="0.1" min="0">
            </div>
            <div class="form-group">
                <label for="edit-carboidratos">Carboidratos (g/100g):</label>
                <input type="number" id="edit-carboidratos" name="carboidratos" step="0.1" min="0">
            </div>
            <div class="form-group">
                <label for="edit-gorduras">Gorduras (g/100g):</label>
                <input type="number" id="edit-gorduras" name="gorduras" step="0.1" min="0">
            </div>
            <button type="submit" class="btn btn-primary">Atualizar</button>
        </form>
    </div>
</div>

<script>
function editarAlimento(id, nome, calorias, proteinas, carboidratos, gorduras) {
    document.getElementById('edit-id').value = id;
    document.getElementById('edit-nome').value = nome;
    document.getElementById('edit-calorias').value = calorias;
    document.getElementById('edit-proteinas').value = proteinas;
    document.getElementById('edit-carboidratos').value = carboidratos;
    document.getElementById('edit-gorduras').value = gorduras;
    document.getElementById('modal-editar').style.display = 'block';
}
</script>

<?php include '../../includes/rodape.php'; ?>
