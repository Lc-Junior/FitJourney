<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControlePerfil.php';

$titulo = 'Perfil';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$mensagem = '';
$tipoMensagem = '';

// Processa atualização do perfil
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controlePerfil = new ControlePerfil();
    $resposta = $controlePerfil->atualizar(Funcoes::limparEntrada($_POST));

    if ($resposta->getSucesso()) {
        $mensagem = $resposta->getMensagem();
        $tipoMensagem = 'success';
    } else {
        $mensagem = $resposta->getMensagem();
        $tipoMensagem = 'error';
    }
}

// Obtém dados do perfil
$controlePerfil = new ControlePerfil();
$perfilResposta = $controlePerfil->getPerfil();
$metricasResposta = $controlePerfil->calcularMetricas();

$perfil = $perfilResposta->getSucesso() ? $perfilResposta->getDados() : [];

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Meu Perfil</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="profile-info">
            <div class="form-group">
                <label for="idade">Idade:</label>
                <input type="number" id="idade" name="idade" value="<?php echo $perfil['idade'] ?? ''; ?>" min="10" max="120">
            </div>

            <div class="form-group">
                <label for="sexo">Sexo:</label>
                <select id="sexo" name="sexo">
                    <option value="">Selecione</option>
                    <option value="masculino" <?php echo ($perfil['sexo'] ?? '') == 'masculino' ? 'selected' : ''; ?>>Masculino</option>
                    <option value="feminino" <?php echo ($perfil['sexo'] ?? '') == 'feminino' ? 'selected' : ''; ?>>Feminino</option>
                    <option value="outro" <?php echo ($perfil['sexo'] ?? '') == 'outro' ? 'selected' : ''; ?>>Outro</option>
                </select>
            </div>

            <div class="form-group">
                <label for="altura">Altura (cm):</label>
                <input type="number" id="altura" name="altura" value="<?php echo $perfil['altura'] ?? ''; ?>" step="0.1" min="100" max="250">
            </div>

            <div class="form-group">
                <label for="peso">Peso (kg):</label>
                <input type="number" id="peso" name="peso" value="<?php echo $perfil['peso'] ?? ''; ?>" step="0.1" min="30" max="300">
            </div>

            <div class="form-group">
                <label for="nivel_atividade">Nível de Atividade:</label>
                <select id="nivel_atividade" name="nivel_atividade">
                    <option value="">Selecione</option>
                    <option value="sedentario" <?php echo ($perfil['nivel_atividade'] ?? '') == 'sedentario' ? 'selected' : ''; ?>>Sedentário</option>
                    <option value="leve" <?php echo ($perfil['nivel_atividade'] ?? '') == 'leve' ? 'selected' : ''; ?>>Leve</option>
                    <option value="moderado" <?php echo ($perfil['nivel_atividade'] ?? '') == 'moderado' ? 'selected' : ''; ?>>Moderado</option>
                    <option value="ativo" <?php echo ($perfil['nivel_atividade'] ?? '') == 'ativo' ? 'selected' : ''; ?>>Ativo</option>
                    <option value="muito_ativo" <?php echo ($perfil['nivel_atividade'] ?? '') == 'muito_ativo' ? 'selected' : ''; ?>>Muito Ativo</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Atualizar Perfil</button>
    </form>
</div>

<?php if ($metricasResposta->getSucesso()): ?>
    <?php $metricas = $metricasResposta->getDados(); ?>
    <div class="card">
        <h2>Métricas Calculadas</h2>
        <div class="dashboard-grid">
            <div class="metric-card">
                <h3>IMC</h3>
                <div class="value"><?php echo number_format($metricas['imc'], 1); ?></div>
                <p><?php echo $metricas['classificacao_imc']; ?></p>
            </div>
            <div class="metric-card">
                <h3>TMB</h3>
                <div class="value"><?php echo number_format($metricas['tmb'], 0); ?> kcal</div>
                <p>Taxa Metabólica Basal</p>
            </div>
            <div class="metric-card">
                <h3>TDEE</h3>
                <div class="value"><?php echo number_format($metricas['tdee'], 0); ?> kcal</div>
                <p>Gasto Energético Total Diário</p>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php include '../includes/rodape.php'; ?>
