<?php
/**
 * Controlador para conquistas
 */
class ControleConquista {
    /**
     * Lista conquistas do usuário
     */
    public function listarPorUsuario() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("
            SELECT c.id, c.nome, c.descricao, c.xp, uc.data_conquista
            FROM conquistas c
            LEFT JOIN usuarios_conquistas uc ON c.id = uc.conquista_id AND uc.usuario_id = ?
            ORDER BY c.nome
        ");
        $stmt->execute([$usuarioId]);
        $conquistas = $stmt->fetchAll();

        $dados = [];
        foreach ($conquistas as $conquista) {
            $dados[] = [
                'id' => $conquista['id'],
                'nome' => $conquista['nome'],
                'descricao' => $conquista['descricao'],
                'xp' => $conquista['xp'],
                'desbloqueada' => $conquista['data_conquista'] !== null,
                'data_conquista' => $conquista['data_conquista']
            ];
        }

        return Resposta::sucesso('Conquistas listadas com sucesso.', $dados);
    }

    /**
     * Lista todas as conquistas (para admin)
     */
    public function listarTodas() {
        $conquistas = Conquista::listarTodos();
        $dados = [];

        foreach ($conquistas as $conquista) {
            $dados[] = [
                'id' => $conquista->getId(),
                'nome' => $conquista->getNome(),
                'descricao' => $conquista->getDescricao(),
                'criterio' => $conquista->getCriterio(),
                'xp' => $conquista->getXp()
            ];
        }

        return Resposta::sucesso('Conquistas listadas com sucesso.', $dados);
    }

    /**
     * Cadastra nova conquista (admin)
     */
    public function cadastrar($dados) {
        $validador = new Validador();
        $validador->naoVazio($dados['nome'] ?? '', 'nome');
        $validador->naoVazio($dados['descricao'] ?? '', 'descrição');
        $validador->naoVazio($dados['criterio'] ?? '', 'critério');
        $validador->numerico($dados['xp'] ?? '', 'XP');
        $validador->positivo($dados['xp'] ?? 0, 'XP');

        if ($validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $validador->getErros()));
        }

        $conquista = new Conquista($dados['nome'], $dados['descricao'], $dados['criterio'], $dados['xp']);
        if ($conquista->salvar()) {
            return Resposta::sucesso('Conquista cadastrada com sucesso.', ['id' => $conquista->getId()]);
        }

        return Resposta::erro('Erro ao cadastrar conquista.');
    }

    /**
     * Atualiza conquista (admin)
     */
    public function atualizar($id, $dados) {
        $conquista = Conquista::buscarPorId($id);
        if (!$conquista) {
            return Resposta::erro('Conquista não encontrada.');
        }

        $validador = new Validador();
        if (isset($dados['nome'])) $validador->naoVazio($dados['nome'], 'nome');
        if (isset($dados['descricao'])) $validador->naoVazio($dados['descricao'], 'descrição');
        if (isset($dados['criterio'])) $validador->naoVazio($dados['criterio'], 'critério');
        if (isset($dados['xp'])) {
            $validador->numerico($dados['xp'], 'XP');
            $validador->positivo($dados['xp'], 'XP');
        }

        if ($validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $validador->getErros()));
        }

        if (isset($dados['nome'])) $conquista->setNome($dados['nome']);
        if (isset($dados['descricao'])) $conquista->setDescricao($dados['descricao']);
        if (isset($dados['criterio'])) $conquista->setCriterio($dados['criterio']);
        if (isset($dados['xp'])) $conquista->setXp($dados['xp']);

        if ($conquista->salvar()) {
            return Resposta::sucesso('Conquista atualizada com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar conquista.');
    }

    /**
     * Exclui conquista (admin)
     */
    public function excluir($id) {
        $conquista = Conquista::buscarPorId($id);
        if (!$conquista) {
            return Resposta::erro('Conquista não encontrada.');
        }

        if ($conquista->excluir()) {
            return Resposta::sucesso('Conquista excluída com sucesso.');
        }

        return Resposta::erro('Erro ao excluir conquista.');
    }

    /**
     * Calcula XP total do usuário
     */
    public function calcularXpTotal($usuarioId = null) {
        if (!$usuarioId) {
            $usuarioId = Funcoes::getUsuarioLogadoId();
        }
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("
            SELECT SUM(c.xp) as xp_total
            FROM usuarios_conquistas uc
            JOIN conquistas c ON uc.conquista_id = c.id
            WHERE uc.usuario_id = ?
        ");
        $stmt->execute([$usuarioId]);
        $resultado = $stmt->fetch();

        return Resposta::sucesso('XP calculado com sucesso.', ['xp_total' => $resultado['xp_total'] ?? 0]);
    }
}
?>
