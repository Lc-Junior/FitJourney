<?php
/**
 * Classe auxiliar para validação de dados
 */
class Validador {
    private $erros = [];

    /**
     * Valida se o campo não está vazio
     */
    public function naoVazio($valor, $campo) {
        if (empty(trim($valor))) {
            $this->erros[] = "O campo $campo é obrigatório.";
            return false;
        }
        return true;
    }

    /**
     * Valida email
     */
    public function email($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->erros[] = "E-mail inválido.";
            return false;
        }
        return true;
    }

    /**
     * Valida comprimento mínimo
     */
    public function comprimentoMinimo($valor, $campo, $min) {
        if (strlen($valor) < $min) {
            $this->erros[] = "O campo $campo deve ter pelo menos $min caracteres.";
            return false;
        }
        return true;
    }

    /**
     * Valida se é numérico
     */
    public function numerico($valor, $campo) {
        if (!is_numeric($valor)) {
            $this->erros[] = "O campo $campo deve ser numérico.";
            return false;
        }
        return true;
    }

    /**
     * Valida se é positivo
     */
    public function positivo($valor, $campo) {
        if ($valor <= 0) {
            $this->erros[] = "O campo $campo deve ser um valor positivo.";
            return false;
        }
        return true;
    }

    /**
     * Valida data
     */
    public function data($data, $campo) {
        $d = DateTime::createFromFormat('Y-m-d', $data);
        if (!$d || $d->format('Y-m-d') !== $data) {
            $this->erros[] = "O campo $campo deve ser uma data válida (YYYY-MM-DD).";
            return false;
        }
        return true;
    }

    /**
     * Valida hora
     */
    public function hora($hora, $campo) {
        $h = DateTime::createFromFormat('H:i', $hora);
        if (!$h || $h->format('H:i') !== $hora) {
            $this->erros[] = "O campo $campo deve ser uma hora válida (HH:MM).";
            return false;
        }
        return true;
    }

    /**
     * Valida se o valor está em uma lista
     */
    public function emLista($valor, $campo, $lista) {
        if (!in_array($valor, $lista)) {
            $this->erros[] = "O campo $campo deve ser um dos seguintes valores: " . implode(', ', $lista) . ".";
            return false;
        }
        return true;
    }

    /**
     * Retorna os erros
     */
    public function getErros() {
        return $this->erros;
    }

    /**
     * Verifica se há erros
     */
    public function temErros() {
        return !empty($this->erros);
    }

    /**
     * Limpa os erros
     */
    public function limparErros() {
        $this->erros = [];
    }

    /**
     * Valida cadastro de usuário
     */
    public function validarCadastroUsuario($dados) {
        $this->limparErros();
        $this->naoVazio($dados['nome'] ?? '', 'nome');
        $this->naoVazio($dados['email'] ?? '', 'email');
        $this->naoVazio($dados['senha'] ?? '', 'senha');
        if (isset($dados['email']) && !empty($dados['email'])) {
            $this->email($dados['email']);
        }
        if (isset($dados['senha']) && !empty($dados['senha'])) {
            $this->comprimentoMinimo($dados['senha'], 'senha', 6);
        }
        return !$this->temErros();
    }

    /**
     * Valida login
     */
    public function validarLogin($dados) {
        $this->limparErros();
        $this->naoVazio($dados['email'] ?? '', 'email');
        $this->naoVazio($dados['senha'] ?? '', 'senha');
        if (isset($dados['email']) && !empty($dados['email'])) {
            $this->email($dados['email']);
        }
        return !$this->temErros();
    }

    /**
     * Valida perfil
     */
    public function validarPerfil($dados) {
        $this->limparErros();
        if (isset($dados['idade'])) {
            $this->numerico($dados['idade'], 'idade');
            $this->positivo($dados['idade'], 'idade');
        }
        if (isset($dados['altura'])) {
            $this->numerico($dados['altura'], 'altura');
            $this->positivo($dados['altura'], 'altura');
        }
        if (isset($dados['peso'])) {
            $this->numerico($dados['peso'], 'peso');
            $this->positivo($dados['peso'], 'peso');
        }
        $niveis = ['sedentario', 'leve', 'moderado', 'ativo', 'muito_ativo'];
        if (isset($dados['nivel_atividade'])) {
            $this->emLista($dados['nivel_atividade'], 'nível de atividade', $niveis);
        }
        $sexos = ['masculino', 'feminino', 'outro'];
        if (isset($dados['sexo'])) {
            $this->emLista($dados['sexo'], 'sexo', $sexos);
        }
        return !$this->temErros();
    }
}
?>
