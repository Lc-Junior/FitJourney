<?php
require_once 'ajudantes/ApiNutricao.php';

$api = new ApiNutricao();
echo "Testando conexão com FatSecret API...\n";

// Debug: mostrar resposta da API
$result = $api->buscarAlimentos('apple', 1);
echo "Resposta da busca: ";
var_dump($result);

$result = !empty($result);
var_dump($result);

if ($result) {
    echo "✅ API funcionando!\n";
    echo "Testando busca de alimentos...\n";
    $alimentos = $api->buscarAlimentos('apple', 3);
    var_dump($alimentos);

    if (!empty($alimentos)) {
        echo "Testando obtenção de nutrientes...\n";
        $nutrientes = $api->obterNutrientes('apple', 100);
        var_dump($nutrientes);
    }
} else {
    echo "❌ API não está funcionando. Verifique as credenciais.\n";
}
?>
