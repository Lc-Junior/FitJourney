<?php
/**
 * Controlador para usuários
 */
class ControleUsuario {
    private $validador;

    public function __construct() {
        $this->validador = new Validador();
    }

    /**
     * Processa cadastro de usuário
     */
    public function cadastrar($dados) {
        if (!$this->validador->validarCadastroUsuario($dados)) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        // Verifica se email já existe
        $usuarioExistente = Usuario::buscarPorEmail($dados['email']);
        if ($usuarioExistente) {
            return Resposta::erro('E-mail já cadastrado.');
        }

        // Cria usuário
        $usuario = new Usuario($dados['nome'], $dados['email'], $dados['senha']);
        if ($usuario->salvar()) {
            // Cria perfil básico
            $perfil = new Perfil($usuario->getId());
            $perfil->salvar();

            // Notificação de boas-vindas
            $notificacao = new Notificacao($usuario->getId(), 'Bem-vindo ao FitJourney!', 'Sua jornada fitness começa agora. Complete seu perfil para personalizar suas metas.', 'lembrete');
            $notificacao->salvar();

            return Resposta::sucesso('Usuário cadastrado com sucesso.');
        }

        return Resposta::erro('Erro ao cadastrar usuário.');
    }

    /**
     * Processa login
     */
    public function login($dados) {
        if (!$this->validador->validarLogin($dados)) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $usuario = Usuario::buscarPorEmail($dados['email']);
        if (!$usuario || !$usuario->verificarSenha($dados['senha'])) {
            return Resposta::erro('E-mail ou senha incorretos.');
        }

        if (!$usuario->getAtivo()) {
            return Resposta::erro('Conta desativada.');
        }

        // Inicia sessão
        Funcoes::iniciarSessao();
        $_SESSION['usuario_id'] = $usuario->getId();
        $_SESSION['usuario_nome'] = $usuario->getNome();

        // Verifica conquistas
        $this->verificarConquistas($usuario->getId());

        return Resposta::sucesso('Login realizado com sucesso.');
    }

    /**
     * Faz logout
     */
    public function logout() {
        Funcoes::logout();
        return Resposta::sucesso('Logout realizado com sucesso.');
    }

    /**
     * Obtém dados do usuário logado
     */
    public function getUsuarioLogado() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $usuario = Usuario::buscarPorId($usuarioId);
        if (!$usuario) {
            return Resposta::erro('Usuário não encontrado.');
        }

        return Resposta::sucesso('Dados obtidos com sucesso.', [
            'id' => $usuario->getId(),
            'nome' => $usuario->getNome(),
            'email' => $usuario->getEmail(),
            'data_cadastro' => $usuario->getDataCadastro()
        ]);
    }

    /**
     * Atualiza dados do usuário
     */
    public function atualizar($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $usuario = Usuario::buscarPorId($usuarioId);
        if (!$usuario) {
            return Resposta::erro('Usuário não encontrado.');
        }

        // Valida email se fornecido
        if (isset($dados['email']) && !empty($dados['email'])) {
            $this->validador->email($dados['email']);
            // Verifica se email já existe para outro usuário
            $usuarioExistente = Usuario::buscarPorEmail($dados['email']);
            if ($usuarioExistente && $usuarioExistente->getId() != $usuarioId) {
                return Resposta::erro('E-mail já cadastrado por outro usuário.');
            }
        }

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        if (isset($dados['nome'])) $usuario->setNome($dados['nome']);
        if (isset($dados['email'])) $usuario->setEmail($dados['email']);

        if ($usuario->salvar()) {
            return Resposta::sucesso('Dados atualizados com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar dados.');
    }

    /**
     * Exclui conta do usuário
     */
    public function excluirConta() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $usuario = Usuario::buscarPorId($usuarioId);
        if (!$usuario) {
            return Resposta::erro('Usuário não encontrado.');
        }

        if ($usuario->excluir()) {
            Funcoes::logout();
            return Resposta::sucesso('Conta excluída com sucesso.');
        }

        return Resposta::erro('Erro ao excluir conta.');
    }

    /**
     * Verifica conquistas do usuário
     */
    private function verificarConquistas($usuarioId) {
        $conquistas = Conquista::listarTodos();

        foreach ($conquistas as $conquista) {
            if (!$conquista->usuarioDesbloqueou($usuarioId)) {
                // Verifica critério da conquista
                if ($this->verificarCriterioConquista($conquista->getCriterio(), $usuarioId)) {
                    $conquista->desbloquearParaUsuario($usuarioId);

                    // Notificação de conquista
                    $notificacao = new Notificacao($usuarioId, 'Nova Conquista!', "Você desbloqueou: {$conquista->getNome()}", 'conquista');
                    $notificacao->salvar();
                }
            }
        }
    }

    /**
     * Verifica se o critério da conquista foi atendido
     */
    private function verificarCriterioConquista($criterio, $usuarioId) {
        switch ($criterio) {
            case 'primeiro_login':
                return true; // Sempre verdadeiro no login

            case 'passos >= 10000':
                // Verificar se o usuário atingiu 10.000 passos em algum dia
                $pdo = Conexao::getInstancia()->getPDO();
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM dados_dispositivo WHERE usuario_id = ? AND passos >= 10000");
                $stmt->execute([$usuarioId]);
                return $stmt->fetchColumn() > 0;

            case 'objetivo_concluido':
                // Verificar se o usuário alcançou algum objetivo baseado no peso atual
                $objetivos = Objetivo::buscarPorUsuarioId($usuarioId);
                $medidas = Medida::buscarPorUsuarioId($usuarioId);
                if (empty($medidas)) {
                    return false; // Sem medidas, não pode ter alcançado
                }
                // Peso mais recente
                $pesoAtual = $medidas[0]->getPeso(); // Assumindo ordenado por data DESC
                foreach ($objetivos as $objetivo) {
                    $pesoAlvo = $objetivo->getPesoAlvo();
                    $tipo = $objetivo->getTipo();
                    if ($tipo == 'emagrecimento' && $pesoAtual <= $pesoAlvo) {
                        return true;
                    } elseif ($tipo == 'ganho_massa' && $pesoAtual >= $pesoAlvo) {
                        return true;
                    }
                    // Para manutenção, talvez não desbloquear automaticamente
                }
                return false;



            // Adicione mais critérios conforme necessário
            default:
                return false;
        }
    }
}
?>
