<?php
require_once 'ajudantes/ApiNutricao.php';

$api = new ApiNutricao();

echo "Testando obtenção de nutrientes...\n";

// Primeiro, buscar o alimento para ver se conseguimos o ID
$alimentos = $api->buscarAlimentos('apple', 1);
echo "Alimentos encontrados: ";
var_dump($alimentos);

if (!empty($alimentos)) {
    $alimento = $alimentos[0];
    echo "Testando com ID: " . $alimento['id'] . "\n";

    // Agora testar obterNutrientes
    $nutrientes = $api->obterNutrientes('apple', 100);
    echo "Resultado obterNutrientes: ";
    var_dump($nutrientes);
} else {
    echo "Nenhum alimento encontrado\n";
}
?>
