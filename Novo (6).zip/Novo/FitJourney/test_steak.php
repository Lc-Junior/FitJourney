<?php
require_once 'ajudantes/ApiNutricao.php';

$api = new ApiNutricao();

echo "Testando steak...\n";
$nutrientes = $api->obterNutrientes('steak', 100);
var_dump($nutrientes);

echo "\nTestando beans...\n";
$nutrientes = $api->obterNutrientes('beans', 100);
var_dump($nutrientes);

echo "\nTestando cooked beans...\n";
$nutrientes = $api->obterNutrientes('cooked beans', 100);
var_dump($nutrientes);
?>
