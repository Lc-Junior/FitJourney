<?php
require_once 'modelo/DAO/conexao.php';
require_once 'ajudantes/Funcoes.php';
require_once 'modelo/Objetivo.php';
require_once 'modelo/Perfil.php';

$pdo = Conexao::getInstancia()->getPDO();
$stmt = $pdo->query('SELECT * FROM objetivos WHERE usuario_id = 3');
$objetivos = $stmt->fetchAll();
echo 'Objetivos do usuario 3: ' . count($objetivos) . PHP_EOL;
foreach ($objetivos as $obj) {
    echo 'ID: ' . $obj['id'] . ', Usuario: ' . $obj['usuario_id'] . ', Calorias: ' . $obj['calorias_diarias'] . ', Tipo: ' . $obj['tipo'] . PHP_EOL;
    // Calcular calorias se não estiver definida
    if (empty($obj['calorias_diarias'])) {
        $perfil = Perfil::buscarPorUsuarioId($obj['usuario_id']);
        if ($perfil) {
            $tmb = Funcoes::calcularTMB($perfil->getPeso(), $perfil->getAltura(), $perfil->getIdade(), $perfil->getSexo());
            $tdee = Funcoes::calcularTDEE($tmb, $perfil->getNivelAtividade());
            $calorias = Funcoes::calcularCaloriasObjetivo($tdee, $obj['tipo']);
            echo 'Calorias calculadas: ' . round($calorias) . PHP_EOL;
        }
    }
}
?>
