# TODO: Add Date History to Dashboard

## Steps to Complete
- [x] Add date parameter handling (GET 'date', default to today, validate)
- [x] Add date navigation buttons (Previous Day, Today, Next Day) before calories section
- [x] Modify calories consumed calculation to use selected date
- [x] Modify calories burned calculation to use selected date
- [x] Update "Refeições de Hoje" to "Refeições de [Date]" and filter table by selected date
- [x] Update "Controle de Calorias Hoje" to "Controle de Calorias [Date]"
- [x] Update chart data and labels to use selected date values
- [x] Test navigation and data display for different dates
- [x] Add a date picker input for selecting specific dates
