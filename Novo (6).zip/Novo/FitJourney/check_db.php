<?php
require_once 'modelo/DAO/conexao.php';

$pdo = Conexao::getInstancia()->getPDO();
$stmt = $pdo->query('SELECT * FROM objetivos');
$objetivos = $stmt->fetchAll();
echo 'Objetivos no banco: ' . count($objetivos) . PHP_EOL;
foreach ($objetivos as $obj) {
    echo 'ID: ' . $obj['id'] . ', Usuario: ' . $obj['usuario_id'] . ', Calorias: ' . $obj['calorias_diarias'] . PHP_EOL;
}
?>
