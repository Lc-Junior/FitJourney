<?php
require_once '../../ajudantes/ApiTreino.php';
/**
 * Modelo para a entidade Treino
 */
class Treino {
    private $id;
    private $usuarioId;
    private $nome;
    private $descricao;
    private $dataTreino;
    private $duracao;
    private $exercicios; // JSON string

    public function __construct($usuarioId = null, $nome = null, $descricao = null, $dataTreino = null, $duracao = null, $exercicios = null) {
        $this->usuarioId = $usuarioId;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->dataTreino = $dataTreino;
        $this->duracao = $duracao;
        // Decode JSON string to array if it's a string
        if (is_string($exercicios)) {
            $this->exercicios = json_decode($exercicios, true);
        } else {
            $this->exercicios = $exercicios;
        }
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getNome() { return $this->nome; }
    public function setNome($nome) { $this->nome = $nome; }

    public function getDescricao() { return $this->descricao; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }

    public function getDataTreino() { return $this->dataTreino; }
    public function setDataTreino($dataTreino) { $this->dataTreino = $dataTreino; }

    public function getDuracao() { return $this->duracao; }
    public function setDuracao($duracao) { $this->duracao = $duracao; }

    public function getExercicios() { return $this->exercicios; }
    public function setExercicios($exercicios) { $this->exercicios = $exercicios; }

    /**
     * Salva o treino no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();

        // Encode exercicios to JSON if it's an array, else set to null if invalid
        $exerciciosJson = null;
        if (is_array($this->exercicios)) {
            $exerciciosJson = json_encode($this->exercicios);
        } elseif (is_string($this->exercicios) && json_decode($this->exercicios) !== null) {
            $exerciciosJson = $this->exercicios;
        }

        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE treinos SET nome = ?, descricao = ?, data_treino = ?, duracao = ?, exercicios = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->descricao, $this->dataTreino, $this->duracao, $exerciciosJson, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO treinos (usuario_id, nome, descricao, data_treino, duracao, exercicios) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->nome, $this->descricao, $this->dataTreino, $this->duracao, $exerciciosJson]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca treino por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM treinos WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $treino = new Treino($dados['usuario_id'], $dados['nome'], $dados['descricao'], $dados['data_treino'], $dados['duracao'], $dados['exercicios']);
            $treino->setId($dados['id']);
            return $treino;
        }
        return null;
    }

    /**
     * Lista treinos do usuário
     */
    public static function listarPorUsuario($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM treinos WHERE usuario_id = ? ORDER BY data_treino DESC");
        $stmt->execute([$usuarioId]);
        $treinos = [];
        while ($dados = $stmt->fetch()) {
            $treino = new Treino($dados['usuario_id'], $dados['nome'], $dados['descricao'], $dados['data_treino'], $dados['duracao'], $dados['exercicios']);
            $treino->setId($dados['id']);
            $treinos[] = $treino;
        }
        return $treinos;
    }

    /**
     * Calcula calorias totais do treino
     */
    public function calcularCaloriasTotais($pesoUsuario) {
        if (!$this->exercicios || !is_array($this->exercicios)) {
            return 0;
        }

        $apiTreino = new ApiTreino();
        return $apiTreino->calcularCaloriasTreino($this->exercicios, $pesoUsuario, $this->duracao);
    }

    /**
     * Exclui o treino
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM treinos WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
