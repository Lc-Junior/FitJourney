<?php
require_once 'ajudantes/ApiNutricao.php';

$api = new ApiNutricao();

echo "=== DEBUG API FATSECRET ===\n";

// Testa busca
echo "1. Testando busca de alimentos...\n";
$alimentos = $api->buscarAlimentos('apple', 1);
var_dump($alimentos);

// Testa obter nutrientes diretamente
echo "\n2. Testando obterNutrientes...\n";
$nutrientes = $api->obterNutrientes('apple', 100);
var_dump($nutrientes);

// Testa fazer requisição manual para food.get
echo "\n3. Testando requisição manual...\n";
$ch = curl_init();
$url = 'https://platform.fatsecret.com/rest/server.api?method=food.get&food_id=35718&format=json&oauth_consumer_key=d918612daef742438bc59f6228fdbe99&oauth_nonce=abc123&oauth_signature_method=HMAC-SHA1&oauth_timestamp=' . time() . '&oauth_version=1.0&oauth_signature=PLACEHOLDER';
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Response: " . substr($response, 0, 500) . "\n";
?>
