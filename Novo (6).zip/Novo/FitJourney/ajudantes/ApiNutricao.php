<?php
/**
 * Serviço para integração com APIs de nutrição - FatSecret
 */
class ApiNutricao {
    private $apiKey;
    private $apiSecret;
    private $baseUrl;

    public function __construct() {
        // FatSecret API credentials (free tier)
        $this->apiKey = 'd918612daef742438bc59f6228fdbe99'; // Substitua pela sua chave
        $this->apiSecret = '994c657710a548d598dba178a41b415d'; // Substitua pelo seu secret
        $this->baseUrl = 'https://platform.fatsecret.com/rest/server.api';
    }

    /**
     * Busca alimentos por termo de pesquisa
     */
    public function buscarAlimentos($termo, $limite = 10) {
        $method = 'foods.search';
        $params = [
            'method' => $method,
            'search_expression' => $termo,
            'max_results' => $limite,
            'format' => 'json'
        ];

        $result = $this->fazerRequisicao($params);

        if ($result && isset($result['foods']['food'])) {
            $alimentos = [];
            $foods = $result['foods']['food'];

            // Trata tanto array quanto objeto único
            if (is_array($foods) && isset($foods[0])) {
                // Múltiplos alimentos retornados como array
                $foodsToProcess = array_slice($foods, 0, $limite);
            } elseif (is_array($foods)) {
                // Array associativo único
                $foodsToProcess = [$foods];
            } else {
                // Objeto único
                $foodsToProcess = [$foods];
            }

            foreach ($foodsToProcess as $food) {
                // Verifica se o alimento tem os campos necessários
                if (!isset($food['food_name']) || !isset($food['food_id'])) {
                    continue; // Pula alimentos inválidos
                }

                $alimentos[] = [
                    'nome' => $food['food_name'],
                    'id' => $food['food_id'],
                    'tipo' => $food['food_type'] ?? 'Generic'
                ];
            }
            return $alimentos;
        }

        return [];
    }

    /**
     * Obtém informações nutricionais detalhadas de um alimento
     */
    public function obterNutrientes($alimento, $quantidade = 100, $unidade = 'g') {
        // Para simplificar, vamos usar valores aproximados baseados no nome do alimento
        // Isso evita problemas com a API FatSecret que pode ter limitações

        $valoresNutricionais = $this->getValoresNutricionaisAproximados($alimento);

        if ($valoresNutricionais) {
            // Ajusta para a quantidade solicitada
            $fator = $quantidade / 100; // Valores base são para 100g

            return [
                'nome' => $alimento,
                'calorias' => round($valoresNutricionais['calorias'] * $fator),
                'proteinas' => round($valoresNutricionais['proteinas'] * $fator, 1),
                'carboidratos' => round($valoresNutricionais['carboidratos'] * $fator, 1),
                'gorduras' => round($valoresNutricionais['gorduras'] * $fator, 1),
                'fibras' => round($valoresNutricionais['fibras'] * $fator, 1),
                'acucares' => round($valoresNutricionais['acucares'] * $fator, 1),
                'sodio' => round($valoresNutricionais['sodio'] * $fator, 1),
                'porcao' => $quantidade,
                'unidade' => $unidade
            ];
        }

        // Fallback para valores padrão se não encontrar
        return [
            'nome' => $alimento,
            'calorias' => 0,
            'proteinas' => 0,
            'carboidratos' => 0,
            'gorduras' => 0,
            'fibras' => 0,
            'acucares' => 0,
            'sodio' => 0,
            'porcao' => $quantidade,
            'unidade' => $unidade
        ];
    }

    /**
     * Retorna valores nutricionais aproximados para alimentos comuns (por 100g)
     */
    private function getValoresNutricionaisAproximados($alimento) {
        $alimentoLower = strtolower(trim($alimento));

        $valores = [
            // Frutas
            'apple' => ['calorias' => 52, 'proteinas' => 0.2, 'carboidratos' => 14, 'gorduras' => 0.2, 'fibras' => 2.4, 'acucares' => 10, 'sodio' => 1],
            'banana' => ['calorias' => 89, 'proteinas' => 1.1, 'carboidratos' => 23, 'gorduras' => 0.3, 'fibras' => 2.6, 'acucares' => 12, 'sodio' => 1],
            'orange' => ['calorias' => 47, 'proteinas' => 0.9, 'carboidratos' => 12, 'gorduras' => 0.1, 'fibras' => 2.4, 'acucares' => 9, 'sodio' => 0],
            'grape' => ['calorias' => 69, 'proteinas' => 0.7, 'carboidratos' => 18, 'gorduras' => 0.2, 'fibras' => 0.9, 'acucares' => 16, 'sodio' => 2],

            // Proteínas
            'chicken breast' => ['calorias' => 165, 'proteinas' => 31, 'carboidratos' => 0, 'gorduras' => 3.6, 'fibras' => 0, 'acucares' => 0, 'sodio' => 74],
            'beef' => ['calorias' => 250, 'proteinas' => 26, 'carboidratos' => 0, 'gorduras' => 17, 'fibras' => 0, 'acucares' => 0, 'sodio' => 72],
            'steak' => ['calorias' => 271, 'proteinas' => 25, 'carboidratos' => 0, 'gorduras' => 19, 'fibras' => 0, 'acucares' => 0, 'sodio' => 60],
            'fish' => ['calorias' => 206, 'proteinas' => 22, 'carboidratos' => 0, 'gorduras' => 12, 'fibras' => 0, 'acucares' => 0, 'sodio' => 74],
            'egg' => ['calorias' => 155, 'proteinas' => 13, 'carboidratos' => 1.1, 'gorduras' => 11, 'fibras' => 0, 'acucares' => 0.6, 'sodio' => 124],

            // Grãos e Cereais
            'rice' => ['calorias' => 130, 'proteinas' => 2.7, 'carboidratos' => 28, 'gorduras' => 0.3, 'fibras' => 0.4, 'acucares' => 0.1, 'sodio' => 1],
            'bread' => ['calorias' => 265, 'proteinas' => 9, 'carboidratos' => 49, 'gorduras' => 3.2, 'fibras' => 2.7, 'acucares' => 5, 'sodio' => 490],
            'pasta' => ['calorias' => 157, 'proteinas' => 5.8, 'carboidratos' => 31, 'gorduras' => 0.9, 'fibras' => 1.8, 'acucares' => 0.6, 'sodio' => 1],

            // Laticínios
            'milk' => ['calorias' => 61, 'proteinas' => 3.2, 'carboidratos' => 4.8, 'gorduras' => 3.3, 'fibras' => 0, 'acucares' => 4.8, 'sodio' => 43],
            'cheese' => ['calorias' => 402, 'proteinas' => 7, 'carboidratos' => 1.3, 'gorduras' => 33, 'fibras' => 0, 'acucares' => 0.5, 'sodio' => 621],
            'yogurt' => ['calorias' => 59, 'proteinas' => 3.5, 'carboidratos' => 4.7, 'gorduras' => 3.3, 'fibras' => 0, 'acucares' => 4.7, 'sodio' => 36],

            // Vegetais
            'potato' => ['calorias' => 77, 'proteinas' => 2, 'carboidratos' => 17, 'gorduras' => 0.1, 'fibras' => 2.2, 'acucares' => 0.8, 'sodio' => 6],
            'carrot' => ['calorias' => 41, 'proteinas' => 0.9, 'carboidratos' => 10, 'gorduras' => 0.2, 'fibras' => 2.8, 'acucares' => 4.7, 'sodio' => 69],
            'broccoli' => ['calorias' => 34, 'proteinas' => 2.8, 'carboidratos' => 7, 'gorduras' => 0.4, 'fibras' => 2.6, 'acucares' => 1.7, 'sodio' => 33],
            'spinach' => ['calorias' => 23, 'proteinas' => 2.9, 'carboidratos' => 3.6, 'gorduras' => 0.4, 'fibras' => 2.2, 'acucares' => 0.4, 'sodio' => 79],

            // Legumes
            'beans' => ['calorias' => 347, 'proteinas' => 21.6, 'carboidratos' => 62.6, 'gorduras' => 1.2, 'fibras' => 15.4, 'acucares' => 2.1, 'sodio' => 12],
            'cooked beans' => ['calorias' => 132, 'proteinas' => 7.5, 'carboidratos' => 23.6, 'gorduras' => 0.5, 'fibras' => 5.2, 'acucares' => 0.3, 'sodio' => 1],
            'lentils' => ['calorias' => 116, 'proteinas' => 9, 'carboidratos' => 20, 'gorduras' => 0.4, 'fibras' => 7.9, 'acucares' => 1.8, 'sodio' => 2],

            // Outros
            'olive oil' => ['calorias' => 884, 'proteinas' => 0, 'carboidratos' => 0, 'gorduras' => 100, 'fibras' => 0, 'acucares' => 0, 'sodio' => 2],
            'sugar' => ['calorias' => 387, 'proteinas' => 0, 'carboidratos' => 100, 'gorduras' => 0, 'fibras' => 0, 'acucares' => 100, 'sodio' => 0],
        ];

        // Busca exata primeiro
        if (isset($valores[$alimentoLower])) {
            return $valores[$alimentoLower];
        }

        // Busca parcial
        foreach ($valores as $key => $value) {
            if (strpos($alimentoLower, $key) !== false || strpos($key, $alimentoLower) !== false) {
                return $value;
            }
        }

        return null;
    }

    /**
     * Calcula nutrientes para múltiplos alimentos
     */
    public function calcularRefeicao($alimentos) {
        $total = [
            'calorias' => 0,
            'proteinas' => 0,
            'carboidratos' => 0,
            'gorduras' => 0,
            'fibras' => 0,
            'acucares' => 0,
            'sodio' => 0
        ];

        foreach ($alimentos as $alimento) {
            $quantidade = $alimento['quantidade'] ?? 100;
            $unidade = $alimento['unidade'] ?? 'g';

            $nutrientes = $this->obterNutrientes($alimento['nome'], $quantidade, $unidade);

            if ($nutrientes) {
                $total['calorias'] += $nutrientes['calorias'];
                $total['proteinas'] += $nutrientes['proteinas'];
                $total['carboidratos'] += $nutrientes['carboidratos'];
                $total['gorduras'] += $nutrientes['gorduras'];
                $total['fibras'] += $nutrientes['fibras'];
                $total['acucares'] += $nutrientes['acucares'];
                $total['sodio'] += $nutrientes['sodio'];
            }
        }

        return $total;
    }

    /**
     * Faz requisição HTTP para a API FatSecret
     */
    private function fazerRequisicao($params) {
        // Gera OAuth 1.0a signature para FatSecret
        $oauthParams = [
            'oauth_consumer_key' => $this->apiKey,
            'oauth_nonce' => md5(uniqid(rand(), true)),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp' => time(),
            'oauth_version' => '1.0'
        ];

        $allParams = array_merge($params, $oauthParams);
        ksort($allParams);

        $baseString = 'GET&' . urlencode($this->baseUrl) . '&' . urlencode(http_build_query($allParams));
        $signingKey = urlencode($this->apiSecret) . '&';

        $oauthParams['oauth_signature'] = base64_encode(hash_hmac('sha1', $baseString, $signingKey, true));

        $url = $this->baseUrl . '?' . http_build_query(array_merge($params, $oauthParams));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            error_log("Erro na API FatSecret: " . $error);
            return null;
        }

        if ($httpCode !== 200) {
            error_log("Erro HTTP na API FatSecret: " . $httpCode . " - " . $response);
            return null;
        }

        return json_decode($response, true);
    }

    /**
     * Verifica se a API está funcionando
     */
    public function testarConexao() {
        $result = $this->buscarAlimentos('apple', 1);
        return !empty($result);
    }
}
?>
