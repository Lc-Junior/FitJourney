<?php
/**
 * Classe para tradução de nomes de alimentos do português para inglês
 */
class TradutorAlimentos {

    private static $traducao = [
        // Cereais e grãos
        'arroz cozido' => 'cooked rice',
        'arroz' => 'rice',
        'aveia' => 'oats',
        'pão integral' => 'whole wheat bread',
        'pão' => 'bread',
        'macarrão' => 'pasta',
        'espaguete' => 'spaghetti',
        'trigo' => 'wheat',

        // Proteínas
        'frango grelhado' => 'grilled chicken',
        'frango' => 'chicken',
        'peito de frango' => 'chicken breast',
        'carne bovina' => 'beef',
        'carne' => 'meat',
        'peixe' => 'fish',
        'salmão' => 'salmon',
        'atum' => 'tuna',
        'ovo cozido' => 'boiled egg',
        'ovo' => 'egg',
        'queijo cottage' => 'cottage cheese',
        'queijo' => 'cheese',
        'iogurte natural' => 'plain yogurt',
        'iogurte' => 'yogurt',
        'leite' => 'milk',

        // Vegetais
        'batata doce' => 'sweet potato',
        'batata' => 'potato',
        'brócolis' => 'broccoli',
        'cenoura' => 'carrot',
        'tomate' => 'tomato',
        'alface' => 'lettuce',
        'espinafre' => 'spinach',
        'abóbora' => 'pumpkin',
        'berinjela' => 'eggplant',
        'pimentão' => 'bell pepper',
        'cebola' => 'onion',
        'alho' => 'garlic',
        'couve' => 'cabbage',

        // Frutas
        'banana' => 'banana',
        'maçã' => 'apple',
        'laranja' => 'orange',
        'uva' => 'grape',
        'morango' => 'strawberry',
        'abacate' => 'avocado',
        'manga' => 'mango',
        'melancia' => 'watermelon',
        'melão' => 'melon',
        'pera' => 'pear',
        'pêssego' => 'peach',
        'limão' => 'lemon',

        // Outros
        'amêndoas' => 'almonds',
        'castanha' => 'chestnut',
        'manteiga' => 'butter',
        'azeite' => 'olive oil',
        'óleo' => 'oil',
        'mel' => 'honey',
        'açúcar' => 'sugar',
        'sal' => 'salt',
        'café' => 'coffee',
        'chá' => 'tea'
    ];

    /**
     * Traduz um nome de alimento do português para inglês
     */
    public static function traduzir($nomePortugues) {
        $nomeMinusculo = strtolower(trim($nomePortugues));

        // Verifica tradução exata
        if (isset(self::$traducao[$nomeMinusculo])) {
            return self::$traducao[$nomeMinusculo];
        }

        // Tenta encontrar tradução parcial
        foreach (self::$traducao as $pt => $en) {
            if (strpos($nomeMinusculo, $pt) !== false) {
                return str_replace($pt, $en, $nomeMinusculo);
            }
        }

        // Se não encontrar tradução, retorna o nome original (pode funcionar se já estiver em inglês)
        return $nomePortugues;
    }

    /**
     * Adiciona uma nova tradução ao dicionário
     */
    public static function adicionarTraducao($portugues, $ingles) {
        self::$traducao[strtolower(trim($portugues))] = strtolower(trim($ingles));
    }
}
