<?php
require_once 'modelo/DAO/conexao.php';

$pdo = Conexao::getInstancia()->getPDO();
$stmt = $pdo->query('SELECT * FROM objetivos WHERE usuario_id = 3');
$objetivos = $stmt->fetchAll();
echo 'Objetivos do usuario 3: ' . count($objetivos) . PHP_EOL;
foreach ($objetivos as $obj) {
    echo 'ID: ' . $obj['id'] . ', Usuario: ' . $obj['usuario_id'] . ', Calorias: ' . $obj['calorias_diarias'] . ', Tipo: ' . $obj['tipo'] . PHP_EOL;
}
?>
