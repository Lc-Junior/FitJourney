<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Treino.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleUsuario.php';
require_once '../../controle/ControlePerfil.php';
require_once '../../controle/ControleRefeicao.php';
require_once '../../controle/ControleObjetivo.php';
require_once '../../controle/ControleConquista.php';
require_once '../../controle/ControleNotificacao.php';

$titulo = 'Dashboard';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$usuarioId = Funcoes::getUsuarioLogadoId();

// Handle date selection
$selectedDate = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
// Validate date format
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate) || !strtotime($selectedDate)) {
    $selectedDate = date('Y-m-d');
}

// Obtém dados do dashboard
$controlePerfil = new ControlePerfil();
$perfilResposta = $controlePerfil->getPerfil();

$metricasResposta = $controlePerfil->calcularMetricas();

$controleRefeicao = new ControleRefeicao();
$refeicoesResposta = $controleRefeicao->listar();

$controleObjetivo = new ControleObjetivo();
$objetivosResposta = $controleObjetivo->listar();

$controleConquista = new ControleConquista();
$xpResposta = $controleConquista->calcularXpTotal();

$controleNotificacao = new ControleNotificacao();
$notificacoesResposta = $controleNotificacao->listarNaoLidas();

// Calcular calorias do dia selecionado
$treinosHoje = Treino::listarPorUsuario($usuarioId);
$caloriasGastasTreino = 0;
$perfilDados = $perfilResposta->getSucesso() ? $perfilResposta->getDados() : null;
$peso = $perfilDados ? $perfilDados['peso'] : 70; // default
foreach ($treinosHoje as $treino) {
    if ($treino->getDataTreino() == $selectedDate) {
        $caloriasGastasTreino += $treino->calcularCaloriasTotais($peso);
    }
}

$caloriasConsumidas = 0;
if ($refeicoesResposta->getSucesso()) {
    foreach ($refeicoesResposta->getDados() as $refeicao) {
        if ($refeicao->getDataRefeicao() == $selectedDate) {
            $caloriasConsumidas += $refeicao->calcularCaloriasTotais();
        }
    }
}

$metaDiaria = 2000; // default

// Priorizar calorias do objetivo se disponível
if ($objetivosResposta->getSucesso()) {
    $objetivos = $objetivosResposta->getDados();
    if (!empty($objetivos)) {
        $objetivoAtivo = $objetivos[0]; // Primeiro objetivo ativo
        if (isset($objetivoAtivo['calorias_diarias']) && $objetivoAtivo['calorias_diarias'] > 0) {
            $metaDiaria = $objetivoAtivo['calorias_diarias'];
        } else {
            // Se objetivo não tem calorias definidas, calcular baseado no perfil
            if ($perfilResposta->getSucesso() && $metricasResposta->getSucesso()) {
                $perfilDados = $perfilResposta->getDados();
                $metricas = $metricasResposta->getDados();
                $tdee = $metricas['tdee'];
                $metaDiaria = Funcoes::calcularCaloriasObjetivo($tdee, $objetivoAtivo['tipo']);
            } else {
                // Fallback para TDEE
                if ($metricasResposta->getSucesso()) {
                    $metricas = $metricasResposta->getDados();
                    $metaDiaria = $metricas['tdee'];
                }
            }
        }
    } else {
        // Sem objetivos, usar TDEE
        if ($metricasResposta->getSucesso()) {
            $metricas = $metricasResposta->getDados();
            $metaDiaria = $metricas['tdee'];
        }
    }
} else {
    // Fallback para TDEE se não conseguir objetivos
    if ($metricasResposta->getSucesso()) {
        $metricas = $metricasResposta->getDados();
        $metaDiaria = $metricas['tdee'];
    }
}

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Olá, <?php echo $_SESSION['usuario_nome']; ?>!</h2>
    <p>Bem-vindo ao seu painel de controle fitness.</p>
</div>

<?php if ($notificacoesResposta->getSucesso() && !empty($notificacoesResposta->getDados())): ?>
<div class="card">
    <h2>Notificações Recentes</h2>
    <?php foreach ($notificacoesResposta->getDados() as $notificacao): ?>
        <div class="notification-item unread">
            <div class="title"><?php echo htmlspecialchars($notificacao['titulo']); ?></div>
            <div><?php echo htmlspecialchars($notificacao['mensagem']); ?></div>
            <div class="date"><?php echo Funcoes::formatarData($notificacao['data_notificacao']); ?></div>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="dashboard-grid">
    <?php if ($metricasResposta->getSucesso()): ?>
        <?php $metricas = $metricasResposta->getDados(); ?>
        <div class="metric-card">
            <h3>IMC</h3>
            <div class="value"><?php echo number_format($metricas['imc'], 1); ?></div>
            <p><?php echo $metricas['classificacao_imc']; ?></p>
        </div>
        <div class="metric-card">
            <h3>TMB</h3>
            <div class="value"><?php echo number_format($metricas['tmb'], 0); ?> kcal</div>
            <p>Taxa Metabólica Basal</p>
        </div>
        <div class="metric-card">
            <h3>TDEE</h3>
            <div class="value"><?php echo number_format($metricas['tdee'], 0); ?> kcal</div>
            <p>Gasto Energético Total</p>
        </div>
        <div class="metric-card">
            <h3>XP Total</h3>
            <div class="value"><?php echo $xpResposta->getSucesso() ? $xpResposta->getDados()['xp_total'] : 0; ?></div>
            <p>Pontos de experiência</p>
        </div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Refeições de <?php echo Funcoes::formatarData($selectedDate); ?></h2>
    <?php if ($refeicoesResposta->getSucesso() && !empty($refeicoesResposta->getDados())): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Data</th>
                    <th>Calorias</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $refeicoesHoje = array_filter($refeicoesResposta->getDados(), function($refeicao) use ($selectedDate) {
                    return $refeicao->getDataRefeicao() == $selectedDate;
                });
                foreach ($refeicoesHoje as $refeicao):
                ?>
                    <tr>
                        <td><?php echo ucfirst(str_replace('_', ' ', $refeicao->getTipo())); ?></td>
                        <td><?php echo Funcoes::formatarData($refeicao->getDataRefeicao()); ?></td>
                        <td><?php echo number_format($refeicao->calcularCaloriasTotais(), 0); ?> kcal</td>
                        <td>
                            <a href="../paginas/refeicoes.php?action=detalhes&id=<?php echo $refeicao->getId(); ?>" class="btn btn-secondary btn-sm">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhuma refeição registrada em <?php echo Funcoes::formatarData($selectedDate); ?>. <a href="../paginas/refeicoes.php">Adicionar refeição</a></p>
    <?php endif; ?>
</div>

<div class="card">
    <div class="date-navigation">
        <a href="?date=<?php echo date('Y-m-d', strtotime($selectedDate . ' -1 day')); ?>" class="btn btn-secondary">Dia Anterior</a>
        <a href="?date=<?php echo date('Y-m-d'); ?>" class="btn btn-primary">Hoje</a>
        <a href="?date=<?php echo date('Y-m-d', strtotime($selectedDate . ' +1 day')); ?>" class="btn btn-secondary">Próximo Dia</a>
        <form method="GET" style="display: inline-block; margin-left: 20px;">
            <input type="date" name="date" value="<?php echo $selectedDate; ?>" class="form-control" style="display: inline-block; width: auto;">
            <button type="submit" class="btn btn-info">Ir para Data</button>
        </form>
    </div>
    <h2>Controle de Calorias de <?php echo Funcoes::formatarData($selectedDate); ?></h2>
    <div class="calories-summary">
        <div class="calories-item">
            <span class="label">Consumidas (Refeições):</span>
            <span class="value"><?php echo number_format($caloriasConsumidas, 0); ?> kcal</span>
        </div>
        <div class="calories-item">
            <span class="label">Gastas (Treino):</span>
            <span class="value"><?php echo number_format($caloriasGastasTreino, 0); ?> kcal</span>
        </div>
        <div class="calories-item">
            <span class="label">Meta Diária:</span>
            <span class="value"><?php echo number_format($metaDiaria, 0); ?> kcal</span>
        </div>
        <div class="calories-item">
            <span class="label">Saldo Restante:</span>
            <span class="value <?php echo ($caloriasConsumidas - $caloriasGastasTreino) > $metaDiaria ? 'negative' : 'positive'; ?>">
                <?php echo number_format(max(0, $metaDiaria - ($caloriasConsumidas - $caloriasGastasTreino)), 0); ?> kcal
            </span>
        </div>
    </div>
    <canvas id="caloriesChart" width="400" height="200"></canvas>
</div>

<div class="card">
    <h2>Objetivos Ativos</h2>
    <?php if ($objetivosResposta->getSucesso() && !empty($objetivosResposta->getDados())): ?>
        <?php foreach ($objetivosResposta->getDados() as $objetivo): ?>
            <div class="goal-progress">
                <h4><?php echo ucfirst($objetivo['tipo']); ?> - Meta: <?php echo $objetivo['peso_alvo']; ?> kg</h4>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 0%;"></div>
                </div>
                <p>De <?php echo Funcoes::formatarData($objetivo['data_inicio']); ?> até <?php echo $objetivo['data_fim'] ? Funcoes::formatarData($objetivo['data_fim']) : 'Indefinido'; ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum objetivo definido. <a href="../paginas/objetivos.php">Definir objetivo</a></p>
    <?php endif; ?>
</div>

<style>
.calories-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.calories-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
    border: 1px solid #e9ecef;
}

.calories-item .label {
    font-weight: 500;
    color: #495057;
}

.calories-item .value {
    font-weight: bold;
    font-size: 1.1em;
}

.calories-item .value.positive {
    color: #28a745;
}

.calories-item .value.negative {
    color: #dc3545;
}

.date-navigation {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.date-navigation form {
    display: flex;
    align-items: center;
    gap: 10px;
}

.date-navigation input[type="date"] {
    padding: 8px 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
    background-color: #fff;
    color: #495057;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}

.date-navigation input[type="date"]:focus {
    border-color: #80bdff;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.date-navigation .btn-info {
    background-color: #17a2b8;
    border-color: #17a2b8;
    color: #fff;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
    transition: background-color 0.15s ease-in-out, border-color 0.15s ease-in-out;
}

.date-navigation .btn-info:hover {
    background-color: #138496;
    border-color: #117a8b;
    color: #fff;
    text-decoration: none;
}
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('caloriesChart').getContext('2d');
const caloriesChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Calorias Consumidas (Refeições)', 'Calorias Gastas (Treino)', 'Meta Diária'],
        datasets: [{
            label: 'Calorias',
            data: [<?php echo $caloriasConsumidas; ?>, <?php echo $caloriasGastasTreino; ?>, <?php echo $metaDiaria; ?>],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(75, 192, 192, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(75, 192, 192, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>

<?php include '../includes/rodape.php'; ?>
