<?php
require_once 'modelo/DAO/conexao.php';
require_once 'ajudantes/Funcoes.php';
require_once 'modelo/Objetivo.php';

$objetivo = Objetivo::buscarPorUsuarioId(1);
if ($objetivo) {
    echo 'Objetivo encontrado: ' . $objetivo->getCaloriasDiarias() . PHP_EOL;
} else {
    echo 'Nenhum objetivo encontrado' . PHP_EOL;
}
?>
