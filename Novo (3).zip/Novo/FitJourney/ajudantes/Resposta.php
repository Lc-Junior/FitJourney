<?php
/**
 * Classe auxiliar para respostas da API
 */
class Resposta {
    private $sucesso;
    private $mensagem;
    private $dados;

    public function __construct($sucesso = false, $mensagem = '', $dados = null) {
        $this->sucesso = $sucesso;
        $this->mensagem = $mensagem;
        $this->dados = $dados;
    }

    public function getSucesso() { return $this->sucesso; }
    public function setSucesso($sucesso) { $this->sucesso = $sucesso; }

    public function getMensagem() { return $this->mensagem; }
    public function setMensagem($mensagem) { $this->mensagem = $mensagem; }

    public function getDados() { return $this->dados; }
    public function setDados($dados) { $this->dados = $dados; }

    /**
     * Retorna a resposta como array
     */
    public function toArray() {
        return [
            'sucesso' => $this->sucesso,
            'mensagem' => $this->mensagem,
            'dados' => $this->dados
        ];
    }

    /**
     * Retorna a resposta como JSON
     */
    public function toJson() {
        header('Content-Type: application/json');
        echo json_encode($this->toArray());
    }

    /**
     * Resposta de sucesso
     */
    public static function sucesso($mensagem = 'Operação realizada com sucesso', $dados = null) {
        return new Resposta(true, $mensagem, $dados);
    }

    /**
     * Resposta de erro
     */
    public static function erro($mensagem = 'Erro na operação', $dados = null) {
        return new Resposta(false, $mensagem, $dados);
    }
}
?>
