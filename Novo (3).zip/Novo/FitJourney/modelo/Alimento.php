<?php
/**
 * Modelo para a entidade Alimento
 */
class Alimento {
    private $id;
    private $nome;
    private $calorias;
    private $proteinas;
    private $carboidratos;
    private $gorduras;

    public function __construct($nome = null, $calorias = null, $proteinas = null, $carboidratos = null, $gorduras = null) {
        $this->nome = $nome;
        $this->calorias = $calorias;
        $this->proteinas = $proteinas;
        $this->carboidratos = $carboidratos;
        $this->gorduras = $gorduras;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getNome() { return $this->nome; }
    public function setNome($nome) { $this->nome = $nome; }

    public function getCalorias() { return $this->calorias; }
    public function setCalorias($calorias) { $this->calorias = $calorias; }

    public function getProteinas() { return $this->proteinas; }
    public function setProteinas($proteinas) { $this->proteinas = $proteinas; }

    public function getCarboidratos() { return $this->carboidratos; }
    public function setCarboidratos($carboidratos) { $this->carboidratos = $carboidratos; }

    public function getGorduras() { return $this->gorduras; }
    public function setGorduras($gorduras) { $this->gorduras = $gorduras; }

    /**
     * Salva o alimento no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE alimentos SET nome = ?, calorias = ?, proteinas = ?, carboidratos = ?, gorduras = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->calorias, $this->proteinas, $this->carboidratos, $this->gorduras, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO alimentos (nome, calorias, proteinas, carboidratos, gorduras) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$this->nome, $this->calorias, $this->proteinas, $this->carboidratos, $this->gorduras]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca alimento por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM alimentos WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $alimento = new Alimento($dados['nome'], $dados['calorias'], $dados['proteinas'], $dados['carboidratos'], $dados['gorduras']);
            $alimento->setId($dados['id']);
            return $alimento;
        }
        return null;
    }

    /**
     * Busca alimentos por nome (parcial)
     */
    public static function buscarPorNome($nome) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM alimentos WHERE nome LIKE ? ORDER BY nome");
        $stmt->execute(['%' . $nome . '%']);
        $alimentos = [];
        while ($dados = $stmt->fetch()) {
            $alimento = new Alimento($dados['nome'], $dados['calorias'], $dados['proteinas'], $dados['carboidratos'], $dados['gorduras']);
            $alimento->setId($dados['id']);
            $alimentos[] = $alimento;
        }
        return $alimentos;
    }

    /**
     * Busca alimento por nome exato
     */
    public static function buscarPorNomeExato($nome) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM alimentos WHERE nome = ?");
        $stmt->execute([$nome]);
        $dados = $stmt->fetch();
        if ($dados) {
            $alimento = new Alimento($dados['nome'], $dados['calorias'], $dados['proteinas'], $dados['carboidratos'], $dados['gorduras']);
            $alimento->setId($dados['id']);
            return $alimento;
        }
        return null;
    }

    /**
     * Lista todos os alimentos
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM alimentos ORDER BY nome");
        $alimentos = [];
        while ($dados = $stmt->fetch()) {
            $alimento = new Alimento($dados['nome'], $dados['calorias'], $dados['proteinas'], $dados['carboidratos'], $dados['gorduras']);
            $alimento->setId($dados['id']);
            $alimentos[] = $alimento;
        }
        return $alimentos;
    }

    /**
     * Exclui o alimento
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM alimentos WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
