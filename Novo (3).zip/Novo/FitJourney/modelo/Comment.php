<?php
/**
 * Modelo para a entidade Comment (Comentário)
 */
class Comment {
    private $id;
    private $usuarioId;
    private $postId;
    private $texto;
    private $dataComentario;

    public function __construct($usuarioId = null, $postId = null, $texto = null) {
        $this->usuarioId = $usuarioId;
        $this->postId = $postId;
        $this->texto = $texto;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getPostId() { return $this->postId; }
    public function setPostId($postId) { $this->postId = $postId; }

    public function getTexto() { return $this->texto; }
    public function setTexto($texto) { $this->texto = $texto; }

    public function getDataComentario() { return $this->dataComentario; }
    public function setDataComentario($dataComentario) { $this->dataComentario = $dataComentario; }

    /**
     * Salva o comentário no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar (se necessário, mas comentários geralmente não são editados)
            return false;
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO comentarios (usuario_id, post_id, texto) VALUES (?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->postId, $this->texto]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Lista comentários de um post
     */
    public static function listarPorPost($postId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT c.*, u.nome AS nome_usuario FROM comentarios c JOIN usuarios u ON c.usuario_id = u.id WHERE c.post_id = ? ORDER BY c.data_comentario ASC");
        $stmt->execute([$postId]);
        $comentarios = [];
        while ($dados = $stmt->fetch()) {
            $comentario = new Comment($dados['usuario_id'], $dados['post_id'], $dados['texto']);
            $comentario->setId($dados['id']);
            $comentario->setDataComentario($dados['data_comentario']);
            $comentario->nomeUsuario = $dados['nome_usuario']; // Adiciona nome do usuário
            $comentarios[] = $comentario;
        }
        return $comentarios;
    }

    /**
     * Exclui o comentário (apenas se for do usuário)
     */
    public function excluir($usuarioId) {
        if ($this->usuarioId != $usuarioId) {
            return false; // Não é o dono
        }
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM comentarios WHERE id = ? AND usuario_id = ?");
        return $stmt->execute([$this->id, $usuarioId]);
    }
}
?>
