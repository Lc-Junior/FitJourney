<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleRefeicao.php';
require_once '../../controle/ControleAdmin.php';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    echo json_encode(['sucesso' => false, 'mensagem' => 'Usuário não logado.']);
    exit;
}

header('Content-Type: application/json');

$acao = $_POST['acao'] ?? '';

switch ($acao) {
    case 'sugerir_alimentos':
        $tipoRefeicao = $_POST['tipo_refeicao'] ?? '';

        if (empty($tipoRefeicao)) {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Tipo de refeição não informado.']);
            exit;
        }

        $controleRefeicao = new ControleRefeicao();
        $resposta = $controleRefeicao->sugerirAlimentos(['tipo_refeicao' => $tipoRefeicao]);

        echo json_encode([
            'sucesso' => $resposta->getSucesso(),
            'mensagem' => $resposta->getMensagem(),
            'dados' => $resposta->getDados()
        ]);
        break;

    case 'adicionar_alimento_sugerido':
        $nomeAlimento = $_POST['nome_alimento'] ?? '';
        $quantidade = $_POST['quantidade'] ?? '';
        $refeicaoId = $_POST['refeicao_id'] ?? '';

        if (empty($nomeAlimento) || empty($quantidade) || empty($refeicaoId)) {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Dados incompletos.']);
            exit;
        }

        $resposta = $controleRefeicao->adicionarAlimentoCustomizado($refeicaoId, $nomeAlimento, $quantidade);
        echo json_encode([
            'sucesso' => $resposta->getSucesso(),
            'mensagem' => $resposta->getMensagem(),
            'dados' => $resposta->getDados()
        ]);
        break;

    default:
        echo json_encode(['sucesso' => false, 'mensagem' => 'Ação inválida.']);
        break;
}
?>
