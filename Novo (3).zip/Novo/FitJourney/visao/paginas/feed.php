<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Post.php';
require_once '../../modelo/Like.php';
require_once '../../modelo/Comment.php';
require_once '../../controle/ControleFeed.php';

$titulo = 'Feed Social';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleFeed = new ControleFeed();
$mensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'criar_post':
                $resposta = $controleFeed->criarPost($_POST);
                $mensagem = $resposta->getMensagem();
                break;
            case 'editar_post':
                $resposta = $controleFeed->editarPost($_POST);
                $mensagem = $resposta->getMensagem();
                break;
            case 'excluir_post':
                $resposta = $controleFeed->excluirPost($_POST['post_id']);
                $mensagem = $resposta->getMensagem();
                break;
            case 'curtir':
                $resposta = $controleFeed->curtirPost($_POST['post_id']);
                $mensagem = $resposta->getMensagem();
                break;
            case 'comentar':
                $resposta = $controleFeed->comentarPost($_POST);
                $mensagem = $resposta->getMensagem();
                break;
            case 'excluir_comentario':
                $resposta = $controleFeed->excluirComentario($_POST['comentario_id']);
                $mensagem = $resposta->getMensagem();
                break;
        }
    }
}

// Obtém posts do feed
$posts = $controleFeed->exibirFeed();

include '../includes/cabecalho.php';
?>

<style>
.feed-post {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    overflow: hidden;
}

.feed-post-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid #eee;
}

.feed-post-header .user-info {
    display: flex;
    align-items: center;
}

.feed-post-header .user-avatar {
    width: 40px;
    height: 40px;
    background-color: #5DB075;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    margin-right: 10px;
}

.feed-post-content {
    padding: 15px;
}

.feed-post-image {
    max-width: 100%;
    height: auto;
    border-radius: 8px;
    margin-top: 10px;
}

.feed-post-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 15px;
    border-top: 1px solid #eee;
    background-color: #f8f9fa;
}

.feed-post-actions .left {
    display: flex;
    gap: 15px;
}

.like-btn {
    background: none;
    border: none;
    color: #666;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.9rem;
}

.like-btn.liked {
    color: #5DB075;
}

.comment-section {
    border-top: 1px solid #eee;
    padding: 15px;
    background-color: #f9f9f9;
}

.comment-item {
    margin-bottom: 10px;
    padding: 10px;
    background: white;
    border-radius: 5px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.comment-item .comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
}

.comment-item .comment-user {
    font-weight: bold;
    color: #5DB075;
}

.comment-item .comment-date {
    font-size: 0.8rem;
    color: #666;
}

.comment-form textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: vertical;
    min-height: 60px;
}

.create-post-form {
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    padding: 20px;
    margin-bottom: 30px;
}

.create-post-form textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: vertical;
    min-height: 80px;
    margin-bottom: 10px;
}

.edit-form {
    margin-top: 10px;
    padding: 10px;
    background-color: #f8f9fa;
    border-radius: 5px;
}

.edit-form textarea {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    resize: vertical;
    min-height: 60px;
    margin-bottom: 5px;
}
</style>

<div class="container">
    <h1>Feed Social</h1>

    <?php if ($mensagem): ?>
        <div class="alert <?php echo strpos($mensagem, 'sucesso') !== false ? 'alert-success' : 'alert-error'; ?>">
            <?php echo htmlspecialchars($mensagem); ?>
        </div>
    <?php endif; ?>

    <!-- Formulário para criar post -->
    <div class="create-post-form">
        <h2>Criar Novo Post</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="criar_post">
            <div class="form-group">
                <textarea name="texto" placeholder="O que você está pensando?" required></textarea>
            </div>
            <div class="form-group">
                <label for="foto">Adicionar foto (opcional):</label>
                <input type="file" name="foto" id="foto" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Publicar</button>
        </form>
    </div>

    <!-- Feed de posts -->
    <?php if (!empty($posts)): ?>
        <?php foreach ($posts as $post): ?>
            <div class="feed-post">
                <div class="feed-post-header">
                    <div class="user-info">
                        <div class="user-avatar"><?php echo strtoupper(substr($post->nomeUsuario, 0, 1)); ?></div>
                        <div>
                            <strong><?php echo htmlspecialchars($post->nomeUsuario); ?></strong>
                            <br>
                            <small><?php echo Funcoes::formatarData($post->getDataCriacao()); ?></small>
                        </div>
                    </div>
                    <?php if ($post->getUsuarioId() == Funcoes::getUsuarioLogadoId()): ?>
                        <div>
                            <button class="btn btn-secondary btn-sm" onclick="toggleEditForm(<?php echo $post->getId(); ?>)">Editar</button>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Tem certeza que deseja excluir este post?')">
                                <input type="hidden" name="action" value="excluir_post">
                                <input type="hidden" name="post_id" value="<?php echo $post->getId(); ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="feed-post-content">
                    <?php if ($post->getTexto()): ?>
                        <p><?php echo nl2br(htmlspecialchars($post->getTexto())); ?></p>
                    <?php endif; ?>
                    <?php if ($post->getFoto()): ?>
                        <img src="<?php echo htmlspecialchars($post->getFoto()); ?>" alt="Post image" class="feed-post-image">
                    <?php endif; ?>

                    <!-- Formulário de edição (inicialmente oculto) -->
                    <div id="edit-form-<?php echo $post->getId(); ?>" class="edit-form" style="display: none;">
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="editar_post">
                            <input type="hidden" name="post_id" value="<?php echo $post->getId(); ?>">
                            <textarea name="texto" required><?php echo htmlspecialchars($post->getTexto()); ?></textarea>
                            <input type="file" name="foto" accept="image/*">
                            <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="toggleEditForm(<?php echo $post->getId(); ?>)">Cancelar</button>
                        </form>
                    </div>
                </div>

                <div class="feed-post-actions">
                    <div class="left">
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="action" value="curtir">
                            <input type="hidden" name="post_id" value="<?php echo $post->getId(); ?>">
                            <button type="submit" class="like-btn <?php echo $post->curtiu ? 'liked' : ''; ?>">
                                👍 <?php echo $post->curtidas; ?> curtidas
                            </button>
                        </form>
                        <button class="btn btn-secondary btn-sm" onclick="toggleComments(<?php echo $post->getId(); ?>)">
                            💬 <?php echo count($post->comentarios); ?> comentários
                        </button>
                    </div>
                </div>

                <!-- Seção de comentários -->
                <div id="comments-<?php echo $post->getId(); ?>" class="comment-section" style="display: none;">
                    <?php if (!empty($post->comentarios)): ?>
                        <?php foreach ($post->comentarios as $comentario): ?>
                            <div class="comment-item">
                                <div class="comment-header">
                                    <span class="comment-user"><?php echo htmlspecialchars($comentario->nomeUsuario); ?></span>
                                    <span class="comment-date"><?php echo Funcoes::formatarData($comentario->getDataComentario()); ?></span>
                                    <?php if ($comentario->getUsuarioId() == Funcoes::getUsuarioLogadoId()): ?>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Excluir comentário?')">
                                            <input type="hidden" name="action" value="excluir_comentario">
                                            <input type="hidden" name="comentario_id" value="<?php echo $comentario->getId(); ?>">
                                            <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                                <p><?php echo nl2br(htmlspecialchars($comentario->getTexto())); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <!-- Formulário para adicionar comentário -->
                    <form method="POST" class="comment-form">
                        <input type="hidden" name="action" value="comentar">
                        <input type="hidden" name="post_id" value="<?php echo $post->getId(); ?>">
                        <textarea name="texto" placeholder="Escreva um comentário..." required></textarea>
                        <button type="submit" class="btn btn-primary btn-sm">Comentar</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="card">
            <p>Nenhum post ainda. Seja o primeiro a compartilhar algo!</p>
        </div>
    <?php endif; ?>
</div>

<script>
function toggleEditForm(postId) {
    const form = document.getElementById('edit-form-' + postId);
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function toggleComments(postId) {
    const comments = document.getElementById('comments-' + postId);
    comments.style.display = comments.style.display === 'none' ? 'block' : 'none';
}
</script>

<?php include '../includes/rodape.php'; ?>
