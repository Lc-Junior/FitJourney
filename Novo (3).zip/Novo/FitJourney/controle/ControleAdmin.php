<?php
/**
 * Controlador para funções administrativas
 */
class ControleAdmin {
    /**
     * Lista todos os usuários (admin)
     */
    public function listarUsuarios() {
        $usuarios = Usuario::listarTodos();
        $dados = [];

        foreach ($usuarios as $usuario) {
            $dados[] = [
                'id' => $usuario->getId(),
                'nome' => $usuario->getNome(),
                'email' => $usuario->getEmail(),
                'data_cadastro' => $usuario->getDataCadastro(),
                'ativo' => $usuario->getAtivo()
            ];
        }

        return Resposta::sucesso('Usuários listados com sucesso.', $dados);
    }

    /**
     * Ativa/desativa usuário (admin)
     */
    public function alterarStatusUsuario($usuarioId, $ativo) {
        $usuario = Usuario::buscarPorId($usuarioId);
        if (!$usuario) {
            return Resposta::erro('Usuário não encontrado.');
        }

        $usuario->setAtivo($ativo);
        if ($usuario->salvar()) {
            $status = $ativo ? 'ativado' : 'desativado';
            return Resposta::sucesso("Usuário $status com sucesso.");
        }

        return Resposta::erro('Erro ao alterar status do usuário.');
    }

    /**
     * Estatísticas gerais (admin)
     */
    public function getEstatisticas() {
        $pdo = Conexao::getInstancia()->getPDO();

        // Total de usuários
        $stmt = $pdo->query("SELECT COUNT(*) as total_usuarios FROM usuarios");
        $totalUsuarios = $stmt->fetch()['total_usuarios'];

        // Usuários ativos
        $stmt = $pdo->query("SELECT COUNT(*) as usuarios_ativos FROM usuarios WHERE ativo = TRUE");
        $usuariosAtivos = $stmt->fetch()['usuarios_ativos'];

        // Total de refeições
        $stmt = $pdo->query("SELECT COUNT(*) as total_refeicoes FROM refeicoes");
        $totalRefeicoes = $stmt->fetch()['total_refeicoes'];

        // Total de conquistas desbloqueadas
        $stmt = $pdo->query("SELECT COUNT(*) as conquistas_desbloqueadas FROM usuarios_conquistas");
        $conquistasDesbloqueadas = $stmt->fetch()['conquistas_desbloqueadas'];

        // Usuários cadastrados nos últimos 30 dias
        $stmt = $pdo->prepare("SELECT COUNT(*) as novos_usuarios FROM usuarios WHERE data_cadastro >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $stmt->execute();
        $novosUsuarios = $stmt->fetch()['novos_usuarios'];

        return Resposta::sucesso('Estatísticas obtidas com sucesso.', [
            'total_usuarios' => $totalUsuarios,
            'usuarios_ativos' => $usuariosAtivos,
            'total_refeicoes' => $totalRefeicoes,
            'conquistas_desbloqueadas' => $conquistasDesbloqueadas,
            'novos_usuarios_30_dias' => $novosUsuarios
        ]);
    }

    /**
     * Lista alimentos (admin)
     */
    public function listarAlimentos() {
        $alimentos = Alimento::listarTodos();
        $dados = [];

        foreach ($alimentos as $alimento) {
            $dados[] = [
                'id' => $alimento->getId(),
                'nome' => $alimento->getNome(),
                'calorias' => $alimento->getCalorias(),
                'proteinas' => $alimento->getProteinas(),
                'carboidratos' => $alimento->getCarboidratos(),
                'gorduras' => $alimento->getGorduras()
            ];
        }

        return Resposta::sucesso('Alimentos listados com sucesso.', $dados);
    }

    /**
     * Cadastra alimento (admin)
     */
    public function cadastrarAlimento($dados) {
        $validador = new Validador();
        $validador->naoVazio($dados['nome'] ?? '', 'nome');
        $validador->numerico($dados['calorias'] ?? '', 'calorias');
        $validador->positivo($dados['calorias'] ?? 0, 'calorias');

        if (isset($dados['proteinas'])) $validador->numerico($dados['proteinas'], 'proteínas');
        if (isset($dados['carboidratos'])) $validador->numerico($dados['carboidratos'], 'carboidratos');
        if (isset($dados['gorduras'])) $validador->numerico($dados['gorduras'], 'gorduras');

        if ($validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $validador->getErros()));
        }

        $alimento = new Alimento(
            $dados['nome'],
            $dados['calorias'],
            $dados['proteinas'] ?? 0,
            $dados['carboidratos'] ?? 0,
            $dados['gorduras'] ?? 0
        );

        if ($alimento->salvar()) {
            return Resposta::sucesso('Alimento cadastrado com sucesso.', ['id' => $alimento->getId()]);
        }

        return Resposta::erro('Erro ao cadastrar alimento.');
    }

    /**
     * Atualiza alimento (admin)
     */
    public function atualizarAlimento($id, $dados) {
        $alimento = Alimento::buscarPorId($id);
        if (!$alimento) {
            return Resposta::erro('Alimento não encontrado.');
        }

        $validador = new Validador();
        if (isset($dados['nome'])) $validador->naoVazio($dados['nome'], 'nome');
        if (isset($dados['calorias'])) {
            $validador->numerico($dados['calorias'], 'calorias');
            $validador->positivo($dados['calorias'], 'calorias');
        }
        if (isset($dados['proteinas'])) $validador->numerico($dados['proteinas'], 'proteínas');
        if (isset($dados['carboidratos'])) $validador->numerico($dados['carboidratos'], 'carboidratos');
        if (isset($dados['gorduras'])) $validador->numerico($dados['gorduras'], 'gorduras');

        if ($validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $validador->getErros()));
        }

        if (isset($dados['nome'])) $alimento->setNome($dados['nome']);
        if (isset($dados['calorias'])) $alimento->setCalorias($dados['calorias']);
        if (isset($dados['proteinas'])) $alimento->setProteinas($dados['proteinas']);
        if (isset($dados['carboidratos'])) $alimento->setCarboidratos($dados['carboidratos']);
        if (isset($dados['gorduras'])) $alimento->setGorduras($dados['gorduras']);

        if ($alimento->salvar()) {
            return Resposta::sucesso('Alimento atualizado com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar alimento.');
    }

    /**
     * Exclui alimento (admin)
     */
    public function excluirAlimento($id) {
        $alimento = Alimento::buscarPorId($id);
        if (!$alimento) {
            return Resposta::erro('Alimento não encontrado.');
        }

        if ($alimento->excluir()) {
            return Resposta::sucesso('Alimento excluído com sucesso.');
        }

        return Resposta::erro('Erro ao excluir alimento.');
    }

    /**
     * Cadastra alimento via API (admin)
     */
    public function cadastrarAlimentoViaAPI($dados) {
        $validador = new Validador();
        $validador->naoVazio($dados['descricao'] ?? '', 'descrição do alimento');

        if ($validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $validador->getErros()));
        }

        $apiNutricao = new ApiNutricao();
        $nutrientes = $apiNutricao->obterNutrientes($dados['descricao']);

        if (!$nutrientes) {
            return Resposta::erro('Não foi possível obter informações nutricionais da API para a descrição fornecida.');
        }

        // Verifica se o alimento já existe
        $alimentoExistente = Alimento::buscarPorNomeExato($nutrientes['nome']);
        if ($alimentoExistente) {
            return Resposta::erro('Alimento já cadastrado com este nome.');
        }

        $alimento = new Alimento(
            $nutrientes['nome'],
            $nutrientes['calorias'],
            $nutrientes['proteinas'],
            $nutrientes['carboidratos'],
            $nutrientes['gorduras']
        );

        if ($alimento->salvar()) {
            return Resposta::sucesso('Alimento cadastrado com sucesso via API.', [
                'id' => $alimento->getId(),
                'nutrientes' => $nutrientes
            ]);
        }

        return Resposta::erro('Erro ao cadastrar alimento.');
    }
}
?>
