<?php
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Alimento.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../ajudantes/ApiNutricao.php';

/**
 * Controlador para gerenciar refeições
 */
class ControleRefeicao {

    /**
     * Lista refeições do usuário logado
     */
    public function listar() {
        try {
            $usuarioId = $_SESSION['usuario_id'];
            $refeicoes = Refeicao::buscarPorUsuarioId($usuarioId);
            return new Resposta(true, 'Refeições listadas com sucesso', $refeicoes);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao listar refeições: ' . $e->getMessage());
        }
    }

    /**
     * Cadastra uma nova refeição
     */
    public function cadastrar($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'];

            // Validação básica
            if (empty($dados['tipo']) || empty($dados['data_refeicao'])) {
                return new Resposta(false, 'Tipo e data da refeição são obrigatórios');
            }

            $refeicao = new Refeicao(
                $usuarioId,
                $dados['tipo'],
                $dados['data_refeicao'],
                $dados['hora_refeicao'] ?? null
            );

            if ($refeicao->salvar()) {
                return new Resposta(true, 'Refeição criada com sucesso');
            } else {
                return new Resposta(false, 'Erro ao salvar refeição');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao criar refeição: ' . $e->getMessage());
        }
    }

    /**
     * Busca uma refeição por ID
     */
    public function buscarPorId($id) {
        try {
            $refeicao = Refeicao::buscarPorId($id);
            if ($refeicao && $refeicao->getUsuarioId() == $_SESSION['usuario_id']) {
                return new Resposta(true, 'Refeição encontrada', $refeicao);
            } else {
                return new Resposta(false, 'Refeição não encontrada');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao buscar refeição: ' . $e->getMessage());
        }
    }

    /**
     * Atualiza uma refeição
     */
    public function atualizar($dados) {
        try {
            if (empty($dados['id'])) {
                return new Resposta(false, 'ID da refeição é obrigatório');
            }

            $refeicao = Refeicao::buscarPorId($dados['id']);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            $refeicao->setTipo($dados['tipo'] ?? $refeicao->getTipo());
            $refeicao->setDataRefeicao($dados['data_refeicao'] ?? $refeicao->getDataRefeicao());
            $refeicao->setHoraRefeicao($dados['hora_refeicao'] ?? $refeicao->getHoraRefeicao());

            if ($refeicao->salvar()) {
                return new Resposta(true, 'Refeição atualizada com sucesso');
            } else {
                return new Resposta(false, 'Erro ao atualizar refeição');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao atualizar refeição: ' . $e->getMessage());
        }
    }

    /**
     * Exclui uma refeição
     */
    public function excluir($id) {
        try {
            $refeicao = Refeicao::buscarPorId($id);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            if ($refeicao->excluir()) {
                return new Resposta(true, 'Refeição excluída com sucesso');
            } else {
                return new Resposta(false, 'Erro ao excluir refeição');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao excluir refeição: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona um item à refeição
     */
    public function adicionarItem($dados) {
        try {
            if (empty($dados['refeicao_id']) || empty($dados['alimento_id']) || empty($dados['quantidade'])) {
                return new Resposta(false, 'Refeição, alimento e quantidade são obrigatórios');
            }

            $refeicao = Refeicao::buscarPorId($dados['refeicao_id']);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            $alimento = Alimento::buscarPorId($dados['alimento_id']);
            if (!$alimento) {
                return new Resposta(false, 'Alimento não encontrado');
            }

            if ($refeicao->adicionarItem($alimento, $dados['quantidade'])) {
                return new Resposta(true, 'Item adicionado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao adicionar item');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao adicionar item: ' . $e->getMessage());
        }
    }

    /**
     * Remove um item da refeição
     */
    public function removerItem($refeicaoId, $alimentoId) {
        try {
            $refeicao = Refeicao::buscarPorId($refeicaoId);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            if ($refeicao->removerItem($alimentoId)) {
                return new Resposta(true, 'Item removido com sucesso');
            } else {
                return new Resposta(false, 'Erro ao remover item');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao remover item: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona um alimento à refeição
     */
    public function adicionarAlimento($refeicaoId, $alimentoId, $quantidade) {
        return $this->adicionarItem(['refeicao_id' => $refeicaoId, 'alimento_id' => $alimentoId, 'quantidade' => $quantidade]);
    }

    /**
     * Remove um alimento da refeição
     */
    public function removerAlimento($refeicaoId, $alimentoId) {
        return $this->removerItem($refeicaoId, $alimentoId);
    }

    /**
     * Edita a quantidade de um alimento na refeição
     */
    public function editarAlimento($refeicaoId, $alimentoId, $quantidade) {
        try {
            $refeicao = Refeicao::buscarPorId($refeicaoId);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            if ($refeicao->editarItem($alimentoId, $quantidade)) {
                return new Resposta(true, 'Quantidade editada com sucesso');
            } else {
                return new Resposta(false, 'Erro ao editar quantidade');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao editar quantidade: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona um alimento customizado (da API) à refeição
     */
    public function adicionarAlimentoCustomizado($refeicaoId, $nomeAlimento, $quantidade, $unidade = 'g') {
        try {
            $refeicao = Refeicao::buscarPorId($refeicaoId);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            $apiNutricao = new ApiNutricao();
            $dadosAlimento = $apiNutricao->obterNutrientes($nomeAlimento, $quantidade, $unidade);

            if (!$dadosAlimento) {
                return new Resposta(false, 'Alimento não encontrado na API');
            }

            // Cria ou busca o alimento
            $alimento = Alimento::buscarPorNomeExato($dadosAlimento['nome']);
            if (!$alimento) {
                $alimento = new Alimento(
                    $dadosAlimento['nome'],
                    $dadosAlimento['calorias'],
                    $dadosAlimento['proteinas'] ?? 0,
                    $dadosAlimento['carboidratos'] ?? 0,
                    $dadosAlimento['gorduras'] ?? 0
                );
                $alimento->salvar();
            }

            if ($refeicao->adicionarItem($alimento, $quantidade)) {
                return new Resposta(true, 'Alimento customizado adicionado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao adicionar alimento customizado');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao adicionar alimento customizado: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona um alimento manual à refeição
     */
    public function adicionarAlimentoManual($refeicaoId, $nomeAlimento, $calorias, $proteinas, $carboidratos, $gorduras, $quantidade) {
        try {
            $refeicao = Refeicao::buscarPorId($refeicaoId);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            // Cria o alimento manual
            $alimento = new Alimento($nomeAlimento, $calorias, $proteinas, $carboidratos, $gorduras);
            $alimento->salvar();

            if ($refeicao->adicionarItem($alimento, $quantidade)) {
                return new Resposta(true, 'Alimento manual adicionado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao adicionar alimento manual');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao adicionar alimento manual: ' . $e->getMessage());
        }
    }

    /**
     * Obtém detalhes de uma refeição com itens
     */
    public function getDetalhes($id) {
        try {
            $refeicao = Refeicao::buscarPorId($id);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            $itens = $refeicao->getItens();

            return new Resposta(true, 'Detalhes obtidos com sucesso', [
                'refeicao' => [
                    'id' => $refeicao->getId(),
                    'tipo' => $refeicao->getTipo(),
                    'data_refeicao' => $refeicao->getDataRefeicao(),
                    'hora_refeicao' => $refeicao->getHoraRefeicao(),
                    'calorias_totais' => $refeicao->calcularCaloriasTotais()
                ],
                'itens' => array_map(function($item) {
                    return [
                        'alimento_id' => $item['alimento_id'],
                        'nome' => $item['nome'],
                        'quantidade' => $item['quantidade'],
                        'calorias' => $item['calorias'],
                        'proteinas' => $item['proteinas'],
                        'carboidratos' => $item['carboidratos'],
                        'gorduras' => $item['gorduras']
                    ];
                }, $itens)
            ]);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao obter detalhes: ' . $e->getMessage());
        }
    }

    /**
     * Sugere alimentos para uma refeição baseada nas calorias do objetivo
     */
    public function sugerirAlimentos($dados) {
        try {
            if (empty($dados['tipo_refeicao'])) {
                return new Resposta(false, 'Tipo de refeição é obrigatório');
            }

            $tipoRefeicao = $dados['tipo_refeicao'];
            $usuarioId = $_SESSION['usuario_id'];

            // Busca objetivo do usuário
            $objetivo = Objetivo::buscarPorUsuarioId($usuarioId);
            $caloriasDiarias = 2000; // default
            if ($objetivo) {
                if ($objetivo->getCaloriasDiarias()) {
                    $caloriasDiarias = $objetivo->getCaloriasDiarias();
                } else {
                    // Calcular calorias diárias baseadas no perfil e objetivo
                    $caloriasDiarias = $this->calcularCaloriasDiarias($usuarioId, $objetivo);
                }
            }

            // Define calorias por refeição (exemplo: café da manhã 25%, almoço 35%, jantar 30%, lanches 10% cada)
            $distribuicao = [
                'cafe_manha' => 0.25,
                'almoco' => 0.35,
                'jantar' => 0.30,
                'lanche' => 0.10
            ];

            $caloriasRefeicao = $caloriasDiarias * $distribuicao[$tipoRefeicao];

            // Lista de alimentos comuns para sugestão (pode ser expandida)
            $alimentosComuns = [
                ['nome' => 'Arroz cozido', 'calorias' => 130],
                ['nome' => 'Frango grelhado', 'calorias' => 165],
                ['nome' => 'Peito de frango', 'calorias' => 165],
                ['nome' => 'Batata doce', 'calorias' => 86],
                ['nome' => 'Aveia', 'calorias' => 379],
                ['nome' => 'Banana', 'calorias' => 89],
                ['nome' => 'Maçã', 'calorias' => 52],
                ['nome' => 'Pão integral', 'calorias' => 247],
                ['nome' => 'Queijo cottage', 'calorias' => 98],
                ['nome' => 'Iogurte natural', 'calorias' => 61],
                ['nome' => 'Ovo cozido', 'calorias' => 155],
                ['nome' => 'Salmão', 'calorias' => 208],
                ['nome' => 'Brócolis', 'calorias' => 34],
                ['nome' => 'Abacate', 'calorias' => 160],
                ['nome' => 'Amêndoas', 'calorias' => 579]
            ];

            // Algoritmo simples de sugestão: combina alimentos para chegar próximo das calorias
            $sugestoes = $this->gerarSugestoes($alimentosComuns, $caloriasRefeicao);

            return new Resposta(true, 'Sugestões geradas com sucesso', [
                'calorias_objetivo' => round($caloriasRefeicao),
                'calorias_totais_sugeridas' => array_sum(array_column($sugestoes, 'calorias')),
                'sugestoes' => $sugestoes
            ]);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao sugerir alimentos: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona um alimento sugerido diretamente à refeição
     */
    public function adicionarSugestao($dados) {
        try {
            if (empty($dados['refeicao_id']) || empty($dados['alimento_nome']) || empty($dados['quantidade'])) {
                return new Resposta(false, 'Refeição, nome do alimento e quantidade são obrigatórios');
            }

            $refeicao = Refeicao::buscarPorId($dados['refeicao_id']);
            if (!$refeicao || $refeicao->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Refeição não encontrada');
            }

            // Busca ou cria o alimento
            $alimento = Alimento::buscarPorNomeExato($dados['alimento_nome']);
            if (!$alimento) {
                // Tenta buscar na API de nutrição
                $apiNutricao = new ApiNutricao();
                $dadosAlimento = $apiNutricao->obterNutrientes($dados['alimento_nome']);
                if ($dadosAlimento) {
                    $alimento = new Alimento(
                        $dadosAlimento['nome'],
                        $dadosAlimento['calorias'],
                        $dadosAlimento['proteinas'] ?? 0,
                        $dadosAlimento['carboidratos'] ?? 0,
                        $dadosAlimento['gorduras'] ?? 0
                    );
                    $alimento->salvar();
                } else {
                    return new Resposta(false, 'Alimento não encontrado na base de dados ou API');
                }
            }

            if ($refeicao->adicionarItem($alimento, $dados['quantidade'])) {
                return new Resposta(true, 'Alimento sugerido adicionado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao adicionar alimento sugerido');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao adicionar sugestão: ' . $e->getMessage());
        }
    }

    /**
     * Calcula calorias diárias baseadas no perfil e objetivo
     */
    private function calcularCaloriasDiarias($usuarioId, $objetivo) {
        // Busca perfil do usuário
        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil) {
            return 2000; // Valor padrão
        }

        // Cálculo básico de TMB (Taxa Metabólica Basal) usando fórmula de Mifflin-St Jeor
        $idade = $perfil->getIdade();
        $peso = $perfil->getPeso();
        $altura = $perfil->getAltura();
        $sexo = $perfil->getSexo();
        $atividade = $perfil->getNivelAtividade();

        if ($sexo == 'masculino') {
            $tmb = 10 * $peso + 6.25 * $altura - 5 * $idade + 5;
        } else {
            $tmb = 10 * $peso + 6.25 * $altura - 5 * $idade - 161;
        }

        // Multiplicador de atividade
        $multiplicadores = [
            'sedentario' => 1.2,
            'leve' => 1.375,
            'moderado' => 1.55,
            'ativo' => 1.725,
            'muito_ativo' => 1.9
        ];

        $tdee = $tmb * ($multiplicadores[$atividade] ?? 1.2);

        // Ajusta baseado no objetivo
        $tipoObjetivo = $objetivo->getTipo();
        if ($tipoObjetivo == 'emagrecimento') {
            return $tdee - 500; // Déficit de 500 calorias
        } elseif ($tipoObjetivo == 'ganho_massa') {
            return $tdee + 300; // Superávit de 300 calorias
        } else {
            return $tdee; // Manutenção
        }
    }

    /**
     * Gera sugestões de alimentos baseadas nas calorias alvo
     */
    private function gerarSugestoes($alimentos, $caloriasAlvo) {
        $sugestoes = [];
        $caloriasAcumuladas = 0;

        // Algoritmo simples: adiciona alimentos até chegar próximo do alvo
        shuffle($alimentos); // Randomiza para variar sugestões

        foreach ($alimentos as $alimento) {
            if ($caloriasAcumuladas >= $caloriasAlvo) break;

            // Calcula quantidade aproximada (exemplo: 100g para carboidratos, 150g para proteínas)
            $quantidade = 100; // gramas
            $caloriasItem = ($alimento['calorias'] / 100) * $quantidade;

            if ($caloriasAcumuladas + $caloriasItem <= $caloriasAlvo + 50) { // Permite um pouco acima
                $sugestoes[] = [
                    'nome' => $alimento['nome'],
                    'quantidade' => $quantidade,
                    'calorias' => round($caloriasItem)
                ];
                $caloriasAcumuladas += $caloriasItem;
            }
        }

        return $sugestoes;
    }
}
?>
