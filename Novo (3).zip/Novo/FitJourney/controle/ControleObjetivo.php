<?php
/**
 * Controlador para objetivos
 */
class ControleObjetivo {
    private $validador;

    public function __construct() {
        $this->validador = new Validador();
    }

    /**
     * Lista objetivos do usuário
     */
    public function listar() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $objetivo = Objetivo::buscarPorUsuarioId($usuarioId);
        $dados = [];

        if ($objetivo) {
            $dados[] = [
                'id' => $objetivo->getId(),
                'tipo' => $objetivo->getTipo(),
                'peso_alvo' => $objetivo->getPesoAlvo(),
                'data_inicio' => $objetivo->getDataInicio(),
                'data_fim' => $objetivo->getDataFim()
            ];
        }

        return Resposta::sucesso('Objetivos listados com sucesso.', $dados);
    }

    /**
     * Cadastra novo objetivo
     */
    public function cadastrar($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Validações
        $this->validador->naoVazio($dados['tipo'] ?? '', 'tipo');
        $this->validador->numerico($dados['peso_alvo'] ?? '', 'peso alvo');
        $this->validador->positivo($dados['peso_alvo'] ?? 0, 'peso alvo');

        $tipos = ['emagrecimento', 'manutencao', 'ganho_massa'];
        if (isset($dados['tipo'])) {
            $this->validador->emLista($dados['tipo'], 'tipo', $tipos);
        }

        if (isset($dados['data_inicio']) && !empty($dados['data_inicio'])) {
            $this->validador->data($dados['data_inicio'], 'data de início');
        }

        if (isset($dados['data_fim']) && !empty($dados['data_fim'])) {
            $this->validador->data($dados['data_fim'], 'data de fim');
        }

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $objetivo = new Objetivo($usuarioId, $dados['tipo'], $dados['peso_alvo'], $dados['data_inicio'] ?? date('Y-m-d'), $dados['data_fim'] ?? null);
        $objetivo->setCaloriasDiarias($dados['calorias_diarias'] ?? null);
        if ($objetivo->salvar()) {
            return Resposta::sucesso('Objetivo cadastrado com sucesso.', ['id' => $objetivo->getId()]);
        }

        return Resposta::erro('Erro ao cadastrar objetivo.');
    }

    /**
     * Atualiza objetivo
     */
    public function atualizar($id, $dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $objetivo = Objetivo::buscarPorId($id);
        if (!$objetivo || $objetivo->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Objetivo não encontrado.');
        }

        // Validações
        if (isset($dados['tipo'])) {
            $tipos = ['emagrecimento', 'manutencao', 'ganho_massa'];
            $this->validador->emLista($dados['tipo'], 'tipo', $tipos);
        }

        if (isset($dados['peso_alvo'])) {
            $this->validador->numerico($dados['peso_alvo'], 'peso alvo');
            $this->validador->positivo($dados['peso_alvo'], 'peso alvo');
        }

        if (isset($dados['data_inicio']) && !empty($dados['data_inicio'])) {
            $this->validador->data($dados['data_inicio'], 'data de início');
        }

        if (isset($dados['data_fim']) && !empty($dados['data_fim'])) {
            $this->validador->data($dados['data_fim'], 'data de fim');
        }

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        if (isset($dados['tipo'])) $objetivo->setTipo($dados['tipo']);
        if (isset($dados['peso_alvo'])) $objetivo->setPesoAlvo($dados['peso_alvo']);
        if (isset($dados['data_inicio'])) $objetivo->setDataInicio($dados['data_inicio']);
        if (isset($dados['data_fim'])) $objetivo->setDataFim($dados['data_fim']);

        if ($objetivo->salvar()) {
            return Resposta::sucesso('Objetivo atualizado com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar objetivo.');
    }

    /**
     * Exclui objetivo
     */
    public function excluir($id) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $objetivo = Objetivo::buscarPorId($id);
        if (!$objetivo || $objetivo->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Objetivo não encontrado.');
        }

        if ($objetivo->excluir()) {
            return Resposta::sucesso('Objetivo excluído com sucesso.');
        }

        return Resposta::erro('Erro ao excluir objetivo.');
    }

    /**
     * Calcula sugestão de dieta baseada no perfil e objetivo
     */
    public function sugerirDieta() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Obtém perfil
        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil || !$perfil->getAltura() || !$perfil->getPeso() || !$perfil->getIdade() || !$perfil->getSexo()) {
            return Resposta::erro('Perfil incompleto para sugerir dieta.');
        }

        // Obtém objetivo ativo
        $objetivoAtivo = Objetivo::buscarPorUsuarioId($usuarioId);

        if (!$objetivoAtivo) {
            return Resposta::erro('Nenhum objetivo ativo encontrado.');
        }

        // Calcula calorias necessárias
        $tmb = Funcoes::calcularTMB($perfil->getPeso(), $perfil->getAltura(), $perfil->getIdade(), $perfil->getSexo());
        $tdee = Funcoes::calcularTDEE($tmb, $perfil->getNivelAtividade());
        $caloriasObjetivo = Funcoes::calcularCaloriasObjetivo($tdee, $objetivoAtivo->getTipo());

        // Sugestão básica de macronutrientes
        $proteinas = round($caloriasObjetivo * 0.25 / 4); // 25% das calorias de proteínas
        $carboidratos = round($caloriasObjetivo * 0.50 / 4); // 50% de carboidratos
        $gorduras = round($caloriasObjetivo * 0.25 / 9); // 25% de gorduras

        return Resposta::sucesso('Sugestão de dieta calculada com sucesso.', [
            'calorias_totais' => round($caloriasObjetivo),
            'macronutrientes' => [
                'proteinas_g' => $proteinas,
                'carboidratos_g' => $carboidratos,
                'gorduras_g' => $gorduras
            ],
            'distribuicao' => [
                'cafe_manha' => round($caloriasObjetivo * 0.25),
                'almoco' => round($caloriasObjetivo * 0.35),
                'jantar' => round($caloriasObjetivo * 0.30),
                'lanches' => round($caloriasObjetivo * 0.10)
            ]
        ]);
    }
}
?>
