<?php
class ControladorNotificacao {
    private $modelo;
    public function __construct(){ $this->modelo = new Notificacao(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function enviar(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        if(empty($entrada['titulo']) || empty($entrada['mensagem'])) Resposta::erro('titulo e mensagem obrigatórios',422);
        $nid = $this->modelo->enviar($id,$entrada['titulo'],$entrada['mensagem'],$entrada['tipo'] ?? 'motivacional');
        Resposta::json(['mensagem'=>'Notificação salva','id_notificacao'=>$nid],201);
    }
    public function listar(){
        $id = $this->requerAut();
        $lista = $this->modelo->listarPorUsuario($id);
        Resposta::json($lista);
    }
}
