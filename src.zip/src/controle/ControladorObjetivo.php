<?php
class ControladorObjetivo {
    private $modelo;
    public function __construct(){ $this->modelo = new Objetivo(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function criar(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        $oid = $this->modelo->criar($id,$entrada);
        Resposta::json(['mensagem'=>'Objetivo criado','id_objetivo'=>$oid],201);
    }
}
