<?php
class ControladorPerfil {
    private $modeloPerfil, $modeloMedida;
    public function __construct(){
        $this->modeloPerfil = new Perfil();
        $this->modeloMedida = new Medida();
    }
    private function obterUsuario(){
        return ControladorAutenticacao::requerAutenticacao();
    }
    public function verPerfil(){
        $id = $this->obterUsuario();
        $perfil = $this->modeloPerfil->obterPorUsuario($id);
        $medidas = $this->modeloMedida->listarPorUsuario($id);
        Resposta::json(['perfil'=>$perfil,'medidas'=>$medidas]);
    }
    public function atualizarPerfil(){
        $id = $this->obterUsuario();
        $entrada = json_decode(file_get_contents('php://input'), true);
        $this->modeloPerfil->criarOuAtualizar($id,$entrada);
        Resposta::json(['mensagem'=>'Perfil atualizado']);
    }
}
