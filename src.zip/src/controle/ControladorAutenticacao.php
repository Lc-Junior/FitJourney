<?php
class ControladorAutenticacao {
    private $modeloUsuario;
    public function __construct(){ $this->modeloUsuario = new Usuario(); }

    public function registrar(){
        $entrada = json_decode(file_get_contents('php://input'), true);
        if(empty($entrada['nome']) || empty($entrada['email']) || empty($entrada['senha'])) {
            Resposta::erro('nome, e-mail e senha são obrigatórios', 422);
        }
        if(!Validador::emailValido($entrada['email'])) Resposta::erro('E-mail inválido',422);
        if(!Validador::senhaForte($entrada['senha'])) Resposta::erro('Senha muito fraca (mínimo 6 caracteres)',422);
        try {
            $id = $this->modeloUsuario->criarUsuario($entrada['nome'],$entrada['email'],$entrada['senha']);
            Resposta::json(['mensagem'=>'Usuário criado com sucesso','id_usuario'=>$id],201);
        } catch (Exception $e){
            Resposta::erro($e->getMessage(),400);
        }
    }

    public function entrar(){
        $entrada = json_decode(file_get_contents('php://input'), true);
        if(empty($entrada['email']) || empty($entrada['senha'])) Resposta::erro('email e senha são obrigatórios',422);
        $user = $this->modeloUsuario->buscarPorEmail($entrada['email']);
        if(!$user) Resposta::erro('Credenciais inválidas',401);
        if(!password_verify($entrada['senha'],$user['senha_hash'])) Resposta::erro('Credenciais inválidas',401);
        // autentica via sessão
        $_SESSION['id_usuario'] = $user['id_usuario'];
        Resposta::json(['mensagem'=>'Autenticado','session_id'=>session_id(),'id_usuario'=>$user['id_usuario']]);
    }

    public static function requerAutenticacao(){
        if(empty($_SESSION['id_usuario'])) Resposta::erro('Não autenticado',401);
        return $_SESSION['id_usuario'];
    }
}
