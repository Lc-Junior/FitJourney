<?php
class ControladorDispositivo {
    private $modelo;
    public function __construct(){ $this->modelo = new Dispositivo(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function sincronizar(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        $this->modelo->adicionar($id,$entrada);
        Resposta::json(['mensagem'=>'Dados sincronizados']);
    }
}
