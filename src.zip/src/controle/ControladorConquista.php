<?php
class ControladorConquista {
    private $modelo;
    public function __construct(){ $this->modelo = new Conquista(); }
    private function requerAut(){ return ControladorAutenticacao::requerAutenticacao(); }
    public function listar(){
        $lista = $this->modelo->listar();
        Resposta::json($lista);
    }
    public function atribuir(){
        $id = $this->requerAut();
        $entrada = json_decode(file_get_contents('php://input'), true);
        if(empty($entrada['id_conquista'])) Resposta::erro('id_conquista obrigatório',422);
        $this->modelo->atribuir($id,$entrada['id_conquista']);
        Resposta::json(['mensagem'=>'Conquista atribuída']);
    }
}
