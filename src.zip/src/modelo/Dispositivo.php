<?php
class Dispositivo {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function adicionar($id_usuario,$dados){
        $stmt = $this->pdo->prepare('INSERT INTO dados_dispositivo (id_usuario,passos,calorias_gastas,minutos_exercicio,data_registro) VALUES (?,?,?,?,?)');
        $stmt->execute([$id_usuario,$dados['passos'],$dados['calorias_gastas'],$dados['minutos_exercicio'],$dados['data_registro']]);
        return $this->pdo->lastInsertId();
    }
    public function listarPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT * FROM dados_dispositivo WHERE id_usuario = ? ORDER BY data_registro DESC');
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll();
    }
}
