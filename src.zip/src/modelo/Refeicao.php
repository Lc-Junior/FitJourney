<?php
class Refeicao {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function criar($id_usuario,$dados){
        $stmt = $this->pdo->prepare('INSERT INTO refeicoes (id_usuario,data_refeicao,tipo,observacoes) VALUES (?,?,?,?)');
        $stmt->execute([$id_usuario,$dados['data_refeicao'],$dados['tipo'],$dados['observacoes']]);
        return $this->pdo->lastInsertId();
    }
    public function adicionarItem($id_refeicao,$item){
        $stmt = $this->pdo->prepare('INSERT INTO itens_refeicao (id_refeicao,id_alimento,quantidade) VALUES (?,?,?)');
        $stmt->execute([$id_refeicao,$item['id_alimento'],$item['quantidade']]);
        return $this->pdo->lastInsertId();
    }
    public function listarPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT r.*, (SELECT SUM(a.calorias * ir.quantidade / 100) FROM itens_refeicao ir JOIN alimentos a ON a.id_alimento = ir.id_alimento WHERE ir.id_refeicao = r.id_refeicao) AS total_calorias FROM refeicoes r WHERE r.id_usuario = ? ORDER BY data_refeicao DESC');
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll();
    }
}
