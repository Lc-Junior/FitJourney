<?php
class Usuario {
    private $pdo;
    public function __construct(){
        $this->pdo = BancoDeDados::obterConexao();
    }
    public function criarUsuario($nome, $email, $senha_plain){
        // validar email existente
        $stmt = $this->pdo->prepare('SELECT id_usuario FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        if($stmt->fetch()) throw new Exception('E-mail já cadastrado');

        // criptografar senha
        $hash = password_hash($senha_plain, PASSWORD_DEFAULT);
        $stmt = $this->pdo->prepare('INSERT INTO usuarios (nome,email,senha_hash) VALUES (?,?,?)');
        $stmt->execute([$nome,$email,$hash]);
        return $this->pdo->lastInsertId();
    }
    public function buscarPorEmail($email){
        $stmt = $this->pdo->prepare('SELECT * FROM usuarios WHERE email = ?');
        $stmt->execute([$email]);
        return $stmt->fetch();
    }
    public function buscarPorId($id){
        $stmt = $this->pdo->prepare('SELECT * FROM usuarios WHERE id_usuario = ?');
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}
