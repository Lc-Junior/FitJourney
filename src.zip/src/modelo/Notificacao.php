<?php
class Notificacao {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function enviar($id_usuario,$titulo,$mensagem,$tipo='motivacional'){
        $stmt = $this->pdo->prepare('INSERT INTO notificacoes (id_usuario,titulo,mensagem,tipo) VALUES (?,?,?,?)');
        $stmt->execute([$id_usuario,$titulo,$mensagem,$tipo]);
        return $this->pdo->lastInsertId();
    }
    public function listarPorUsuario($id_usuario){
        $stmt = $this->pdo->prepare('SELECT * FROM notificacoes WHERE id_usuario = ? ORDER BY data_envio DESC');
        $stmt->execute([$id_usuario]);
        return $stmt->fetchAll();
    }
}
