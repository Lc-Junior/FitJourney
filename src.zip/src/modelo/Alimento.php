<?php
class Alimento {
    private $pdo;
    public function __construct(){ $this->pdo = BancoDeDados::obterConexao(); }
    public function criar($dados){
        $stmt = $this->pdo->prepare('INSERT INTO alimentos (nome,porcao_g,calorias,proteinas_g,carboidratos_g,gorduras_g,criado_por) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$dados['nome'],$dados['porcao_g'],$dados['calorias'],$dados['proteinas_g'],$dados['carboidratos_g'],$dados['gorduras_g'],$dados['criado_por']]);
        return $this->pdo->lastInsertId();
    }
    public function listar(){
        $stmt = $this->pdo->query('SELECT * FROM alimentos ORDER BY nome');
        return $stmt->fetchAll();
    }
}
