<?php
class Validador {
    public static function emailValido($email){
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    public static function senhaForte($senha){
        return strlen($senha) >= 6;
    }
}
