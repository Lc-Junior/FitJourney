-- Script SQL para criar o banco de dados FitJourney

CREATE DATABASE IF NOT EXISTS fitjourney;
USE fitjourney;

-- Tabela de usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de perfis
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    idade INT,
    sexo ENUM('masculino', 'feminino', 'outro'),
    altura DECIMAL(5,2), -- em cm
    peso DECIMAL(5,2), -- em kg
    nivel_atividade ENUM('sedentario', 'leve', 'moderado', 'ativo', 'muito_ativo'),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de medidas
CREATE TABLE medidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_medida DATE NOT NULL,
    peso DECIMAL(5,2),
    cintura DECIMAL(5,2),
    quadril DECIMAL(5,2),
    peito DECIMAL(5,2),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de objetivos
CREATE TABLE objetivos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('emagrecimento', 'manutencao', 'ganho_massa'),
    peso_alvo DECIMAL(5,2),
    data_inicio DATE,
    data_fim DATE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de alimentos
CREATE TABLE alimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    calorias DECIMAL(6,2) NOT NULL, -- por 100g
    proteinas DECIMAL(5,2),
    carboidratos DECIMAL(5,2),
    gorduras DECIMAL(5,2)
);

-- Tabela de refeições
CREATE TABLE refeicoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('cafe_manha', 'almoco', 'jantar', 'lanche'),
    data_refeicao DATE NOT NULL,
    hora_refeicao TIME,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de itens de refeição
CREATE TABLE itens_refeicao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    refeicao_id INT NOT NULL,
    alimento_id INT NOT NULL,
    quantidade DECIMAL(6,2), -- em gramas
    FOREIGN KEY (refeicao_id) REFERENCES refeicoes(id) ON DELETE CASCADE,
    FOREIGN KEY (alimento_id) REFERENCES alimentos(id) ON DELETE CASCADE
);

-- Tabela de dados de dispositivo
CREATE TABLE dados_dispositivo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_dados DATE NOT NULL,
    passos INT,
    calorias_queimadas DECIMAL(6,2),
    tempo_exercicio INT, -- em minutos
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de conquistas
CREATE TABLE conquistas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    criterio VARCHAR(255), -- condição para desbloquear
    xp INT DEFAULT 0
);

-- Tabela de conquistas dos usuários
CREATE TABLE usuarios_conquistas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    conquista_id INT NOT NULL,
    data_conquista TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (conquista_id) REFERENCES conquistas(id) ON DELETE CASCADE
);

-- Tabela de notificações
CREATE TABLE notificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(100) NOT NULL,
    mensagem TEXT,
    tipo ENUM('lembrete', 'alerta', 'conquista'),
    lida BOOLEAN DEFAULT FALSE,
    data_notificacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Inserir algumas conquistas padrão
INSERT INTO conquistas (nome, descricao, criterio, xp) VALUES
('Primeiro Passo', 'Realizou o primeiro registro no sistema', 'primeiro_login', 10),
('10k Passos', 'Andou 10.000 passos em um dia', 'passos >= 10000', 50),
('Primeira Refeição', 'Registrou a primeira refeição', 'primeira_refeicao', 20),
('Objetivo Alcançado', 'Alcançou um objetivo definido', 'objetivo_concluido', 100);

-- Inserir alguns alimentos padrão
INSERT INTO alimentos (nome, calorias, proteinas, carboidratos, gorduras) VALUES
('Arroz Branco', 130, 2.7, 28, 0.3),
('Frango Grelhado', 165, 31, 0, 3.6),
('Banana', 89, 1.1, 23, 0.3),
('Leite Desnatado', 34, 3.4, 5, 0.1);

-- Tabela de posts para o feed social
CREATE TABLE posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    texto TEXT,
    foto VARCHAR(255), -- caminho para a foto, opcional
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de curtidas nos posts
CREATE TABLE curtidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    post_id INT NOT NULL,
    data_curtida TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
    UNIQUE KEY unique_curtida (usuario_id, post_id) -- impede curtidas duplicadas
);

-- Tabela de comentários nos posts
CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    post_id INT NOT NULL,
    texto TEXT NOT NULL,
    data_comentario TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
);

-- Tabela de treinos
CREATE TABLE treinos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    data_treino DATE NOT NULL,
    duracao INT, -- em minutos
    exercicios JSON, -- lista de exercícios em formato JSON
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
