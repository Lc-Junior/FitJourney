# TODO - Implementar Página de Treinos no FitJourney

## Tarefas Pendentes
- [x] Atualizar fitjourney.sql: Adicionar tabela 'treinos' com campos id, usuario_id, nome, descricao, data_treino, duracao, exercicios (JSON ou texto).
- [x] Criar modelo/Treino.php: Classe para gerenciar treinos no banco de dados.
- [x] Criar controle/ControleTreino.php: Controlador para lógica de negócio dos treinos (listar, criar, editar, deletar).
- [x] Criar ajudantes/ApiTreino.php: Classe para integrar API de sugestões de treino (ex.: ExerciseDB API, baseada em perfil do usuário).
- [x] Criar visao/paginas/treinos.php: Página para exibir treinos do usuário, adicionar novos treinos e mostrar sugestões via API.
- [x] Atualizar visao/includes/cabecalho.php: Adicionar link "Treinos" no menu de navegação.
- [x] Testar: Executar servidor local e verificar funcionalidade da página de treinos.

## Notas
- Usar API gratuita como ExerciseDB (https://exercisedb.p.rapidapi.com) para sugestões de exercícios.
- Sugestões baseadas em perfil: idade, sexo, nível de atividade.
- Estrutura similar às outras páginas (ex.: refeicoes.php).
- Servidor local iniciado em http://localhost:8000 para testes.
