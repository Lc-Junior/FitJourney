<?php
/**
 * Modelo para a entidade Refeicao
 */
class Refeicao {
    private $id;
    private $usuarioId;
    private $tipo;
    private $dataRefeicao;
    private $horaRefeicao;

    public function __construct($usuarioId = null, $tipo = null, $dataRefeicao = null, $horaRefeicao = null) {
        $this->usuarioId = $usuarioId;
        $this->tipo = $tipo;
        $this->dataRefeicao = $dataRefeicao;
        $this->horaRefeicao = $horaRefeicao;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getTipo() { return $this->tipo; }
    public function setTipo($tipo) { $this->tipo = $tipo; }

    public function getDataRefeicao() { return $this->dataRefeicao; }
    public function setDataRefeicao($dataRefeicao) { $this->dataRefeicao = $dataRefeicao; }

    public function getHoraRefeicao() { return $this->horaRefeicao; }
    public function setHoraRefeicao($horaRefeicao) { $this->horaRefeicao = $horaRefeicao; }

    /**
     * Salva a refeição no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE refeicoes SET tipo = ?, data_refeicao = ?, hora_refeicao = ? WHERE id = ?");
            return $stmt->execute([$this->tipo, $this->dataRefeicao, $this->horaRefeicao, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO refeicoes (usuario_id, tipo, data_refeicao, hora_refeicao) VALUES (?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->tipo, $this->dataRefeicao, $this->horaRefeicao]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca refeições por ID do usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM refeicoes WHERE usuario_id = ? ORDER BY data_refeicao DESC, hora_refeicao DESC");
        $stmt->execute([$usuarioId]);
        $refeicoes = [];
        while ($dados = $stmt->fetch()) {
            $refeicao = new Refeicao($dados['usuario_id'], $dados['tipo'], $dados['data_refeicao'], $dados['hora_refeicao']);
            $refeicao->setId($dados['id']);
            $refeicoes[] = $refeicao;
        }
        return $refeicoes;
    }

    /**
     * Busca refeições por data e usuário
     */
    public static function buscarPorDataEUsuario($data, $usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM refeicoes WHERE data_refeicao = ? AND usuario_id = ? ORDER BY hora_refeicao");
        $stmt->execute([$data, $usuarioId]);
        $refeicoes = [];
        while ($dados = $stmt->fetch()) {
            $refeicao = new Refeicao($dados['usuario_id'], $dados['tipo'], $dados['data_refeicao'], $dados['hora_refeicao']);
            $refeicao->setId($dados['id']);
            $refeicoes[] = $refeicao;
        }
        return $refeicoes;
    }

    /**
     * Lista todas as refeições
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM refeicoes ORDER BY data_refeicao DESC, hora_refeicao DESC");
        $refeicoes = [];
        while ($dados = $stmt->fetch()) {
            $refeicao = new Refeicao($dados['usuario_id'], $dados['tipo'], $dados['data_refeicao'], $dados['hora_refeicao']);
            $refeicao->setId($dados['id']);
            $refeicoes[] = $refeicao;
        }
        return $refeicoes;
    }

    /**
     * Busca refeição por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM refeicoes WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $refeicao = new Refeicao($dados['usuario_id'], $dados['tipo'], $dados['data_refeicao'], $dados['hora_refeicao']);
            $refeicao->setId($dados['id']);
            return $refeicao;
        }
        return null;
    }

    /**
     * Exclui a refeição
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM refeicoes WHERE id = ?");
        return $stmt->execute([$this->id]);
    }

    /**
     * Calcula calorias totais da refeição
     */
    public function calcularCaloriasTotais() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("
            SELECT SUM(a.calorias * i.quantidade / 100) as total_calorias
            FROM itens_refeicao i
            JOIN alimentos a ON i.alimento_id = a.id
            WHERE i.refeicao_id = ?
        ");
        $stmt->execute([$this->id]);
        $resultado = $stmt->fetch();
        return $resultado['total_calorias'] ?? 0;
    }
}
?>
