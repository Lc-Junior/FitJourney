<?php
/**
 * Modelo para a entidade Post
 */
class Post {
    private $id;
    private $usuarioId;
    private $texto;
    private $foto;
    private $dataCriacao;

    public function __construct($usuarioId = null, $texto = null, $foto = null) {
        $this->usuarioId = $usuarioId;
        $this->texto = $texto;
        $this->foto = $foto;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getTexto() { return $this->texto; }
    public function setTexto($texto) { $this->texto = $texto; }

    public function getFoto() { return $this->foto; }
    public function setFoto($foto) { $this->foto = $foto; }

    public function getDataCriacao() { return $this->dataCriacao; }
    public function setDataCriacao($dataCriacao) { $this->dataCriacao = $dataCriacao; }

    /**
     * Salva o post no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE posts SET texto = ?, foto = ? WHERE id = ? AND usuario_id = ?");
            return $stmt->execute([$this->texto, $this->foto, $this->id, $this->usuarioId]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO posts (usuario_id, texto, foto) VALUES (?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->texto, $this->foto]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca post por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $post = new Post($dados['usuario_id'], $dados['texto'], $dados['foto']);
            $post->setId($dados['id']);
            $post->setDataCriacao($dados['data_criacao']);
            return $post;
        }
        return null;
    }

    /**
     * Lista posts de todos os usuários (feed)
     */
    public static function listarFeed($limite = 50) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT p.*, u.nome AS nome_usuario FROM posts p JOIN usuarios u ON p.usuario_id = u.id ORDER BY p.data_criacao DESC LIMIT :limite");
        $stmt->bindValue(':limite', (int)$limite, PDO::PARAM_INT);
        $stmt->execute();
        $posts = [];
        while ($dados = $stmt->fetch()) {
            $post = new Post($dados['usuario_id'], $dados['texto'], $dados['foto']);
            $post->setId($dados['id']);
            $post->setDataCriacao($dados['data_criacao']);
            $post->nomeUsuario = $dados['nome_usuario']; // Adiciona nome do usuário
            $posts[] = $post;
        }
        return $posts;
    }

    /**
     * Lista posts de um usuário específico
     */
    public static function listarPorUsuario($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE usuario_id = ? ORDER BY data_criacao DESC");
        $stmt->execute([$usuarioId]);
        $posts = [];
        while ($dados = $stmt->fetch()) {
            $post = new Post($dados['usuario_id'], $dados['texto'], $dados['foto']);
            $post->setId($dados['id']);
            $post->setDataCriacao($dados['data_criacao']);
            $posts[] = $post;
        }
        return $posts;
    }

    /**
     * Exclui o post (apenas se for do usuário)
     */
    public function excluir($usuarioId) {
        if ($this->usuarioId != $usuarioId) {
            return false; // Não é o dono
        }
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM posts WHERE id = ? AND usuario_id = ?");
        return $stmt->execute([$this->id, $usuarioId]);
    }
}
?>
