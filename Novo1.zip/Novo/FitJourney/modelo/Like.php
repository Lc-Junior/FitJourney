<?php
/**
 * Modelo para a entidade Like (Curtida)
 */
class Like {
    private $id;
    private $usuarioId;
    private $postId;
    private $dataCurtida;

    public function __construct($usuarioId = null, $postId = null) {
        $this->usuarioId = $usuarioId;
        $this->postId = $postId;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getPostId() { return $this->postId; }
    public function setPostId($postId) { $this->postId = $postId; }

    public function getDataCurtida() { return $this->dataCurtida; }
    public function setDataCurtida($dataCurtida) { $this->dataCurtida = $dataCurtida; }

    /**
     * Adiciona ou remove curtida (toggle)
     */
    public static function toggleLike($usuarioId, $postId) {
        $pdo = Conexao::getInstancia()->getPDO();
        // Verifica se já curtiu
        $stmt = $pdo->prepare("SELECT id FROM curtidas WHERE usuario_id = ? AND post_id = ?");
        $stmt->execute([$usuarioId, $postId]);
        $like = $stmt->fetch();

        if ($like) {
            // Remove curtida
            $stmt = $pdo->prepare("DELETE FROM curtidas WHERE id = ?");
            $stmt->execute([$like['id']]);
            return false; // Removido
        } else {
            // Adiciona curtida
            $stmt = $pdo->prepare("INSERT INTO curtidas (usuario_id, post_id) VALUES (?, ?)");
            $stmt->execute([$usuarioId, $postId]);
            return true; // Adicionado
        }
    }

    /**
     * Verifica se usuário curtiu o post
     */
    public static function usuarioCurtiu($usuarioId, $postId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT id FROM curtidas WHERE usuario_id = ? AND post_id = ?");
        $stmt->execute([$usuarioId, $postId]);
        return $stmt->fetch() !== false;
    }

    /**
     * Conta curtidas de um post
     */
    public static function contarCurtidas($postId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT COUNT(*) AS total FROM curtidas WHERE post_id = ?");
        $stmt->execute([$postId]);
        $result = $stmt->fetch();
        return $result['total'];
    }
}
?>
