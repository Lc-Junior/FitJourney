<?php
/**
 * Controlador para o feed social
 */
class ControleFeed {
    private $validador;

    public function __construct() {
        $this->validador = new Validador();
    }

    /**
     * Exibe o feed
     */
    public function exibirFeed() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            header('Location: login.php');
            exit;
        }

        $posts = Post::listarFeed();
        // Adiciona dados de likes e comentários para cada post
        foreach ($posts as $post) {
            $post->curtidas = Like::contarCurtidas($post->getId());
            $post->curtiu = Like::usuarioCurtiu($usuarioId, $post->getId());
            $post->comentarios = Comment::listarPorPost($post->getId());
        }

        return $posts;
    }

    /**
     * Processa criação de post
     */
    public function criarPost($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        if (empty($dados['texto']) && empty($_FILES['foto']['name'])) {
            return Resposta::erro('Post deve ter texto ou foto.');
        }

        $fotoPath = null;
        if (!empty($_FILES['foto']['name'])) {
            $fotoPath = $this->processarUploadFoto();
            if (!$fotoPath) {
                return Resposta::erro('Erro ao fazer upload da foto.');
            }
        }

        $post = new Post($usuarioId, $dados['texto'], $fotoPath);
        if ($post->salvar()) {
            return Resposta::sucesso('Post criado com sucesso.');
        }

        return Resposta::erro('Erro ao criar post.');
    }

    /**
     * Processa edição de post
     */
    public function editarPost($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $postId = $dados['post_id'];
        $post = Post::buscarPorId($postId);
        if (!$post || $post->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Post não encontrado ou não autorizado.');
        }

        if (empty($dados['texto']) && empty($_FILES['foto']['name'])) {
            return Resposta::erro('Post deve ter texto ou foto.');
        }

        $fotoPath = $post->getFoto(); // Mantém foto atual se não enviada nova
        if (!empty($_FILES['foto']['name'])) {
            $fotoPath = $this->processarUploadFoto();
            if (!$fotoPath) {
                return Resposta::erro('Erro ao fazer upload da foto.');
            }
        }

        $post->setTexto($dados['texto']);
        $post->setFoto($fotoPath);
        if ($post->salvar()) {
            return Resposta::sucesso('Post editado com sucesso.');
        }

        return Resposta::erro('Erro ao editar post.');
    }

    /**
     * Processa exclusão de post
     */
    public function excluirPost($postId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $post = Post::buscarPorId($postId);
        if (!$post) {
            return Resposta::erro('Post não encontrado.');
        }

        if ($post->excluir($usuarioId)) {
            // Remove foto se existir
            if ($post->getFoto()) {
                unlink(__DIR__ . '/../visao/' . $post->getFoto());
            }
            return Resposta::sucesso('Post excluído com sucesso.');
        }

        return Resposta::erro('Erro ao excluir post.');
    }

    /**
     * Processa curtida
     */
    public function curtirPost($postId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $curtiu = Like::toggleLike($usuarioId, $postId);
        return Resposta::sucesso($curtiu ? 'Post curtido.' : 'Curtida removida.');
    }

    /**
     * Processa comentário
     */
    public function comentarPost($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        if (empty($dados['texto'])) {
            return Resposta::erro('Comentário não pode ser vazio.');
        }

        $comentario = new Comment($usuarioId, $dados['post_id'], $dados['texto']);
        if ($comentario->salvar()) {
            return Resposta::sucesso('Comentário adicionado.');
        }

        return Resposta::erro('Erro ao adicionar comentário.');
    }

    /**
     * Processa exclusão de comentário
     */
    public function excluirComentario($comentarioId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $comentario = new Comment();
        $comentario->setId($comentarioId);
        if ($comentario->excluir($usuarioId)) {
            return Resposta::sucesso('Comentário excluído.');
        }

        return Resposta::erro('Erro ao excluir comentário.');
    }

    /**
     * Processa upload de foto
     */
    private function processarUploadFoto() {
        if (!isset($_FILES['foto']) || $_FILES['foto']['error'] != UPLOAD_ERR_OK) {
            return false;
        }

        $arquivo = $_FILES['foto'];
        $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));

        if (!in_array($extensao, $extensoesPermitidas)) {
            return false;
        }

        if ($arquivo['size'] > 5 * 1024 * 1024) { // 5MB
            return false;
        }

        $nomeUnico = uniqid() . '.' . $extensao;
        $caminho = 'uploads/posts/' . $nomeUnico;
        $caminhoCompleto = __DIR__ . '/../visao/' . $caminho;

        if (move_uploaded_file($arquivo['tmp_name'], $caminhoCompleto)) {
            return $caminho;
        }

        return false;
    }
}
?>
