<?php
require_once '../../modelo/Treino.php';
require_once '../../ajudantes/Resposta.php';

/**
 * Controlador para gerenciar treinos
 */
class ControleTreino {

    /**
     * Lista treinos do usuário logado
     */
    public function listar() {
        try {
            $usuarioId = $_SESSION['usuario_id'];
            $treinos = Treino::listarPorUsuario($usuarioId);
            return new Resposta(true, 'Treinos listados com sucesso', $treinos);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao listar treinos: ' . $e->getMessage());
        }
    }

    /**
     * Cria um novo treino
     */
    public function criar($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'];

            // Validação básica
            if (empty($dados['nome']) || empty($dados['data_treino'])) {
                return new Resposta(false, 'Nome e data do treino são obrigatórios');
            }

            $treino = new Treino(
                $usuarioId,
                $dados['nome'],
                $dados['descricao'] ?? '',
                $dados['data_treino'],
                $dados['duracao'] ?? null,
                $dados['exercicios'] ?? null
            );

            if ($treino->salvar()) {
                return new Resposta(true, 'Treino criado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao salvar treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao criar treino: ' . $e->getMessage());
        }
    }

    /**
     * Busca um treino por ID
     */
    public function buscarPorId($id) {
        try {
            $treino = Treino::buscarPorId($id);
            if ($treino && $treino->getUsuarioId() == $_SESSION['usuario_id']) {
                return new Resposta(true, 'Treino encontrado', $treino);
            } else {
                return new Resposta(false, 'Treino não encontrado');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao buscar treino: ' . $e->getMessage());
        }
    }

    /**
     * Atualiza um treino
     */
    public function atualizar($dados) {
        try {
            if (empty($dados['id'])) {
                return new Resposta(false, 'ID do treino é obrigatório');
            }

            $treino = Treino::buscarPorId($dados['id']);
            if (!$treino || $treino->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Treino não encontrado');
            }

            $treino->setNome($dados['nome'] ?? $treino->getNome());
            $treino->setDescricao($dados['descricao'] ?? $treino->getDescricao());
            $treino->setDataTreino($dados['data_treino'] ?? $treino->getDataTreino());
            $treino->setDuracao($dados['duracao'] ?? $treino->getDuracao());
            $treino->setExercicios($dados['exercicios'] ?? $treino->getExercicios());

            if ($treino->salvar()) {
                return new Resposta(true, 'Treino atualizado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao atualizar treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao atualizar treino: ' . $e->getMessage());
        }
    }

    /**
     * Exclui um treino
     */
    public function excluir($id) {
        try {
            $treino = Treino::buscarPorId($id);
            if (!$treino || $treino->getUsuarioId() != $_SESSION['usuario_id']) {
                return new Resposta(false, 'Treino não encontrado');
            }

            if ($treino->excluir()) {
                return new Resposta(true, 'Treino excluído com sucesso');
            } else {
                return new Resposta(false, 'Erro ao excluir treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao excluir treino: ' . $e->getMessage());
        }
    }
}
?>
