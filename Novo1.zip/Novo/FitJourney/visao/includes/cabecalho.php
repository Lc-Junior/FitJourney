<?php
// Inicia sessão se não estiver iniciada
Funcoes::iniciarSessao();

// Processa logout
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    require_once '../../controle/ControleUsuario.php';
    $controleUsuario = new ControleUsuario();
    $resposta = $controleUsuario->logout();
    Funcoes::redirecionar('/Novo/FitJourney/visao/index.php');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FitJourney - <?php echo $titulo ?? 'Sistema de Acompanhamento Fitness'; ?></title>
    <link rel="stylesheet" href="/Novo/FitJourney/visao/css/estilo.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">FitJourney</div>
            <nav>
                <ul>
                    <li><a href="/Novo/FitJourney/visao/index.php">Início</a></li>
                    <?php if (Funcoes::usuarioLogado()): ?>
                        <li><a href="/Novo/FitJourney/visao/paginas/dashboard.php">Dashboard</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/feed.php">Feed</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/perfil.php">Perfil</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/treinos.php">Treinos</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/refeicoes.php">Refeições</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/objetivos.php">Objetivos</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/conquistas.php">Conquistas</a></li>
                        <li><a href="?action=logout">Sair</a></li>
                    <?php else: ?>
                        <li><a href="/Novo/FitJourney/visao/paginas/login.php">Login</a></li>
                        <li><a href="/Novo/FitJourney/visao/paginas/cadastro.php">Cadastro</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    <main class="container">
