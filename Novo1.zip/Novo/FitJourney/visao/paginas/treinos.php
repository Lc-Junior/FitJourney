<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../ajudantes/ApiTreino.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Treino.php';
require_once '../../controle/ControleTreino.php';
require_once '../../controle/ControlePerfil.php';

$titulo = 'Treinos';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controleTreino = new ControleTreino();

    if (isset($_POST['acao'])) {
        switch ($_POST['acao']) {
            case 'criar':
                $resposta = $controleTreino->criar(Funcoes::limparEntrada($_POST));
                break;
            case 'atualizar':
                $resposta = $controleTreino->atualizar(Funcoes::limparEntrada($_POST));
                break;
            case 'excluir':
                if (isset($_POST['id'])) {
                    $resposta = $controleTreino->excluir($_POST['id']);
                }
                break;
        }

        if (isset($resposta)) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = $resposta->getSucesso() ? 'success' : 'error';
        }
    }
}

// Obtém treinos do usuário
$controleTreino = new ControleTreino();
$treinosResposta = $controleTreino->listar();
$treinos = $treinosResposta->getSucesso() ? $treinosResposta->getDados() : [];

// Obtém perfil para sugestões
$controlePerfil = new ControlePerfil();
$perfilResposta = $controlePerfil->getPerfil();
$perfil = $perfilResposta->getSucesso() ? $perfilResposta->getDados() : [];

// Gera sugestões de treino
$apiTreino = new ApiTreino();
$sugestoes = $apiTreino->gerarSugestoesTreino($perfil);

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Meus Treinos</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <div class="workout-actions">
        <button class="btn btn-primary" onclick="mostrarFormularioTreino()">Adicionar Treino</button>
    </div>

    <!-- Lista de Treinos -->
    <div class="workouts-list">
        <?php if (empty($treinos)): ?>
            <p>Você ainda não tem treinos cadastrados.</p>
        <?php else: ?>
            <?php foreach ($treinos as $treino): ?>
                <div class="workout-card">
                    <h3><?php echo htmlspecialchars($treino->getNome()); ?></h3>
                    <p><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($treino->getDataTreino())); ?></p>
                    <?php if ($treino->getDuracao()): ?>
                        <p><strong>Duração:</strong> <?php echo $treino->getDuracao(); ?> minutos</p>
                    <?php endif; ?>
                    <?php if ($treino->getDescricao()): ?>
                        <p><?php echo htmlspecialchars($treino->getDescricao()); ?></p>
                    <?php endif; ?>

                    <?php
                    $exercicios = json_decode($treino->getExercicios(), true);
                    if ($exercicios && is_array($exercicios)):
                    ?>
                        <div class="exercises-list">
                            <h4>Exercícios:</h4>
                            <ul>
                                <?php foreach ($exercicios as $exercicio): ?>
                                    <li>
                                        <strong><?php echo htmlspecialchars($exercicio['nome']); ?></strong>
                                        - <?php echo $exercicio['series']; ?> séries x <?php echo $exercicio['repeticoes']; ?>
                                        <?php if (isset($exercicio['descanso'])): ?>
                                            (descanso: <?php echo $exercicio['descanso']; ?>)
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="workout-actions">
                        <button class="btn btn-secondary" onclick="editarTreino(<?php echo $treino->getId(); ?>)">Editar</button>
                        <button class="btn btn-danger" onclick="excluirTreino(<?php echo $treino->getId(); ?>, '<?php echo htmlspecialchars($treino->getNome()); ?>')">Excluir</button>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Sugestões de Treino -->
<?php if (!empty($sugestoes)): ?>
<div class="card">
    <h2>Sugestões de Treino</h2>
    <p>Baseado no seu perfil, aqui estão algumas sugestões personalizadas:</p>

    <div class="suggestions-list">
        <?php foreach ($sugestoes as $sugestao): ?>
            <div class="suggestion-card">
                <h3><?php echo htmlspecialchars($sugestao['nome']); ?></h3>
                <p><strong>Duração estimada:</strong> <?php echo $sugestao['duracao']; ?> minutos</p>

                <div class="exercises-list">
                    <h4>Exercícios sugeridos:</h4>
                    <ul>
                        <?php foreach ($sugestao['exercicios'] as $exercicio): ?>
                            <li>
                                <strong><?php echo htmlspecialchars($exercicio['nome']); ?></strong>
                                - <?php echo $exercicio['series']; ?> séries x <?php echo $exercicio['repeticoes']; ?>
                                <?php if (isset($exercicio['descanso'])): ?>
                                    (descanso: <?php echo $exercicio['descanso']; ?>)
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <button class="btn btn-success" onclick="usarSugestao('<?php echo htmlspecialchars($sugestao['nome']); ?>', <?php echo $sugestao['duracao']; ?>, <?php echo htmlspecialchars(json_encode($sugestao['exercicios'])); ?>)">
                    Usar esta sugestão
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<!-- Modal/Formulário de Treino -->
<div id="workout-modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="fecharModal()">&times;</span>
        <h2 id="modal-title">Adicionar Treino</h2>

        <form id="workout-form" method="POST">
            <input type="hidden" name="acao" id="acao" value="criar">
            <input type="hidden" name="id" id="treino-id">

            <div class="form-group">
                <label for="nome">Nome do Treino:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="form-group">
                <label for="data_treino">Data do Treino:</label>
                <input type="date" id="data_treino" name="data_treino" required>
            </div>

            <div class="form-group">
                <label for="duracao">Duração (minutos):</label>
                <input type="number" id="duracao" name="duracao" min="1">
            </div>

            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <textarea id="descricao" name="descricao" rows="3"></textarea>
            </div>

            <div class="form-group">
                <label>Exercícios (JSON opcional):</label>
                <textarea id="exercicios" name="exercicios" rows="5" placeholder='[{"nome": "Agachamento", "series": 3, "repeticoes": "10-12", "descanso": "30s"}]' ></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Salvar</button>
            <button type="button" class="btn btn-secondary" onclick="fecharModal()">Cancelar</button>
        </form>
    </div>
</div>

<script>
// Funções JavaScript para gerenciar o modal e ações
function mostrarFormularioTreino() {
    document.getElementById('modal-title').textContent = 'Adicionar Treino';
    document.getElementById('acao').value = 'criar';
    document.getElementById('treino-id').value = '';
    document.getElementById('workout-form').reset();
    document.getElementById('workout-modal').style.display = 'block';
}

function editarTreino(id) {
    // Aqui você pode implementar busca do treino por AJAX ou redirecionar
    alert('Funcionalidade de edição será implementada com AJAX');
}

function excluirTreino(id, nome) {
    if (confirm('Tem certeza que deseja excluir o treino "' + nome + '"?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = '<input type="hidden" name="acao" value="excluir"><input type="hidden" name="id" value="' + id + '">';
        document.body.appendChild(form);
        form.submit();
    }
}

function usarSugestao(nome, duracao, exercicios) {
    document.getElementById('modal-title').textContent = 'Criar Treino com Sugestão';
    document.getElementById('acao').value = 'criar';
    document.getElementById('treino-id').value = '';
    document.getElementById('workout-form').reset();

    document.getElementById('nome').value = nome;
    document.getElementById('duracao').value = duracao;
    document.getElementById('exercicios').value = JSON.stringify(exercicios, null, 2);
    document.getElementById('data_treino').value = new Date().toISOString().split('T')[0];

    document.getElementById('workout-modal').style.display = 'block';
}

function fecharModal() {
    document.getElementById('workout-modal').style.display = 'none';
}

// Fecha modal ao clicar fora
window.onclick = function(event) {
    const modal = document.getElementById('workout-modal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>

<?php include '../includes/rodape.php'; ?>
