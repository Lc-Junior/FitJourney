<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleRefeicao.php';
require_once '../../controle/ControleAdmin.php';

$titulo = 'Refeições';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleRefeicao = new ControleRefeicao();
$controleAdmin = new ControleAdmin();

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'cadastrar_refeicao':
            $resposta = $controleRefeicao->cadastrar(Funcoes::limparEntrada($_POST));
            break;

        case 'adicionar_alimento':
            $resposta = $controleRefeicao->adicionarAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id'],
                $_POST['quantidade']
            );
            break;

        case 'remover_alimento':
            $resposta = $controleRefeicao->removerAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id']
            );
            break;

        case 'editar_alimento':
            $resposta = $controleRefeicao->editarAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id'],
                $_POST['quantidade']
            );
            break;

        case 'adicionar_alimento_customizado':
            $resposta = $controleRefeicao->adicionarAlimentoCustomizado(
                $_POST['refeicao_id'],
                $_POST['nome_alimento'],
                $_POST['quantidade'],
                $_POST['unidade'] ?? 'g'
            );
            break;

        case 'excluir_refeicao':
            $resposta = $controleRefeicao->excluir($_POST['refeicao_id']);
            break;
    }

    if (isset($resposta)) {
        if ($resposta->getSucesso()) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'success';
        } else {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'error';
        }
    }
}

// Obtém dados
$refeicoesResposta = $controleRefeicao->listar();
$alimentosResposta = $controleAdmin->listarAlimentos();

$refeicoes = $refeicoesResposta->getSucesso() ? $refeicoesResposta->getDados() : [];
$alimentos = $alimentosResposta->getSucesso() ? $alimentosResposta->getDados() : [];

// Verifica se é para mostrar detalhes
$detalhesRefeicao = null;
if (isset($_GET['action']) && $_GET['action'] == 'detalhes' && isset($_GET['id'])) {
    $detalhesResposta = $controleRefeicao->getDetalhes($_GET['id']);
    if ($detalhesResposta->getSucesso()) {
        $detalhesRefeicao = $detalhesResposta->getDados();
    }
}

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Gerenciar Refeições</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-refeicao').style.display='block'" class="btn btn-primary">Nova Refeição</button>
</div>

<?php if ($detalhesRefeicao): ?>
<div class="card">
    <h2>Detalhes da Refeição</h2>
    <p><strong>Tipo:</strong> <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $detalhesRefeicao['refeicao']['tipo'] ?? ''))); ?></p>
    <p><strong>Data:</strong> <?php echo htmlspecialchars(Funcoes::formatarData($detalhesRefeicao['refeicao']['data_refeicao'] ?? '')); ?></p>
    <p><strong>Hora:</strong> <?php echo htmlspecialchars($detalhesRefeicao['refeicao']['hora_refeicao'] ?? ''); ?></p>
    <p><strong>Calorias Totais:</strong> <?php echo htmlspecialchars(number_format($detalhesRefeicao['refeicao']['calorias_totais'] ?? 0, 0)); ?> kcal</p>

    <h3>Alimentos</h3>
    <?php if (!empty($detalhesRefeicao['itens'])): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Alimento</th>
                    <th>Quantidade (g)</th>
                    <th>Calorias</th>
                    <th>Proteínas (g)</th>
                    <th>Carboidratos (g)</th>
                    <th>Gorduras (g)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detalhesRefeicao['itens'] as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['nome'] ?? ''); ?></td>
                        <td><?php echo ($item['quantidade'] ?? 0); ?>g</td>
                        <td><?php echo number_format(($item['calorias'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 0); ?> kcal</td>
                        <td><?php echo number_format(($item['proteinas'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td><?php echo number_format(($item['carboidratos'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td><?php echo number_format(($item['gorduras'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td>
                            <button onclick="editarQuantidade(<?php echo $item['alimento_id'] ?? ''; ?>, <?php echo $item['quantidade'] ?? 0; ?>)" class="btn btn-warning btn-sm">Editar</button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="remover_alimento">
                                <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
                                <input type="hidden" name="alimento_id" value="<?php echo $item['alimento_id'] ?? ''; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Remover este alimento?')">Remover</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum alimento adicionado ainda.</p>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-alimento').style.display='block'" class="btn btn-success">Adicionar Alimento</button>
    <button onclick="document.getElementById('modal-custom').style.display='block'" class="btn btn-info">Buscar Alimento na API</button>
    <a href="refeicoes.php" class="btn btn-secondary">Voltar</a>
</div>
<?php else: ?>
<div class="card">
    <h2>Minhas Refeições</h2>
    <?php if (!empty($refeicoes)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Data</th>
                    <th>Hora</th>
                    <th>Calorias</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($refeicoes as $refeicao): ?>
                    <tr>
                        <td><?php echo ucfirst(str_replace('_', ' ', $refeicao['tipo'])); ?></td>
                        <td><?php echo Funcoes::formatarData($refeicao['data_refeicao']); ?></td>
                        <td><?php echo $refeicao['hora_refeicao']; ?></td>
                        <td><?php echo number_format($refeicao['calorias_totais'], 0); ?> kcal</td>
                        <td>
                            <a href="?action=detalhes&id=<?php echo $refeicao['id']; ?>" class="btn btn-secondary btn-sm">Ver</a>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="excluir_refeicao">
                                <input type="hidden" name="refeicao_id" value="<?php echo $refeicao['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Excluir esta refeição?')">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhuma refeição registrada ainda.</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Modal Nova Refeição -->
<div id="modal-refeicao" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-refeicao').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Nova Refeição</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="cadastrar_refeicao">
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select id="tipo" name="tipo" required>
                    <option value="cafe_manha">Café da Manhã</option>
                    <option value="almoco">Almoço</option>
                    <option value="jantar">Jantar</option>
                    <option value="lanche">Lanche</option>
                </select>
            </div>
            <div class="form-group">
                <label for="data_refeicao">Data:</label>
                <input type="date" id="data_refeicao" name="data_refeicao" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="hora_refeicao">Hora:</label>
                <input type="time" id="hora_refeicao" name="hora_refeicao">
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>
</div>

<!-- Modal Adicionar Alimento -->
<div id="modal-alimento" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-alimento').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Adicionar Alimento</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_alimento">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <div class="form-group">
                <label for="alimento_id">Alimento:</label>
                <select id="alimento_id" name="alimento_id" required>
                    <?php foreach ($alimentos as $alimento): ?>
                        <option value="<?php echo $alimento['id']; ?>"><?php echo htmlspecialchars($alimento['nome']); ?> (<?php echo $alimento['calorias']; ?> kcal/100g)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="quantidade">Quantidade (gramas):</label>
                <input type="number" id="quantidade" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar</button>
        </form>
    </div>
</div>

<!-- Modal Buscar Alimento na API -->
<div id="modal-custom" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px;">
        <span onclick="document.getElementById('modal-custom').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Buscar Alimento na API</h3>
        <p><small>Exemplo: "80g banana", "50g pão", "200ml leite"</small></p>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_alimento_customizado">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <div class="form-group">
                <label for="nome_alimento">Nome do Alimento:</label>
                <input type="text" id="nome_alimento" name="nome_alimento" placeholder="Ex: banana, pão" required>
            </div>
            <div class="form-group">
                <label for="quantidade_custom">Quantidade (gramas):</label>
                <input type="number" id="quantidade_custom" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <div class="form-group">
                <label for="unidade">Unidade:</label>
                <select id="unidade" name="unidade">
                    <option value="g">Gramas (g)</option>
                    <option value="ml">Mililitros (ml)</option>
                    <option value="oz">Onças (oz)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Buscar e Adicionar</button>
        </form>
    </div>
</div>

<!-- Modal Editar Quantidade -->
<div id="modal-editar" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-editar').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Editar Quantidade</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="editar_alimento">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <input type="hidden" id="editar_alimento_id" name="alimento_id" value="">
            <div class="form-group">
                <label for="editar_quantidade">Nova Quantidade (gramas):</label>
                <input type="number" id="editar_quantidade" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
</div>

<script>
function editarQuantidade(alimentoId, quantidadeAtual) {
    document.getElementById('editar_alimento_id').value = alimentoId;
    document.getElementById('editar_quantidade').value = quantidadeAtual;
    document.getElementById('modal-editar').style.display = 'block';
}
</script>

<?php include '../includes/rodape.php'; ?>
