<?php
/**
 * Modelo para a entidade Medida
 */
class Medida {
    private $id;
    private $usuarioId;
    private $dataMedida;
    private $peso;
    private $cintura;
    private $quadril;
    private $peito;

    public function __construct($usuarioId = null, $dataMedida = null, $peso = null, $cintura = null, $quadril = null, $peito = null) {
        $this->usuarioId = $usuarioId;
        $this->dataMedida = $dataMedida;
        $this->peso = $peso;
        $this->cintura = $cintura;
        $this->quadril = $quadril;
        $this->peito = $peito;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getDataMedida() { return $this->dataMedida; }
    public function setDataMedida($dataMedida) { $this->dataMedida = $dataMedida; }

    public function getPeso() { return $this->peso; }
    public function setPeso($peso) { $this->peso = $peso; }

    public function getCintura() { return $this->cintura; }
    public function setCintura($cintura) { $this->cintura = $cintura; }

    public function getQuadril() { return $this->quadril; }
    public function setQuadril($quadril) { $this->quadril = $quadril; }

    public function getPeito() { return $this->peito; }
    public function setPeito($peito) { $this->peito = $peito; }

    /**
     * Salva a medida no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE medidas SET data_medida = ?, peso = ?, cintura = ?, quadril = ?, peito = ? WHERE id = ?");
            return $stmt->execute([$this->dataMedida, $this->peso, $this->cintura, $this->quadril, $this->peito, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO medidas (usuario_id, data_medida, peso, cintura, quadril, peito) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->dataMedida, $this->peso, $this->cintura, $this->quadril, $this->peito]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca medidas por ID do usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM medidas WHERE usuario_id = ? ORDER BY data_medida DESC");
        $stmt->execute([$usuarioId]);
        $medidas = [];
        while ($dados = $stmt->fetch()) {
            $medida = new Medida($dados['usuario_id'], $dados['data_medida'], $dados['peso'], $dados['cintura'], $dados['quadril'], $dados['peito']);
            $medida->setId($dados['id']);
            $medidas[] = $medida;
        }
        return $medidas;
    }

    /**
     * Lista todas as medidas
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM medidas ORDER BY data_medida DESC");
        $medidas = [];
        while ($dados = $stmt->fetch()) {
            $medida = new Medida($dados['usuario_id'], $dados['data_medida'], $dados['peso'], $dados['cintura'], $dados['quadril'], $dados['peito']);
            $medida->setId($dados['id']);
            $medidas[] = $medida;
        }
        return $medidas;
    }

    /**
     * Exclui a medida
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM medidas WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
