<?php
/**
 * Modelo para a entidade Notificacao
 */
class Notificacao {
    private $id;
    private $usuarioId;
    private $titulo;
    private $mensagem;
    private $tipo;
    private $lida;
    private $dataNotificacao;

    public function __construct($usuarioId = null, $titulo = null, $mensagem = null, $tipo = null) {
        $this->usuarioId = $usuarioId;
        $this->titulo = $titulo;
        $this->mensagem = $mensagem;
        $this->tipo = $tipo;
        $this->lida = false;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getTitulo() { return $this->titulo; }
    public function setTitulo($titulo) { $this->titulo = $titulo; }

    public function getMensagem() { return $this->mensagem; }
    public function setMensagem($mensagem) { $this->mensagem = $mensagem; }

    public function getTipo() { return $this->tipo; }
    public function setTipo($tipo) { $this->tipo = $tipo; }

    public function getLida() { return $this->lida; }
    public function setLida($lida) { $this->lida = $lida; }

    public function getDataNotificacao() { return $this->dataNotificacao; }
    public function setDataNotificacao($dataNotificacao) { $this->dataNotificacao = $dataNotificacao; }

    /**
     * Salva a notificação no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE notificacoes SET titulo = ?, mensagem = ?, tipo = ?, lida = ? WHERE id = ?");
            return $stmt->execute([$this->titulo, $this->mensagem, $this->tipo, $this->lida, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo) VALUES (?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->titulo, $this->mensagem, $this->tipo]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca notificações por ID do usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? ORDER BY data_notificacao DESC");
        $stmt->execute([$usuarioId]);
        $notificacoes = [];
        while ($dados = $stmt->fetch()) {
            $notificacao = new Notificacao($dados['usuario_id'], $dados['titulo'], $dados['mensagem'], $dados['tipo']);
            $notificacao->setId($dados['id']);
            $notificacao->setLida($dados['lida']);
            $notificacao->setDataNotificacao($dados['data_notificacao']);
            $notificacoes[] = $notificacao;
        }
        return $notificacoes;
    }

    /**
     * Busca notificações não lidas por usuário
     */
    public static function buscarNaoLidasPorUsuario($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? AND lida = FALSE ORDER BY data_notificacao DESC");
        $stmt->execute([$usuarioId]);
        $notificacoes = [];
        while ($dados = $stmt->fetch()) {
            $notificacao = new Notificacao($dados['usuario_id'], $dados['titulo'], $dados['mensagem'], $dados['tipo']);
            $notificacao->setId($dados['id']);
            $notificacao->setLida($dados['lida']);
            $notificacao->setDataNotificacao($dados['data_notificacao']);
            $notificacoes[] = $notificacao;
        }
        return $notificacoes;
    }

    /**
     * Lista todas as notificações
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM notificacoes ORDER BY data_notificacao DESC");
        $notificacoes = [];
        while ($dados = $stmt->fetch()) {
            $notificacao = new Notificacao($dados['usuario_id'], $dados['titulo'], $dados['mensagem'], $dados['tipo']);
            $notificacao->setId($dados['id']);
            $notificacao->setLida($dados['lida']);
            $notificacao->setDataNotificacao($dados['data_notificacao']);
            $notificacoes[] = $notificacao;
        }
        return $notificacoes;
    }

    /**
     * Marca como lida
     */
    public function marcarComoLida() {
        $this->lida = true;
        return $this->salvar();
    }

    /**
     * Exclui a notificação
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM notificacoes WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
