<?php
/**
 * Modelo para a entidade Perfil
 */
class Perfil {
    private $id;
    private $usuarioId;
    private $idade;
    private $peso;
    private $altura;
    private $sexo;
    private $nivelAtividade;

    public function __construct($usuarioId = null, $idade = null, $peso = null, $altura = null, $sexo = null, $nivelAtividade = null) {
        $this->usuarioId = $usuarioId;
        $this->idade = $idade;
        $this->peso = $peso;
        $this->altura = $altura;
        $this->sexo = $sexo;
        $this->nivelAtividade = $nivelAtividade;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getIdade() { return $this->idade; }
    public function setIdade($idade) { $this->idade = $idade; }

    public function getPeso() { return $this->peso; }
    public function setPeso($peso) { $this->peso = $peso; }

    public function getAltura() { return $this->altura; }
    public function setAltura($altura) { $this->altura = $altura; }

    public function getSexo() { return $this->sexo; }
    public function setSexo($sexo) { $this->sexo = $sexo; }

    public function getNivelAtividade() { return $this->nivelAtividade; }
    public function setNivelAtividade($nivelAtividade) { $this->nivelAtividade = $nivelAtividade; }

    /**
     * Salva o perfil no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE perfis SET idade = ?, peso = ?, altura = ?, sexo = ?, nivel_atividade = ? WHERE id = ?");
            return $stmt->execute([$this->idade, $this->peso, $this->altura, $this->sexo, $this->nivelAtividade, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO perfis (usuario_id, idade, peso, altura, sexo, nivel_atividade) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->idade, $this->peso, $this->altura, $this->sexo, $this->nivelAtividade]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca perfil por ID do usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM perfis WHERE usuario_id = ?");
        $stmt->execute([$usuarioId]);
        $dados = $stmt->fetch();
        if ($dados) {
            $perfil = new Perfil($dados['usuario_id'], $dados['idade'], $dados['peso'], $dados['altura'], $dados['sexo'], $dados['nivel_atividade']);
            $perfil->setId($dados['id']);
            return $perfil;
        }
        return null;
    }
}
?>
