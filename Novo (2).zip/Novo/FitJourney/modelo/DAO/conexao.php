<?php
/**
 * Classe de conexão com o banco de dados usando Singleton
 */
class Conexao {
    private static $instancia = null;
    private $pdo;

    private function __construct() {
        $host = 'localhost';
        $dbname = 'fitjourney';
        $usuario = 'root'; // Altere se necessário
        $senha = ''; // Altere se necessário

        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $usuario, $senha);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            die("Erro na conexão com o banco de dados: " . $e->getMessage());
        }
    }

    public static function getInstancia() {
        if (self::$instancia === null) {
            self::$instancia = new Conexao();
        }
        return self::$instancia;
    }

    public function getPDO() {
        return $this->pdo;
    }

    // Impede clonagem
    private function __clone() {}

    // Impede desserialização
    public function __wakeup() {}
}
?>
