<?php
/**
 * Classe para integração com API de exercícios
 * Usa ExerciseDB API (gratuita via RapidAPI)
 */
class ApiTreino {

    private $apiKey = 'a43d1b42f7mshe3ed57ff98c9ff8p196878jsn8fe9c83b3590'; // Substitua pela sua chave
    private $baseUrl = 'https://exercisedb.p.rapidapi.com';

    /**
     * Busca exercícios por categoria
     */
    public function buscarExerciciosPorCategoria($categoria = 'cardio') {
        $url = $this->baseUrl . '/exercises/bodyPart/' . urlencode($categoria);

        $headers = [
            'X-RapidAPI-Host: exercisedb.p.rapidapi.com',
            'X-RapidAPI-Key: ' . $this->apiKey
        ];

        return $this->fazerRequisicao($url, $headers);
    }

    /**
     * Busca exercícios por equipamento
     */
    public function buscarExerciciosPorEquipamento($equipamento = 'body weight') {
        $url = $this->baseUrl . '/exercises/equipment/' . urlencode($equipamento);

        $headers = [
            'X-RapidAPI-Host: exercisedb.p.rapidapi.com',
            'X-RapidAPI-Key: ' . $this->apiKey
        ];

        return $this->fazerRequisicao($url, $headers);
    }

    /**
     * Busca exercícios por nome
     */
    public function buscarExerciciosPorNome($nome) {
        $url = $this->baseUrl . '/exercises/name/' . urlencode($nome);

        $headers = [
            'X-RapidAPI-Host: exercisedb.p.rapidapi.com',
            'X-RapidAPI-Key: ' . $this->apiKey
        ];

        return $this->fazerRequisicao($url, $headers);
    }

    /**
     * Gera sugestões de treino baseadas no perfil do usuário
     */
    public function gerarSugestoesTreino($perfil) {
        $sugestoes = [];

        // Baseado no nível de atividade
        switch ($perfil['nivel_atividade']) {
            case 'sedentario':
                $sugestoes = $this->sugestoesIniciante();
                break;
            case 'leve':
                $sugestoes = $this->sugestoesIntermediario();
                break;
            case 'moderado':
            case 'ativo':
                $sugestoes = $this->sugestoesAvancado();
                break;
            case 'muito_ativo':
                $sugestoes = $this->sugestoesProfissional();
                break;
            default:
                $sugestoes = $this->sugestoesIniciante();
        }

        return $sugestoes;
    }

    /**
     * Sugestões para iniciantes
     */
    private function sugestoesIniciante() {
        return [
            [
                'nome' => 'Caminhada Leve',
                'duracao' => 30,
                'exercicios' => [
                    ['nome' => 'Caminhada', 'series' => 1, 'repeticoes' => '30 min', 'descanso' => 'N/A']
                ]
            ],
            [
                'nome' => 'Exercícios Básicos',
                'duracao' => 20,
                'exercicios' => [
                    ['nome' => 'Agachamento', 'series' => 3, 'repeticoes' => '10-12', 'descanso' => '30s'],
                    ['nome' => 'Flexão de Braço (ajoelhada)', 'series' => 3, 'repeticoes' => '8-10', 'descanso' => '30s'],
                    ['nome' => 'Prancha', 'series' => 3, 'repeticoes' => '20-30s', 'descanso' => '30s']
                ]
            ]
        ];
    }

    /**
     * Sugestões para intermediários
     */
    private function sugestoesIntermediario() {
        return [
            [
                'nome' => 'Treino Funcional',
                'duracao' => 45,
                'exercicios' => [
                    ['nome' => 'Agachamento com Salto', 'series' => 4, 'repeticoes' => '12-15', 'descanso' => '45s'],
                    ['nome' => 'Flexão de Braço', 'series' => 4, 'repeticoes' => '10-12', 'descanso' => '45s'],
                    ['nome' => 'Burpee', 'series' => 4, 'repeticoes' => '8-10', 'descanso' => '60s'],
                    ['nome' => 'Prancha Lateral', 'series' => 3, 'repeticoes' => '30s cada lado', 'descanso' => '30s']
                ]
            ]
        ];
    }

    /**
     * Sugestões para avançados
     */
    private function sugestoesAvancado() {
        return [
            [
                'nome' => 'Treino HIIT',
                'duracao' => 40,
                'exercicios' => [
                    ['nome' => 'Mountain Climber', 'series' => 4, 'repeticoes' => '30s', 'descanso' => '15s'],
                    ['nome' => 'Jump Squat', 'series' => 4, 'repeticoes' => '15', 'descanso' => '30s'],
                    ['nome' => 'Push-up com Rotação', 'series' => 4, 'repeticoes' => '10 cada lado', 'descanso' => '30s'],
                    ['nome' => 'Plank Jack', 'series' => 4, 'repeticoes' => '20', 'descanso' => '45s']
                ]
            ]
        ];
    }

    /**
     * Sugestões para profissionais
     */
    private function sugestoesProfissional() {
        return [
            [
                'nome' => 'Treino Intensivo',
                'duracao' => 60,
                'exercicios' => [
                    ['nome' => 'Burpee Box Jump', 'series' => 5, 'repeticoes' => '15', 'descanso' => '30s'],
                    ['nome' => 'Handstand Push-up', 'series' => 5, 'repeticoes' => '8-10', 'descanso' => '45s'],
                    ['nome' => 'Pistol Squat', 'series' => 4, 'repeticoes' => '10 cada perna', 'descanso' => '60s'],
                    ['nome' => 'Dragon Flag', 'series' => 4, 'repeticoes' => '8-10', 'descanso' => '60s']
                ]
            ]
        ];
    }

    /**
     * Calcula calorias queimadas por exercício
     * Fórmula: MET * peso (kg) * tempo (horas)
     */
    public function calcularCaloriasExercicio($exercicio, $pesoUsuario, $duracaoMinutos = 1) {
        // Valores MET aproximados para exercícios comuns
        $metValues = [
            'caminhada' => 3.8,
            'agachamento' => 6.0,
            'flexão de braço' => 8.0,
            'flexão de braço (ajoelhada)' => 4.0,
            'prancha' => 4.0,
            'agachamento com salto' => 8.0,
            'burpee' => 10.0,
            'prancha lateral' => 4.0,
            'mountain climber' => 8.0,
            'jump squat' => 10.0,
            'push-up com rotação' => 6.0,
            'plank jack' => 8.0,
            'burpee box jump' => 10.0,
            'handstand push-up' => 6.0,
            'pistol squat' => 6.0,
            'dragon flag' => 8.0
        ];

        $nomeExercicio = strtolower($exercicio['nome']);
        $met = $metValues[$nomeExercicio] ?? 5.0; // Valor padrão se não encontrado

        // Tempo em horas
        $tempoHoras = $duracaoMinutos / 60;

        // Calorias = MET * peso * tempo
        $calorias = $met * $pesoUsuario * $tempoHoras;

        return round($calorias, 1);
    }

    /**
     * Calcula calorias totais de um treino
     */
    public function calcularCaloriasTreino($exercicios, $pesoUsuario, $duracaoTotal = null) {
        $totalCalorias = 0;

        if (is_array($exercicios)) {
            foreach ($exercicios as $exercicio) {
                // Assume 1 minuto por série se duração total não fornecida
                $duracaoExercicio = $duracaoTotal ? ($duracaoTotal / count($exercicios)) : 1;
                $totalCalorias += $this->calcularCaloriasExercicio($exercicio, $pesoUsuario, $duracaoExercicio);
            }
        }

        return round($totalCalorias, 1);
    }

    /**
     * Faz requisição HTTP para a API
     */
    private function fazerRequisicao($url, $headers) {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para desenvolvimento

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($httpCode == 200) {
            return json_decode($response, true);
        } else {
            // Retorna sugestões locais se API falhar
            return $this->sugestoesIniciante();
        }
    }
}
?>
