# TODO for Fixing Treino Creation Error

- [x] Modify the `salvar` method in `Treino.php` to encode `exercicios` to JSON if it's an array before saving to the database.
- [x] Update the constructor in `Treino.php` to decode JSON string to array when loading from database.
- [x] Update the `salvar` method to handle invalid exercicios input by setting to null.
- [x] Restore ControleRefeicao.php from backup due to corruption.
- [x] Implement logic for checking achievement criteria in `ControleUsuario.php` for 'passos >= 10000' and 'objetivo_concluido'.
- [x] Update 'objetivo_concluido' logic to check based on current weight reaching target weight instead of date.
- [x] Add missing require_once statements for Objetivo and Medida in login.php to fix class not found error.
- [x] Fix achievement checking to trigger on meal creation and weight updates, not just login.

# TODO for Implementing Calorie Calculation in Workouts

- [x] Add calorie calculation method to ApiTreino.php using MET values and user weight.
- [x] Add method in Treino.php to sum calories for all exercises in a workout.
- [x] Update treinos.php to display total calories in workout cards.
- [x] Update treinos.php to display calories per exercise in suggestions.
- [x] Test the implementation by creating a workout and verifying calorie display.

# TODO for Adding Manual Food Entry Feature

- [x] Add new case 'adicionar_alimento_manual' in refeicoes.php switch statement.
- [x] Add modal for manual food entry in refeicoes.php with fields for name, calories, proteins, carbs, fats, and quantity.
- [x] Add adicionarAlimentoManual method in ControleRefeicao.php to handle manual food addition.
- [x] Verify buscarPorNomeExato method exists in Alimento.php (already exists).
- [x] Test the manual food entry feature by adding a custom food and verifying it appears in the meal.

# TODO for Adding Diet Suggestion Button

- [x] Add "Sugerir Dieta com Base nas Calorias" button in refeicoes.php details view.
- [x] Add JavaScript function to redirect to objetivos.php with confirmation.
- [x] The button redirects to the objectives page where the existing sugerirDieta method calculates suggestions based on user profile and active goals.
