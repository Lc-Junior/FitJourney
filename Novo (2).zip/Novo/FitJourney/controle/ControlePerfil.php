<?php
/**
 * Controlador para perfis
 */
class ControlePerfil {
    private $validador;

    public function __construct() {
        $this->validador = new Validador();
    }

    /**
     * Obtém perfil do usuário logado
     */
    public function getPerfil() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil) {
            return Resposta::erro('Perfil não encontrado.');
        }

        return Resposta::sucesso('Perfil obtido com sucesso.', [
            'idade' => $perfil->getIdade(),
            'sexo' => $perfil->getSexo(),
            'altura' => $perfil->getAltura(),
            'peso' => $perfil->getPeso(),
            'nivel_atividade' => $perfil->getNivelAtividade()
        ]);
    }

    /**
     * Atualiza perfil
     */
    public function atualizar($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        if (!$this->validador->validarPerfil($dados)) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil) {
            $perfil = new Perfil($usuarioId);
        }

        if (isset($dados['idade'])) $perfil->setIdade($dados['idade']);
        if (isset($dados['sexo'])) $perfil->setSexo($dados['sexo']);
        if (isset($dados['altura'])) $perfil->setAltura($dados['altura']);
        if (isset($dados['peso'])) $perfil->setPeso($dados['peso']);
        if (isset($dados['nivel_atividade'])) $perfil->setNivelAtividade($dados['nivel_atividade']);

        if ($perfil->salvar()) {
            return Resposta::sucesso('Perfil atualizado com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar perfil.');
    }

    /**
     * Calcula métricas do perfil
     */
    public function calcularMetricas() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil || !$perfil->getAltura() || !$perfil->getPeso() || !$perfil->getIdade() || !$perfil->getSexo()) {
            return Resposta::erro('Perfil incompleto para calcular métricas.');
        }

        $imc = Funcoes::calcularIMC($perfil->getPeso(), $perfil->getAltura());
        $classificacaoIMC = Funcoes::classificarIMC($imc);

        $tmb = Funcoes::calcularTMB($perfil->getPeso(), $perfil->getAltura(), $perfil->getIdade(), $perfil->getSexo());
        $tdee = Funcoes::calcularTDEE($tmb, $perfil->getNivelAtividade());

        return Resposta::sucesso('Métricas calculadas com sucesso.', [
            'imc' => $imc,
            'classificacao_imc' => $classificacaoIMC,
            'tmb' => round($tmb, 2),
            'tdee' => round($tdee, 2)
        ]);
    }
}
?>
