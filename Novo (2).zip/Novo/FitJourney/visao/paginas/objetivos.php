<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleObjetivo.php';

$titulo = 'Objetivos';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleObjetivo = new ControleObjetivo();

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'cadastrar':
            $resposta = $controleObjetivo->cadastrar(Funcoes::limparEntrada($_POST));
            break;

        case 'atualizar':
            $resposta = $controleObjetivo->atualizar($_POST['id'], Funcoes::limparEntrada($_POST));
            break;

        case 'excluir':
            $resposta = $controleObjetivo->excluir($_POST['id']);
            break;
    }

    if (isset($resposta)) {
        if ($resposta->getSucesso()) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'success';
        } else {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'error';
        }
    }
}

// Obtém dados
$objetivosResposta = $controleObjetivo->listar();
$sugestaoResposta = $controleObjetivo->sugerirDieta();

$objetivos = $objetivosResposta->getSucesso() ? $objetivosResposta->getDados() : [];
$sugestao = $sugestaoResposta->getSucesso() ? $sugestaoResposta->getDados() : null;

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Meus Objetivos</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-objetivo').style.display='block'" class="btn btn-primary">Novo Objetivo</button>
</div>

<div class="card">
    <h2>Objetivos Ativos</h2>
    <?php if (!empty($objetivos)): ?>
        <?php foreach ($objetivos as $objetivo): ?>
            <div class="goal-progress">
                <h4><?php echo ucfirst($objetivo['tipo']); ?> - Meta: <?php echo $objetivo['peso_alvo']; ?> kg</h4>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 0%;"></div>
                </div>
                <p>De <?php echo Funcoes::formatarData($objetivo['data_inicio']); ?> até <?php echo $objetivo['data_fim'] ? Funcoes::formatarData($objetivo['data_fim']) : 'Indefinido'; ?></p>
                <div style="margin-top: 10px;">
                    <button onclick="editarObjetivo(<?php echo $objetivo['id']; ?>, '<?php echo $objetivo['tipo']; ?>', <?php echo $objetivo['peso_alvo']; ?>, '<?php echo $objetivo['data_inicio']; ?>', '<?php echo $objetivo['data_fim']; ?>')" class="btn btn-warning btn-sm">Editar</button>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="acao" value="excluir">
                        <input type="hidden" name="id" value="<?php echo $objetivo['id']; ?>">
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Excluir este objetivo?')">Excluir</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum objetivo definido ainda.</p>
    <?php endif; ?>
</div>

<?php if ($sugestao): ?>
<div class="card">
    <h2>Sugestão de Dieta</h2>
    <div class="dashboard-grid">
        <div class="metric-card">
            <h3>Calorias Totais</h3>
            <div class="value"><?php echo number_format($sugestao['calorias_totais'], 0); ?> kcal</div>
        </div>
        <div class="metric-card">
            <h3>Proteínas</h3>
            <div class="value"><?php echo $sugestao['macronutrientes']['proteinas_g']; ?>g</div>
        </div>
        <div class="metric-card">
            <h3>Carboidratos</h3>
            <div class="value"><?php echo $sugestao['macronutrientes']['carboidratos_g']; ?>g</div>
        </div>
        <div class="metric-card">
            <h3>Gorduras</h3>
            <div class="value"><?php echo $sugestao['macronutrientes']['gorduras_g']; ?>g</div>
        </div>
    </div>

    <h3>Distribuição por Refeição</h3>
    <ul>
        <li><strong>Café da Manhã:</strong> <?php echo number_format($sugestao['distribuicao']['cafe_manha'], 0); ?> kcal</li>
        <li><strong>Almoço:</strong> <?php echo number_format($sugestao['distribuicao']['almoco'], 0); ?> kcal</li>
        <li><strong>Jantar:</strong> <?php echo number_format($sugestao['distribuicao']['jantar'], 0); ?> kcal</li>
        <li><strong>Lanches:</strong> <?php echo number_format($sugestao['distribuicao']['lanches'], 0); ?> kcal</li>
    </ul>
</div>
<?php endif; ?>

<!-- Modal Novo Objetivo -->
<div id="modal-objetivo" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-objetivo').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3 id="modal-title">Novo Objetivo</h3>
        <form method="POST" id="form-objetivo">
            <input type="hidden" name="acao" value="cadastrar" id="acao-objetivo">
            <input type="hidden" name="id" id="objetivo-id">
            <div class="form-group">
                <label for="tipo">Tipo de Objetivo:</label>
                <select id="tipo" name="tipo" required>
                    <option value="emagrecimento">Emagrecimento</option>
                    <option value="manutencao">Manutenção</option>
                    <option value="ganho_massa">Ganho de Massa</option>
                </select>
            </div>
            <div class="form-group">
                <label for="peso_alvo">Peso Alvo (kg):</label>
                <input type="number" id="peso_alvo" name="peso_alvo" step="0.1" min="30" max="300" required>
            </div>
            <div class="form-group">
                <label for="data_inicio">Data de Início:</label>
                <input type="date" id="data_inicio" name="data_inicio" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="data_fim">Data de Fim (opcional):</label>
                <input type="date" id="data_fim" name="data_fim">
            </div>
            <button type="submit" class="btn btn-primary" id="btn-submit">Cadastrar</button>
        </form>
    </div>
</div>

<script>
function editarObjetivo(id, tipo, pesoAlvo, dataInicio, dataFim) {
    document.getElementById('modal-title').textContent = 'Editar Objetivo';
    document.getElementById('acao-objetivo').value = 'atualizar';
    document.getElementById('objetivo-id').value = id;
    document.getElementById('tipo').value = tipo;
    document.getElementById('peso_alvo').value = pesoAlvo;
    document.getElementById('data_inicio').value = dataInicio;
    document.getElementById('data_fim').value = dataFim;
    document.getElementById('btn-submit').textContent = 'Atualizar';
    document.getElementById('modal-objetivo').style.display = 'block';
}

// Reset modal when closed
document.querySelector('#modal-objetivo span').onclick = function() {
    document.getElementById('modal-title').textContent = 'Novo Objetivo';
    document.getElementById('acao-objetivo').value = 'cadastrar';
    document.getElementById('objetivo-id').value = '';
    document.getElementById('form-objetivo').reset();
    document.getElementById('btn-submit').textContent = 'Cadastrar';
    document.getElementById('modal-objetivo').style.display = 'none';
}
</script>

<?php include '../includes/rodape.php'; ?>
