<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleUsuario.php';
require_once '../../controle/ControlePerfil.php';
require_once '../../controle/ControleRefeicao.php';
require_once '../../controle/ControleObjetivo.php';
require_once '../../controle/ControleConquista.php';
require_once '../../controle/ControleNotificacao.php';

$titulo = 'Dashboard';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$usuarioId = Funcoes::getUsuarioLogadoId();

// Obtém dados do dashboard
$controlePerfil = new ControlePerfil();
$perfilResposta = $controlePerfil->getPerfil();

$metricasResposta = $controlePerfil->calcularMetricas();

$controleRefeicao = new ControleRefeicao();
$refeicoesResposta = $controleRefeicao->listar();

$controleObjetivo = new ControleObjetivo();
$objetivosResposta = $controleObjetivo->listar();

$controleConquista = new ControleConquista();
$xpResposta = $controleConquista->calcularXpTotal();

$controleNotificacao = new ControleNotificacao();
$notificacoesResposta = $controleNotificacao->listarNaoLidas();

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Olá, <?php echo $_SESSION['usuario_nome']; ?>!</h2>
    <p>Bem-vindo ao seu painel de controle fitness.</p>
</div>

<?php if ($notificacoesResposta->getSucesso() && !empty($notificacoesResposta->getDados())): ?>
<div class="card">
    <h2>Notificações Recentes</h2>
    <?php foreach ($notificacoesResposta->getDados() as $notificacao): ?>
        <div class="notification-item unread">
            <div class="title"><?php echo htmlspecialchars($notificacao['titulo']); ?></div>
            <div><?php echo htmlspecialchars($notificacao['mensagem']); ?></div>
            <div class="date"><?php echo Funcoes::formatarData($notificacao['data_notificacao']); ?></div>
        </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="dashboard-grid">
    <?php if ($metricasResposta->getSucesso()): ?>
        <?php $metricas = $metricasResposta->getDados(); ?>
        <div class="metric-card">
            <h3>IMC</h3>
            <div class="value"><?php echo number_format($metricas['imc'], 1); ?></div>
            <p><?php echo $metricas['classificacao_imc']; ?></p>
        </div>
        <div class="metric-card">
            <h3>TMB</h3>
            <div class="value"><?php echo number_format($metricas['tmb'], 0); ?> kcal</div>
            <p>Taxa Metabólica Basal</p>
        </div>
        <div class="metric-card">
            <h3>TDEE</h3>
            <div class="value"><?php echo number_format($metricas['tdee'], 0); ?> kcal</div>
            <p>Gasto Energético Total</p>
        </div>
        <div class="metric-card">
            <h3>XP Total</h3>
            <div class="value"><?php echo $xpResposta->getSucesso() ? $xpResposta->getDados()['xp_total'] : 0; ?></div>
            <p>Pontos de experiência</p>
        </div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Refeições de Hoje</h2>
    <?php if ($refeicoesResposta->getSucesso() && !empty($refeicoesResposta->getDados())): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Data</th>
                    <th>Calorias</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $refeicoesHoje = array_filter($refeicoesResposta->getDados(), function($refeicao) {
                    return $refeicao->getDataRefeicao() == date('Y-m-d');
                });
                foreach ($refeicoesHoje as $refeicao):
                ?>
                    <tr>
                        <td><?php echo ucfirst(str_replace('_', ' ', $refeicao->getTipo())); ?></td>
                        <td><?php echo Funcoes::formatarData($refeicao->getDataRefeicao()); ?></td>
                        <td><?php echo number_format($refeicao->calcularCaloriasTotais(), 0); ?> kcal</td>
                        <td>
                            <a href="../paginas/refeicoes.php?action=detalhes&id=<?php echo $refeicao->getId(); ?>" class="btn btn-secondary btn-sm">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhuma refeição registrada hoje. <a href="../paginas/refeicoes.php">Adicionar refeição</a></p>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Objetivos Ativos</h2>
    <?php if ($objetivosResposta->getSucesso() && !empty($objetivosResposta->getDados())): ?>
        <?php foreach ($objetivosResposta->getDados() as $objetivo): ?>
            <div class="goal-progress">
                <h4><?php echo ucfirst($objetivo['tipo']); ?> - Meta: <?php echo $objetivo['peso_alvo']; ?> kg</h4>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: 0%;"></div>
                </div>
                <p>De <?php echo Funcoes::formatarData($objetivo['data_inicio']); ?> até <?php echo $objetivo['data_fim'] ? Funcoes::formatarData($objetivo['data_fim']) : 'Indefinido'; ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>Nenhum objetivo definido. <a href="../paginas/objetivos.php">Definir objetivo</a></p>
    <?php endif; ?>
</div>

<?php include '../includes/rodape.php'; ?>
