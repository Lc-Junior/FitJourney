<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Notificacao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Medida.php';
require_once '../../controle/ControleUsuario.php';

$titulo = 'Login';

// Redireciona se já estiver logado
if (Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('../index.php');
}

$mensagem = '';
$tipoMensagem = '';

// Processa login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $controleUsuario = new ControleUsuario();
    $resposta = $controleUsuario->login(Funcoes::limparEntrada($_POST));

    if ($resposta->getSucesso()) {
        Funcoes::redirecionar('dashboard.php');
    } else {
        $mensagem = $resposta->getMensagem();
        $tipoMensagem = 'error';
    }
}

include '../includes/cabecalho.php';
?>

<div class="auth-form">
    <h2>Fazer Login</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%;">Entrar</button>
    </form>

    <p style="text-align: center; margin-top: 20px;">
        Não tem conta? <a href="../paginas/cadastro.php">Cadastre-se aqui</a>
    </p>
</div>

<?php include '../includes/rodape.php'; ?>
