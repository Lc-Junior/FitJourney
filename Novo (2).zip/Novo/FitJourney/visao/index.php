<?php
require_once '../modelo/DAO/conexao.php';
require_once '../ajudantes/Funcoes.php';
require_once '../ajudantes/Validador.php';
require_once '../ajudantes/Resposta.php';
require_once '../modelo/Usuario.php';
require_once '../modelo/Perfil.php';
require_once '../modelo/Notificacao.php';
require_once '../modelo/Conquista.php';
require_once '../modelo/Refeicao.php';
require_once '../controle/ControleUsuario.php';

$titulo = 'Página Inicial';

// Processa logout
if (isset($_GET['action']) && $_GET['action'] == 'logout') {
    $controleUsuario = new ControleUsuario();
    $resposta = $controleUsuario->logout();
    Funcoes::redirecionar('index.php');
}

include 'includes/cabecalho.php';
?>

<div class="card">
    <h1>Bem-vindo ao FitJourney!</h1>
    <p>Seu sistema completo para acompanhamento físico, nutricional e motivacional.</p>

    <?php if (!Funcoes::usuarioLogado()): ?>
        <div style="text-align: center; margin-top: 30px;">
            <p>Comece sua jornada fitness hoje mesmo!</p>
            <a href="paginas/cadastro.php" class="btn btn-primary" style="margin-right: 10px;">Cadastrar-se</a>
            <a href="paginas/login.php" class="btn btn-secondary">Fazer Login</a>
        </div>
    <?php else: ?>
        <div style="text-align: center; margin-top: 30px;">
            <p>Olá, <?php echo $_SESSION['usuario_nome']; ?>! Continue sua jornada.</p>
            <a href="/Novo/FitJourney/visao/paginas/dashboard.php" class="btn btn-primary">Acessar Dashboard</a>
        </div>
    <?php endif; ?>
</div>

<div class="card">
    <h2>Funcionalidades</h2>
    <div class="dashboard-grid">
        <div class="metric-card">
            <h3>📊 Acompanhamento</h3>
            <p>Monitore seu progresso com métricas detalhadas e gráficos.</p>
        </div>
        <div class="metric-card">
            <h3>🍎 Nutrição</h3>
            <p>Registre refeições, calcule calorias e receba sugestões de dieta.</p>
        </div>
        <div class="metric-card">
            <h3>🎯 Objetivos</h3>
            <p>Defina metas realistas e acompanhe seu progresso.</p>
        </div>
        <div class="metric-card">
            <h3>🏆 Gamificação</h3>
            <p>Ganhe conquistas e XP por suas conquistas fitness.</p>
        </div>
    </div>
</div>

<?php include 'includes/rodape.php'; ?>
