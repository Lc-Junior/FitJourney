<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();

// Teste 1: Buscar autocomplete
echo "=== Teste 1: Autocomplete ===\n";
$result1 = $api->buscarAlimentosSpoonacular('banana', 3);
print_r($result1);

if (!empty($result1) && isset($result1[0]['id'])) {
    $id = $result1[0]['id'];
    echo "\n=== Teste 2: Informações do ingrediente ID: $id ===\n";

    // Busca informações do ingrediente
    $infoUrl = 'https://api.spoonacular.com/food/ingredients/' . $id . '/information?apiKey=82054678cd304c63a35f96e01b204270&amount=100&unit=g';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $infoUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);

    $result2 = json_decode($response, true);
    print_r($result2);
}
?>
