<?php
/**
 * Modelo para a entidade Conquista
 */
class Conquista {
    private $id;
    private $nome;
    private $descricao;
    private $criterio;
    private $xp;

    public function __construct($nome = null, $descricao = null, $criterio = null, $xp = null) {
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->criterio = $criterio;
        $this->xp = $xp;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getNome() { return $this->nome; }
    public function setNome($nome) { $this->nome = $nome; }

    public function getDescricao() { return $this->descricao; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }

    public function getCriterio() { return $this->criterio; }
    public function setCriterio($criterio) { $this->criterio = $criterio; }

    public function getXp() { return $this->xp; }
    public function setXp($xp) { $this->xp = $xp; }

    /**
     * Salva a conquista no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE conquistas SET nome = ?, descricao = ?, criterio = ?, xp = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->descricao, $this->criterio, $this->xp, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO conquistas (nome, descricao, criterio, xp) VALUES (?, ?, ?, ?)");
            $stmt->execute([$this->nome, $this->descricao, $this->criterio, $this->xp]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca conquista por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM conquistas WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $conquista = new Conquista($dados['nome'], $dados['descricao'], $dados['criterio'], $dados['xp']);
            $conquista->setId($dados['id']);
            return $conquista;
        }
        return null;
    }

    /**
     * Lista todas as conquistas
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM conquistas ORDER BY nome");
        $conquistas = [];
        while ($dados = $stmt->fetch()) {
            $conquista = new Conquista($dados['nome'], $dados['descricao'], $dados['criterio'], $dados['xp']);
            $conquista->setId($dados['id']);
            $conquistas[] = $conquista;
        }
        return $conquistas;
    }

    /**
     * Exclui a conquista
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM conquistas WHERE id = ?");
        return $stmt->execute([$this->id]);
    }

    /**
     * Verifica se o usuário desbloqueou a conquista
     */
    public function usuarioDesbloqueou($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios_conquistas WHERE usuario_id = ? AND conquista_id = ?");
        $stmt->execute([$usuarioId, $this->id]);
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Desbloqueia a conquista para o usuário
     */
    public function desbloquearParaUsuario($usuarioId) {
        if ($this->usuarioDesbloqueou($usuarioId)) {
            return false; // Já desbloqueada
        }
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("INSERT INTO usuarios_conquistas (usuario_id, conquista_id) VALUES (?, ?)");
        return $stmt->execute([$usuarioId, $this->id]);
    }
}
?>
