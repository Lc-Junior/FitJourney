<?php
/**
 * Modelo para a entidade Usuario
 */
class Usuario {
    private $id;
    private $nome;
    private $email;
    private $senha;
    private $dataCadastro;
    private $ativo;

    public function __construct($nome = null, $email = null, $senha = null) {
        $this->nome = $nome;
        $this->email = $email;
        if (!empty($senha)) {
            $this->senha = password_hash($senha, PASSWORD_DEFAULT);
        } else {
            $this->senha = $senha;
        }
        $this->ativo = true;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getNome() { return $this->nome; }
    public function setNome($nome) { $this->nome = $nome; }

    public function getEmail() { return $this->email; }
    public function setEmail($email) { $this->email = $email; }

    public function getSenha() { return $this->senha; }
    public function setSenha($senha) {
        if (!empty($senha)) {
            $this->senha = password_hash($senha, PASSWORD_DEFAULT);
        }
    }

    public function getDataCadastro() { return $this->dataCadastro; }
    public function setDataCadastro($dataCadastro) { $this->dataCadastro = $dataCadastro; }

    public function getAtivo() { return $this->ativo; }
    public function setAtivo($ativo) { $this->ativo = $ativo; }

    /**
     * Salva o usuário no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE usuarios SET nome = ?, email = ?, ativo = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->email, $this->ativo, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
            $stmt->execute([$this->nome, $this->email, $this->senha]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca usuário por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $usuario = new Usuario($dados['nome'], $dados['email'], null);
            $usuario->setId($dados['id']);
            $usuario->setDataCadastro($dados['data_cadastro']);
            $usuario->setAtivo($dados['ativo']);
            $usuario->senha = $dados['senha']; // Set the hashed password directly
            return $usuario;
        }
        return null;
    }

    /**
     * Busca usuário por email
     */
    public static function buscarPorEmail($email) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $dados = $stmt->fetch();
        if ($dados) {
            $usuario = new Usuario($dados['nome'], $dados['email'], null);
            $usuario->setId($dados['id']);
            $usuario->setDataCadastro($dados['data_cadastro']);
            $usuario->setAtivo($dados['ativo']);
            $usuario->senha = $dados['senha']; // Set the hashed password directly
            return $usuario;
        }
        return null;
    }

    /**
     * Verifica senha
     */
    public function verificarSenha($senha) {
        return password_verify($senha, $this->senha);
    }

    /**
     * Lista todos os usuários
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM usuarios ORDER BY nome");
        $usuarios = [];
        while ($dados = $stmt->fetch()) {
            $usuario = new Usuario($dados['nome'], $dados['email'], null);
            $usuario->setId($dados['id']);
            $usuario->setDataCadastro($dados['data_cadastro']);
            $usuario->setAtivo($dados['ativo']);
            $usuario->senha = $dados['senha']; // Set the hashed password directly
            $usuarios[] = $usuario;
        }
        return $usuarios;
    }

    /**
     * Exclui o usuário
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
