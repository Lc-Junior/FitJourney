<?php
/**
 * Modelo para a entidade Objetivo
 */
class Objetivo {
    private $id;
    private $usuarioId;
    private $tipo;
    private $pesoAlvo;
    private $dataInicio;
    private $dataFim;

    public function __construct($usuarioId = null, $tipo = null, $pesoAlvo = null, $dataInicio = null, $dataFim = null) {
        $this->usuarioId = $usuarioId;
        $this->tipo = $tipo;
        $this->pesoAlvo = $pesoAlvo;
        $this->dataInicio = $dataInicio;
        $this->dataFim = $dataFim;
    }

    // Getters e Setters
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }

    public function getUsuarioId() { return $this->usuarioId; }
    public function setUsuarioId($usuarioId) { $this->usuarioId = $usuarioId; }

    public function getTipo() { return $this->tipo; }
    public function setTipo($tipo) { $this->tipo = $tipo; }

    public function getPesoAlvo() { return $this->pesoAlvo; }
    public function setPesoAlvo($pesoAlvo) { $this->pesoAlvo = $pesoAlvo; }

    public function getDataInicio() { return $this->dataInicio; }
    public function setDataInicio($dataInicio) { $this->dataInicio = $dataInicio; }

    public function getDataFim() { return $this->dataFim; }
    public function setDataFim($dataFim) { $this->dataFim = $dataFim; }

    /**
     * Salva o objetivo no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();
        if ($this->id) {
            // Atualizar
            $stmt = $pdo->prepare("UPDATE objetivos SET tipo = ?, peso_alvo = ?, data_inicio = ?, data_fim = ? WHERE id = ?");
            return $stmt->execute([$this->tipo, $this->pesoAlvo, $this->dataInicio, $this->dataFim, $this->id]);
        } else {
            // Inserir
            $stmt = $pdo->prepare("INSERT INTO objetivos (usuario_id, tipo, peso_alvo, data_inicio, data_fim) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$this->usuarioId, $this->tipo, $this->pesoAlvo, $this->dataInicio, $this->dataFim]);
            $this->id = $pdo->lastInsertId();
            return true;
        }
    }

    /**
     * Busca objetivos por ID do usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM objetivos WHERE usuario_id = ? ORDER BY data_inicio DESC");
        $stmt->execute([$usuarioId]);
        $objetivos = [];
        while ($dados = $stmt->fetch()) {
            $objetivo = new Objetivo($dados['usuario_id'], $dados['tipo'], $dados['peso_alvo'], $dados['data_inicio'], $dados['data_fim']);
            $objetivo->setId($dados['id']);
            $objetivos[] = $objetivo;
        }
        return $objetivos;
    }

    /**
     * Lista todos os objetivos
     */
    public static function listarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->query("SELECT * FROM objetivos ORDER BY data_inicio DESC");
        $objetivos = [];
        while ($dados = $stmt->fetch()) {
            $objetivo = new Objetivo($dados['usuario_id'], $dados['tipo'], $dados['peso_alvo'], $dados['data_inicio'], $dados['data_fim']);
            $objetivo->setId($dados['id']);
            $objetivos[] = $objetivo;
        }
        return $objetivos;
    }

    /**
     * Busca objetivo por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM objetivos WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();
        if ($dados) {
            $objetivo = new Objetivo($dados['usuario_id'], $dados['tipo'], $dados['peso_alvo'], $dados['data_inicio'], $dados['data_fim']);
            $objetivo->setId($dados['id']);
            return $objetivo;
        }
        return null;
    }

    /**
     * Exclui o objetivo
     */
    public function excluir() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM objetivos WHERE id = ?");
        return $stmt->execute([$this->id]);
    }
}
?>
