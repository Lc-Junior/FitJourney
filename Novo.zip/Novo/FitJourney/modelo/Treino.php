<?php
require_once 'DAO/conexao.php';

/**
 * Modelo para treinos
 */
class Treino {
    private $id;
    private $usuarioId;
    private $nome;
    private $descricao;
    private $tipo;
    private $duracaoEstimada;
    private $dataCriacao;

    public function __construct($usuarioId, $nome, $descricao = null, $tipo = 'equilibrado', $duracaoEstimada = null) {
        $this->usuarioId = $usuarioId;
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->tipo = $tipo;
        $this->duracaoEstimada = $duracaoEstimada;
    }

    // Getters
    public function getId() { return $this->id; }
    public function getUsuarioId() { return $this->usuarioId; }
    public function getNome() { return $this->nome; }
    public function getDescricao() { return $this->descricao; }
    public function getTipo() { return $this->tipo; }
    public function getDuracaoEstimada() { return $this->duracaoEstimada; }
    public function getDataCriacao() { return $this->dataCriacao; }

    // Setters
    public function setNome($nome) { $this->nome = $nome; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }
    public function setTipo($tipo) { $this->tipo = $tipo; }
    public function setDuracaoEstimada($duracaoEstimada) { $this->duracaoEstimada = $duracaoEstimada; }

    /**
     * Salva o treino no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();

        if ($this->id) {
            // Update
            $stmt = $pdo->prepare("UPDATE treinos SET nome = ?, descricao = ?, tipo = ?, duracao_estimada = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->descricao, $this->tipo, $this->duracaoEstimada, $this->id]);
        } else {
            // Insert
            $stmt = $pdo->prepare("INSERT INTO treinos (usuario_id, nome, descricao, tipo, duracao_estimada) VALUES (?, ?, ?, ?, ?)");
            $result = $stmt->execute([$this->usuarioId, $this->nome, $this->descricao, $this->tipo, $this->duracaoEstimada]);
            if ($result) {
                $this->id = $pdo->lastInsertId();
            }
            return $result;
        }
    }

    /**
     * Busca treino por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM treinos WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();

        if ($dados) {
            $treino = new Treino($dados['usuario_id'], $dados['nome'], $dados['descricao'], $dados['tipo'], $dados['duracao_estimada']);
            $treino->id = $dados['id'];
            $treino->dataCriacao = $dados['data_criacao'];
            return $treino;
        }

        return null;
    }

    /**
     * Busca treinos por usuário
     */
    public static function buscarPorUsuarioId($usuarioId) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM treinos WHERE usuario_id = ? ORDER BY data_criacao DESC");
        $stmt->execute([$usuarioId]);
        $treinos = [];

        while ($dados = $stmt->fetch()) {
            $treino = new Treino($dados['usuario_id'], $dados['nome'], $dados['descricao'], $dados['tipo'], $dados['duracao_estimada']);
            $treino->id = $dados['id'];
            $treino->dataCriacao = $dados['data_criacao'];
            $treinos[] = $treino;
        }

        return $treinos;
    }

    /**
     * Busca treinos sugeridos por tipo de objetivo
     */
    public static function buscarPorTipoObjetivo($tipoObjetivo) {
        $pdo = Conexao::getInstancia()->getPDO();

        // Mapeamento de objetivos para tipos de treino
        $mapeamento = [
            'emagrecimento' => ['cardio', 'equilibrado'],
            'manutencao' => ['equilibrado', 'forca'],
            'ganho_massa' => ['forca', 'equilibrado']
        ];

        $tiposTreino = $mapeamento[$tipoObjetivo] ?? ['equilibrado'];

        $placeholders = str_repeat('?,', count($tiposTreino) - 1) . '?';
        $stmt = $pdo->prepare("SELECT * FROM treinos WHERE tipo IN ($placeholders) ORDER BY data_criacao DESC");
        $stmt->execute($tiposTreino);
        $treinos = [];

        while ($dados = $stmt->fetch()) {
            $treino = new Treino($dados['usuario_id'], $dados['nome'], $dados['descricao'], $dados['tipo'], $dados['duracao_estimada']);
            $treino->id = $dados['id'];
            $treino->dataCriacao = $dados['data_criacao'];
            $treinos[] = $treino;
        }

        return $treinos;
    }

    /**
     * Exclui o treino
     */
    public function excluir() {
        if (!$this->id) return false;

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM treinos WHERE id = ?");
        return $stmt->execute([$this->id]);
    }

    /**
     * Adiciona exercício ao treino
     */
    public function adicionarExercicio($exercicioId, $series, $repeticoes, $descanso, $ordem = null) {
        if (!$this->id) return false;

        $pdo = Conexao::getInstancia()->getPDO();

        // Se não especificar ordem, colocar no final
        if ($ordem === null) {
            $stmt = $pdo->prepare("SELECT MAX(ordem) as max_ordem FROM treinos_exercicios WHERE treino_id = ?");
            $stmt->execute([$this->id]);
            $resultado = $stmt->fetch();
            $ordem = ($resultado['max_ordem'] ?? 0) + 1;
        }

        $stmt = $pdo->prepare("INSERT INTO treinos_exercicios (treino_id, exercicio_id, series, repeticoes, descanso, ordem) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$this->id, $exercicioId, $series, $repeticoes, $descanso, $ordem]);
    }

    /**
     * Remove exercício do treino
     */
    public function removerExercicio($exercicioId) {
        if (!$this->id) return false;

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM treinos_exercicios WHERE treino_id = ? AND exercicio_id = ?");
        return $stmt->execute([$this->id, $exercicioId]);
    }

    /**
     * Busca exercícios do treino
     */
    public function getExercicios() {
        if (!$this->id) return [];

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("
            SELECT te.*, e.nome, e.descricao, e.grupo_muscular, e.equipamento, e.dificuldade
            FROM treinos_exercicios te
            JOIN exercicios e ON te.exercicio_id = e.id
            WHERE te.treino_id = ?
            ORDER BY te.ordem
        ");
        $stmt->execute([$this->id]);
        return $stmt->fetchAll();
    }

    /**
     * Calcula duração total estimada baseada nos exercícios
     */
    public function calcularDuracaoTotal() {
        $exercicios = $this->getExercicios();
        $duracaoTotal = 0;

        foreach ($exercicios as $exercicio) {
            // Estimativa: 30 segundos por série + descanso
            $tempoPorSerie = 30 + $exercicio['descanso'];
            $duracaoTotal += $exercicio['series'] * $tempoPorSerie;
        }

        // Adicionar 5 minutos de aquecimento e 5 de alongamento
        $duracaoTotal += 600;

        return ceil($duracaoTotal / 60); // em minutos
    }
}
?>
