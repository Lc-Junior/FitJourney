<?php
require_once 'DAO/conexao.php';

/**
 * Modelo para exercícios
 */
class Exercicio {
    private $id;
    private $nome;
    private $descricao;
    private $grupoMuscular;
    private $equipamento;
    private $dificuldade;

    public function __construct($nome, $descricao = null, $grupoMuscular = null, $equipamento = null, $dificuldade = 'intermediario') {
        $this->nome = $nome;
        $this->descricao = $descricao;
        $this->grupoMuscular = $grupoMuscular;
        $this->equipamento = $equipamento;
        $this->dificuldade = $dificuldade;
    }

    // Getters
    public function getId() { return $this->id; }
    public function getNome() { return $this->nome; }
    public function getDescricao() { return $this->descricao; }
    public function getGrupoMuscular() { return $this->grupoMuscular; }
    public function getEquipamento() { return $this->equipamento; }
    public function getDificuldade() { return $this->dificuldade; }

    // Setters
    public function setNome($nome) { $this->nome = $nome; }
    public function setDescricao($descricao) { $this->descricao = $descricao; }
    public function setGrupoMuscular($grupoMuscular) { $this->grupoMuscular = $grupoMuscular; }
    public function setEquipamento($equipamento) { $this->equipamento = $equipamento; }
    public function setDificuldade($dificuldade) { $this->dificuldade = $dificuldade; }

    /**
     * Salva o exercício no banco de dados
     */
    public function salvar() {
        $pdo = Conexao::getInstancia()->getPDO();

        if ($this->id) {
            // Update
            $stmt = $pdo->prepare("UPDATE exercicios SET nome = ?, descricao = ?, grupo_muscular = ?, equipamento = ?, dificuldade = ? WHERE id = ?");
            return $stmt->execute([$this->nome, $this->descricao, $this->grupoMuscular, $this->equipamento, $this->dificuldade, $this->id]);
        } else {
            // Insert
            $stmt = $pdo->prepare("INSERT INTO exercicios (nome, descricao, grupo_muscular, equipamento, dificuldade) VALUES (?, ?, ?, ?, ?)");
            $result = $stmt->execute([$this->nome, $this->descricao, $this->grupoMuscular, $this->equipamento, $this->dificuldade]);
            if ($result) {
                $this->id = $pdo->lastInsertId();
            }
            return $result;
        }
    }

    /**
     * Busca exercício por ID
     */
    public static function buscarPorId($id) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios WHERE id = ?");
        $stmt->execute([$id]);
        $dados = $stmt->fetch();

        if ($dados) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            return $exercicio;
        }

        return null;
    }

    /**
     * Busca todos os exercícios
     */
    public static function buscarTodos() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios ORDER BY nome");
        $stmt->execute();
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicio;
        }

        return $exercicios;
    }

    /**
     * Busca exercícios por grupo muscular
     */
    public static function buscarPorGrupoMuscular($grupoMuscular) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios WHERE grupo_muscular = ? ORDER BY nome");
        $stmt->execute([$grupoMuscular]);
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicio;
        }

        return $exercicios;
    }

    /**
     * Busca exercícios por dificuldade
     */
    public static function buscarPorDificuldade($dificuldade) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios WHERE dificuldade = ? ORDER BY nome");
        $stmt->execute([$dificuldade]);
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicio;
        }

        return $exercicios;
    }

    /**
     * Busca exercícios por equipamento necessário
     */
    public static function buscarPorEquipamento($equipamento) {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios WHERE equipamento LIKE ? ORDER BY nome");
        $stmt->execute(['%' . $equipamento . '%']);
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicio;
        }

        return $exercicios;
    }

    /**
     * Busca exercícios sem equipamento
     */
    public static function buscarSemEquipamento() {
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("SELECT * FROM exercicios WHERE equipamento IS NULL OR equipamento = '' ORDER BY nome");
        $stmt->execute();
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicios;
        }

        return $exercicios;
    }

    /**
     * Exclui o exercício
     */
    public function excluir() {
        if (!$this->id) return false;

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM exercicios WHERE id = ?");
        return $stmt->execute([$this->id]);
    }

    /**
     * Busca exercícios sugeridos para um objetivo
     */
    public static function sugerirPorObjetivo($tipoObjetivo, $nivelAtividade = 'moderado') {
        $pdo = Conexao::getInstancia()->getPDO();

        // Mapeamento de objetivos para grupos musculares prioritários
        $mapeamentoObjetivos = [
            'emagrecimento' => ['cardio', 'pernas', 'core'],
            'manutencao' => ['peito', 'costas', 'pernas', 'ombros'],
            'ganho_massa' => ['peito', 'costas', 'pernas', 'ombros', 'bracos']
        ];

        $gruposPrioritarios = $mapeamentoObjetivos[$tipoObjetivo] ?? ['peito', 'costas', 'pernas'];

        // Mapeamento de nível de atividade para dificuldade
        $mapeamentoDificuldade = [
            'sedentario' => ['iniciante'],
            'leve' => ['iniciante', 'intermediario'],
            'moderado' => ['iniciante', 'intermediario', 'avancado'],
            'ativo' => ['intermediario', 'avancado'],
            'muito_ativo' => ['avancado']
        ];

        $dificuldades = $mapeamentoDificuldade[$nivelAtividade] ?? ['iniciante', 'intermediario'];

        // Construir query dinâmica
        $gruposPlaceholders = str_repeat('?,', count($gruposPrioritarios) - 1) . '?';
        $dificuldadesPlaceholders = str_repeat('?,', count($dificuldades) - 1) . '?';

        $stmt = $pdo->prepare("
            SELECT * FROM exercicios
            WHERE grupo_muscular IN ($gruposPlaceholders)
            AND dificuldade IN ($dificuldadesPlaceholders)
            ORDER BY FIELD(grupo_muscular, " . implode(',', array_fill(0, count($gruposPrioritarios), '?')) . "), dificuldade
        ");

        $params = array_merge($gruposPrioritarios, $dificuldades, $gruposPrioritarios);
        $stmt->execute($params);
        $exercicios = [];

        while ($dados = $stmt->fetch()) {
            $exercicio = new Exercicio($dados['nome'], $dados['descricao'], $dados['grupo_muscular'], $dados['equipamento'], $dados['dificuldade']);
            $exercicio->id = $dados['id'];
            $exercicios[] = $exercicio;
        }

        return $exercicios;
    }
}
?>
