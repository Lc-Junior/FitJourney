# TODO: Implement Interactive Feed Feature for FitJourney

## Steps to Complete
- [x] Update fitjourney.sql to add new tables: posts, likes, comments
- [x] Create modelo/Post.php for post CRUD operations
- [x] Create modelo/Like.php for like management
- [x] Create modelo/Comment.php for comment management
- [x] Create controle/ControleFeed.php with methods for feed display, posting (with photo upload), liking, commenting, editing posts (owner only), deleting posts (owner only)
- [x] Create visao/paginas/feed.php as the main feed view with forms for posting, liking, commenting, editing, deleting
- [x] Update visao/includes/cabecalho.php to add navigation link to feed
- [x] Create visao/uploads/posts/ directory for photo storage
- [x] Update CSS in visao/css/estilo.css or inline in feed.php to match fitness theme (e.g., incorporate existing colors/styles)
- [x] Test the feed page: login, post text/photos, view posts, like, comment, edit/delete own posts
- [x] Verify photo uploads (file types, sizes, security)
- [x] Run app locally via XAMPP and use browser to verify UI/interactions
- [x] Debug any issues (e.g., database errors, permissions)
