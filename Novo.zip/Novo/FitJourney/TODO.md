# FitJourney - Funcionalidades Pendentes

## ✅ Implementado
- [x] Cadastro e autenticação de usuários
- [x] Registro de informações pessoais (Perfil)
- [x] Cadastro de alimentos e refeições com cálculo automático de calorias e macronutrientes
- [x] Definição de metas (Objetivos)
- [x] Sugestão automática de dietas baseada no objetivo do usuário
- [x] Sistema de conquistas
- [x] Feed social com posts, curtidas e comentários
- [x] Notificações do sistema

## 🔄 Em Desenvolvimento
- [ ] Sugestão automática de treinos de acordo com o objetivo do usuário
- [ ] Acompanhamento de progresso (medidas corporais)
- [ ] Relatórios personalizados sobre desempenho e rotina
- [ ] Histórico do usuário com comparativo entre dias, semanas e meses

## 📋 Próximos Passos

### 1. Sistema de Treinos
- [ ] Criar modelo Treino.php
- [ ] Criar modelo Exercicio.php
- [ ] Criar controlador ControleTreino.php
- [ ] Adicionar tabelas no banco: treinos, exercicios, treinos_exercicios
- [ ] Implementar lógica de sugestão de treinos baseada no objetivo
- [ ] Criar página de treinos na interface

### 2. Acompanhamento de Progresso
- [ ] Melhorar modelo Medida.php (já existe tabela medidas)
- [ ] Criar controlador ControleProgresso.php
- [ ] Adicionar funcionalidade de fotos de progresso
- [ ] Criar gráficos de evolução
- [ ] Página de acompanhamento de progresso

### 3. Relatórios e Analytics
- [ ] Criar controlador ControleRelatorio.php
- [ ] Implementar relatórios diários/semanais/mensais
- [ ] Gráficos de progresso (peso, medidas, calorias)
- [ ] Comparativos históricos
- [ ] Exportação de relatórios

### 4. Histórico Comparativo
- [ ] Melhorar queries para análise histórica
- [ ] Implementar comparações período a período
- [ ] Dashboard com métricas históricas
- [ ] Tendências e projeções

## 🗂️ Estrutura de Arquivos Necessária

### Modelos (modelo/)
- Treino.php
- Exercicio.php
- Progresso.php (extensão de Medida)

### Controladores (controle/)
- ControleTreino.php
- ControleProgresso.php
- ControleRelatorio.php

### Views (visao/paginas/)
- treinos.php
- progresso.php
- relatorios.php
- historico.php

### Banco de Dados
```sql
-- Tabelas adicionais necessárias
CREATE TABLE treinos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    tipo ENUM('forca', 'cardio', 'flexibilidade', 'equilibrado'),
    duracao_estimada INT, -- em minutos
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE exercicios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    grupo_muscular VARCHAR(50),
    equipamento VARCHAR(100),
    dificuldade ENUM('iniciante', 'intermediario', 'avancado')
);

CREATE TABLE treinos_exercicios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    treino_id INT NOT NULL,
    exercicio_id INT NOT NULL,
    series INT,
    repeticoes VARCHAR(20), -- "10-12" ou "até falha"
    descanso INT, -- em segundos
    ordem INT, -- ordem no treino
    FOREIGN KEY (treino_id) REFERENCES treinos(id) ON DELETE CASCADE,
    FOREIGN KEY (exercicio_id) REFERENCES exercicios(id) ON DELETE CASCADE
);

CREATE TABLE progresso_fotos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_foto DATE NOT NULL,
    caminho_foto VARCHAR(255),
    tipo ENUM('frente', 'lado', 'costas'),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
```

## 🎯 Prioridades
1. Sistema de treinos (funcionalidade principal faltante)
2. Acompanhamento de progresso (métricas importantes)
3. Relatórios e histórico (análise de dados)
