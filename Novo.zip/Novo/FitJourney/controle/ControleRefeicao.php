<?php
require_once '../../ajudantes/ApiNutricao.php';

/**
 * Controlador para refeições
 */
class ControleRefeicao {
    private $validador;
    private $apiNutricao;

    public function __construct() {
        $this->validador = new Validador();
        $this->apiNutricao = new ApiNutricao();
    }

    /**
     * Lista refeições do usuário
     */
    public function listar() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $refeicoes = Refeicao::buscarPorUsuarioId($usuarioId);
        $dados = [];

        foreach ($refeicoes as $refeicao) {
            $dados[] = [
                'id' => $refeicao->getId(),
                'tipo' => $refeicao->getTipo(),
                'data_refeicao' => $refeicao->getDataRefeicao(),
                'hora_refeicao' => $refeicao->getHoraRefeicao(),
                'calorias_totais' => $refeicao->calcularCaloriasTotais()
            ];
        }

        return Resposta::sucesso('Refeições listadas com sucesso.', $dados);
    }

    /**
     * Cadastra nova refeição
     */
    public function cadastrar($dados) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Validações básicas
        $this->validador->naoVazio($dados['tipo'] ?? '', 'tipo');
        $this->validador->naoVazio($dados['data_refeicao'] ?? '', 'data da refeição');
        $this->validador->data($dados['data_refeicao'] ?? '', 'data da refeição');

        $tipos = ['cafe_manha', 'almoco', 'jantar', 'lanche'];
        if (isset($dados['tipo'])) {
            $this->validador->emLista($dados['tipo'], 'tipo', $tipos);
        }

        if (isset($dados['hora_refeicao']) && !empty($dados['hora_refeicao'])) {
            $this->validador->hora($dados['hora_refeicao'], 'hora da refeição');
        }

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $refeicao = new Refeicao($usuarioId, $dados['tipo'], $dados['data_refeicao'], $dados['hora_refeicao'] ?? null);
        if ($refeicao->salvar()) {
            return Resposta::sucesso('Refeição cadastrada com sucesso.', ['id' => $refeicao->getId()]);
        }

        return Resposta::erro('Erro ao cadastrar refeição.');
    }

    /**
     * Adiciona alimento à refeição
     */
    public function adicionarAlimento($refeicaoId, $alimentoId, $quantidade) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Verifica se a refeição pertence ao usuário
        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        // Verifica se o alimento existe
        $alimento = Alimento::buscarPorId($alimentoId);
        if (!$alimento) {
            return Resposta::erro('Alimento não encontrado.');
        }

        // Valida quantidade
        $this->validador->numerico($quantidade, 'quantidade');
        $this->validador->positivo($quantidade, 'quantidade');

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("INSERT INTO itens_refeicao (refeicao_id, alimento_id, quantidade) VALUES (?, ?, ?)");
        if ($stmt->execute([$refeicaoId, $alimentoId, $quantidade])) {
            return Resposta::sucesso('Alimento adicionado à refeição com sucesso.');
        }

        return Resposta::erro('Erro ao adicionar alimento.');
    }

    /**
     * Remove alimento da refeição
     */
    public function removerAlimento($refeicaoId, $alimentoId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Verifica se a refeição pertence ao usuário
        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("DELETE FROM itens_refeicao WHERE refeicao_id = ? AND alimento_id = ?");
        if ($stmt->execute([$refeicaoId, $alimentoId])) {
            return Resposta::sucesso('Alimento removido da refeição com sucesso.');
        }

        return Resposta::erro('Erro ao remover alimento.');
    }

    /**
     * Edita quantidade do alimento na refeição
     */
    public function editarAlimento($refeicaoId, $alimentoId, $quantidade) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Verifica se a refeição pertence ao usuário
        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        // Valida quantidade
        $this->validador->numerico($quantidade, 'quantidade');
        $this->validador->positivo($quantidade, 'quantidade');

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("UPDATE itens_refeicao SET quantidade = ? WHERE refeicao_id = ? AND alimento_id = ?");
        if ($stmt->execute([$quantidade, $refeicaoId, $alimentoId])) {
            return Resposta::sucesso('Quantidade do alimento atualizada com sucesso.');
        }

        return Resposta::erro('Erro ao atualizar quantidade.');
    }

    /**
     * Obtém detalhes da refeição
     */
    public function getDetalhes($refeicaoId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        // Busca itens da refeição
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("
            SELECT i.quantidade, a.id as alimento_id, a.nome, a.calorias, a.proteinas, a.carboidratos, a.gorduras
            FROM itens_refeicao i
            JOIN alimentos a ON i.alimento_id = a.id
            WHERE i.refeicao_id = ?
        ");
        $stmt->execute([$refeicaoId]);
        $itens = $stmt->fetchAll();

        return Resposta::sucesso('Detalhes obtidos com sucesso.', [
            'refeicao' => [
                'id' => $refeicao->getId(),
                'tipo' => $refeicao->getTipo(),
                'data_refeicao' => $refeicao->getDataRefeicao(),
                'hora_refeicao' => $refeicao->getHoraRefeicao(),
                'calorias_totais' => $refeicao->calcularCaloriasTotais()
            ],
            'itens' => $itens
        ]);
    }

    /**
     * Busca alimentos via API
     */
    public function buscarAlimentosAPI($termo) {
        if (empty($termo)) {
            return Resposta::erro('Termo de busca não informado.');
        }

        $alimentos = $this->apiNutricao->buscarAlimentos($termo);

        if (empty($alimentos)) {
            return Resposta::erro('Nenhum alimento encontrado.');
        }

        return Resposta::sucesso('Alimentos encontrados.', $alimentos);
    }

    /**
     * Calcula nutrientes de uma refeição via API
     */
    public function calcularNutrientesAPI($alimentos) {
        if (empty($alimentos) || !is_array($alimentos)) {
            return Resposta::erro('Lista de alimentos inválida.');
        }

        $nutrientes = $this->apiNutricao->calcularRefeicao($alimentos);

        if (!$nutrientes) {
            return Resposta::erro('Erro ao calcular nutrientes.');
        }

        return Resposta::sucesso('Nutrientes calculados com sucesso.', $nutrientes);
    }

    /**
     * Adiciona alimento customizado à refeição (via API)
     */
    public function adicionarAlimentoCustomizado($refeicaoId, $nomeAlimento, $quantidade, $unidade = 'g') {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Verifica se a refeição pertence ao usuário
        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        // Validações
        $this->validador->naoVazio($nomeAlimento, 'nome do alimento');
        $this->validador->numerico($quantidade, 'quantidade');
        $this->validador->positivo($quantidade, 'quantidade');

        if ($this->validador->temErros()) {
            return Resposta::erro('Dados inválidos: ' . implode(', ', $this->validador->getErros()));
        }

        // Busca nutrientes via API
        $descricao = $quantidade . $unidade . ' ' . $nomeAlimento;
        $nutrientes = $this->apiNutricao->obterNutrientes($descricao);

        if (!$nutrientes) {
            return Resposta::erro('Não foi possível obter informações nutricionais do alimento.');
        }

        // Salva ou atualiza alimento no banco
        $alimento = Alimento::buscarPorNomeExato($nomeAlimento);
        if (!$alimento) {
            // Cria novo alimento
            $alimento = new Alimento($nomeAlimento, $nutrientes['calorias'], $nutrientes['proteinas'], $nutrientes['carboidratos'], $nutrientes['gorduras']);
            $alimento->salvar();
        }

        // Adiciona à refeição
        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("INSERT INTO itens_refeicao (refeicao_id, alimento_id, quantidade) VALUES (?, ?, ?)");
        if ($stmt->execute([$refeicaoId, $alimento->getId(), $quantidade])) {
            return Resposta::sucesso('Alimento adicionado à refeição com sucesso.', [
                'alimento' => $nutrientes,
                'calorias_adicionadas' => $nutrientes['calorias']
            ]);
        }

        return Resposta::erro('Erro ao adicionar alimento.');
    }

    /**
     * Exclui refeição
     */
    public function excluir($refeicaoId) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $refeicao = Refeicao::buscarPorId($refeicaoId);
        if (!$refeicao || $refeicao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Refeição não encontrada.');
        }

        if ($refeicao->excluir()) {
            return Resposta::sucesso('Refeição excluída com sucesso.');
        }

        return Resposta::erro('Erro ao excluir refeição.');
    }

    /**
     * Gera sugestões de alimentos para uma refeição
     */
    public function sugerirAlimentosRefeicao($tipoRefeicao, $caloriasObjetivo, $macronutrientesObjetivo = null) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Validações
        $tiposValidos = ['cafe_manha', 'almoco', 'jantar', 'lanche'];
        if (!in_array($tipoRefeicao, $tiposValidos)) {
            return Resposta::erro('Tipo de refeição inválido.');
        }

        if (!is_numeric($caloriasObjetivo) || $caloriasObjetivo <= 0) {
            return Resposta::erro('Calorias objetivo deve ser um número positivo.');
        }

        // Busca sugestões usando Spoonacular
        $sugestoes = $this->apiNutricao->sugerirAlimentosRefeicao($tipoRefeicao, $caloriasObjetivo, $macronutrientesObjetivo);

        if (empty($sugestoes)) {
            return Resposta::erro('Não foi possível gerar sugestões de alimentos.');
        }

        return Resposta::sucesso('Sugestões de alimentos geradas com sucesso.', [
            'tipo_refeicao' => $tipoRefeicao,
            'calorias_objetivo' => $caloriasObjetivo,
            'macronutrientes_objetivo' => $macronutrientesObjetivo,
            'sugestoes' => $sugestoes
        ]);
    }

    /**
     * Gera sugestões de alimentos para uma refeição baseada no perfil do usuário
     */
    public function sugerirAlimentos($tipoRefeicao) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        // Obtém perfil do usuário
        $perfil = Perfil::buscarPorUsuarioId($usuarioId);
        if (!$perfil) {
            return Resposta::erro('Perfil não encontrado. Complete seu perfil para receber sugestões personalizadas.');
        }

        // Obtém objetivo ativo
        $objetivos = Objetivo::buscarPorUsuarioId($usuarioId);
        $objetivoAtivo = null;
        foreach ($objetivos as $obj) {
            if (!$obj->getDataFim() || strtotime($obj->getDataFim()) >= time()) {
                $objetivoAtivo = $obj;
                break;
            }
        }

        if (!$objetivoAtivo) {
            return Resposta::erro('Nenhum objetivo ativo encontrado. Defina um objetivo para receber sugestões.');
        }

        // Calcula calorias diárias necessárias
        $tmb = Funcoes::calcularTMB($perfil->getPeso(), $perfil->getAltura(), $perfil->getIdade(), $perfil->getSexo());
        $tdee = Funcoes::calcularTDEE($tmb, $perfil->getNivelAtividade());
        $caloriasDiarias = Funcoes::calcularCaloriasObjetivo($tdee, $objetivoAtivo->getTipo());

        // Distribuição de calorias por refeição
        $distribuicao = [
            'cafe_manha' => round($caloriasDiarias * 0.25),
            'almoco' => round($caloriasDiarias * 0.35),
            'jantar' => round($caloriasDiarias * 0.30),
            'lanche' => round($caloriasDiarias * 0.10)
        ];

        $caloriasObjetivo = $distribuicao[$tipoRefeicao] ?? round($caloriasDiarias * 0.25);

        // Gera sugestões usando Spoonacular
        $sugestoes = $this->apiNutricao->sugerirAlimentosRefeicao($tipoRefeicao, $caloriasObjetivo);

        if (empty($sugestoes)) {
            return Resposta::erro('Não foi possível gerar sugestões de alimentos.');
        }

        return Resposta::sucesso('Sugestões personalizadas geradas com sucesso.', [
            'tipo_refeicao' => $tipoRefeicao,
            'calorias_objetivo' => $caloriasObjetivo,
            'calorias_diarias' => $caloriasDiarias,
            'distribuicao' => $distribuicao,
            'sugestoes' => $sugestoes
        ]);
    }
}
?>
