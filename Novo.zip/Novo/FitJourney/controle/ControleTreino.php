<?php
require_once '../modelo/Treino.php';
require_once '../modelo/Exercicio.php';
require_once '../modelo/Objetivo.php';
require_once '../modelo/Perfil.php';
require_once '../ajudantes/Resposta.php';

/**
 * Controlador para treinos
 */
class ControleTreino {
    /**
     * Lista treinos do usuário
     */
    public function listar() {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treinos = Treino::buscarPorUsuarioId($usuarioId);
            return new Resposta(true, 'Treinos listados com sucesso', $treinos);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao listar treinos: ' . $e->getMessage());
        }
    }

    /**
     * Busca detalhes de um treino específico
     */
    public function getDetalhes($treinoId) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treino = Treino::buscarPorId($treinoId);
            if (!$treino || $treino->getUsuarioId() != $usuarioId) {
                return new Resposta(false, 'Treino não encontrado');
            }

            $exercicios = $treino->getExercicios();
            $duracaoTotal = $treino->calcularDuracaoTotal();

            $dados = [
                'treino' => [
                    'id' => $treino->getId(),
                    'nome' => $treino->getNome(),
                    'descricao' => $treino->getDescricao(),
                    'tipo' => $treino->getTipo(),
                    'duracao_estimada' => $treino->getDuracaoEstimada(),
                    'duracao_calculada' => $duracaoTotal,
                    'data_criacao' => $treino->getDataCriacao()
                ],
                'exercicios' => $exercicios
            ];

            return new Resposta(true, 'Detalhes do treino obtidos com sucesso', $dados);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao buscar detalhes do treino: ' . $e->getMessage());
        }
    }

    /**
     * Cadastra um novo treino
     */
    public function cadastrar($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            // Validação dos dados
            $nome = trim($dados['nome'] ?? '');
            if (empty($nome)) {
                return new Resposta(false, 'Nome do treino é obrigatório');
            }

            $tipo = $dados['tipo'] ?? 'equilibrado';
            $tiposValidos = ['forca', 'cardio', 'flexibilidade', 'equilibrado'];
            if (!in_array($tipo, $tiposValidos)) {
                return new Resposta(false, 'Tipo de treino inválido');
            }

            $treino = new Treino(
                $usuarioId,
                $nome,
                $dados['descricao'] ?? null,
                $tipo,
                $dados['duracao_estimada'] ?? null
            );

            if ($treino->salvar()) {
                return new Resposta(true, 'Treino cadastrado com sucesso', ['id' => $treino->getId()]);
            } else {
                return new Resposta(false, 'Erro ao salvar treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao cadastrar treino: ' . $e->getMessage());
        }
    }

    /**
     * Edita um treino existente
     */
    public function editar($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treinoId = $dados['treino_id'] ?? null;
            if (!$treinoId) {
                return new Resposta(false, 'ID do treino é obrigatório');
            }

            $treino = Treino::buscarPorId($treinoId);
            if (!$treino || $treino->getUsuarioId() != $usuarioId) {
                return new Resposta(false, 'Treino não encontrado');
            }

            // Atualizar dados
            if (isset($dados['nome'])) {
                $treino->setNome(trim($dados['nome']));
            }
            if (isset($dados['descricao'])) {
                $treino->setDescricao($dados['descricao']);
            }
            if (isset($dados['tipo'])) {
                $tipo = $dados['tipo'];
                $tiposValidos = ['forca', 'cardio', 'flexibilidade', 'equilibrado'];
                if (in_array($tipo, $tiposValidos)) {
                    $treino->setTipo($tipo);
                }
            }
            if (isset($dados['duracao_estimada'])) {
                $treino->setDuracaoEstimada($dados['duracao_estimada']);
            }

            if ($treino->salvar()) {
                return new Resposta(true, 'Treino atualizado com sucesso');
            } else {
                return new Resposta(false, 'Erro ao atualizar treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao editar treino: ' . $e->getMessage());
        }
    }

    /**
     * Exclui um treino
     */
    public function excluir($treinoId) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treino = Treino::buscarPorId($treinoId);
            if (!$treino || $treino->getUsuarioId() != $usuarioId) {
                return new Resposta(false, 'Treino não encontrado');
            }

            if ($treino->excluir()) {
                return new Resposta(true, 'Treino excluído com sucesso');
            } else {
                return new Resposta(false, 'Erro ao excluir treino');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao excluir treino: ' . $e->getMessage());
        }
    }

    /**
     * Adiciona exercício a um treino
     */
    public function adicionarExercicio($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treinoId = $dados['treino_id'] ?? null;
            $exercicioId = $dados['exercicio_id'] ?? null;
            $series = $dados['series'] ?? null;
            $repeticoes = $dados['repeticoes'] ?? null;
            $descanso = $dados['descanso'] ?? null;

            if (!$treinoId || !$exercicioId || !$series || !$repeticoes || !$descanso) {
                return new Resposta(false, 'Todos os campos são obrigatórios');
            }

            $treino = Treino::buscarPorId($treinoId);
            if (!$treino || $treino->getUsuarioId() != $usuarioId) {
                return new Resposta(false, 'Treino não encontrado');
            }

            if ($treino->adicionarExercicio($exercicioId, $series, $repeticoes, $descanso)) {
                return new Resposta(true, 'Exercício adicionado ao treino com sucesso');
            } else {
                return new Resposta(false, 'Erro ao adicionar exercício');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao adicionar exercício: ' . $e->getMessage());
        }
    }

    /**
     * Remove exercício de um treino
     */
    public function removerExercicio($dados) {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            $treinoId = $dados['treino_id'] ?? null;
            $exercicioId = $dados['exercicio_id'] ?? null;

            if (!$treinoId || !$exercicioId) {
                return new Resposta(false, 'IDs são obrigatórios');
            }

            $treino = Treino::buscarPorId($treinoId);
            if (!$treino || $treino->getUsuarioId() != $usuarioId) {
                return new Resposta(false, 'Treino não encontrado');
            }

            if ($treino->removerExercicio($exercicioId)) {
                return new Resposta(true, 'Exercício removido do treino com sucesso');
            } else {
                return new Resposta(false, 'Erro ao remover exercício');
            }
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao remover exercício: ' . $e->getMessage());
        }
    }

    /**
     * Lista todos os exercícios disponíveis
     */
    public function listarExercicios() {
        try {
            $exercicios = Exercicio::buscarTodos();
            return new Resposta(true, 'Exercícios listados com sucesso', $exercicios);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao listar exercícios: ' . $e->getMessage());
        }
    }

    /**
     * Sugere treinos baseado no objetivo do usuário
     */
    public function sugerirTreinos() {
        try {
            $usuarioId = $_SESSION['usuario_id'] ?? null;
            if (!$usuarioId) {
                return new Resposta(false, 'Usuário não autenticado');
            }

            // Buscar objetivo do usuário
            $objetivo = Objetivo::buscarPorUsuarioId($usuarioId);
            if (!$objetivo) {
                return new Resposta(false, 'Usuário não possui objetivo definido');
            }

            // Buscar perfil para nível de atividade
            $perfil = Perfil::buscarPorUsuarioId($usuarioId);
            $nivelAtividade = $perfil ? $perfil->getNivelAtividade() : 'moderado';

            // Buscar exercícios sugeridos
            $exercicios = Exercicio::sugerirPorObjetivo($objetivo->getTipo(), $nivelAtividade);

            // Criar treinos sugeridos baseados nos exercícios
            $treinosSugeridos = $this->criarTreinosSugeridos($exercicios, $objetivo->getTipo());

            return new Resposta(true, 'Treinos sugeridos gerados com sucesso', $treinosSugeridos);
        } catch (Exception $e) {
            return new Resposta(false, 'Erro ao sugerir treinos: ' . $e->getMessage());
        }
    }

    /**
     * Cria treinos sugeridos baseados nos exercícios disponíveis
     */
    private function criarTreinosSugeridos($exercicios, $tipoObjetivo) {
        $treinosSugeridos = [];

        // Agrupar exercícios por grupo muscular
        $exerciciosPorGrupo = [];
        foreach ($exercicios as $exercicio) {
            $grupo = $exercicio->getGrupoMuscular();
            if (!isset($exerciciosPorGrupo[$grupo])) {
                $exerciciosPorGrupo[$grupo] = [];
            }
            $exerciciosPorGrupo[$grupo][] = $exercicio;
        }

        // Criar treinos baseados no tipo de objetivo
        switch ($tipoObjetivo) {
            case 'emagrecimento':
                $treinosSugeridos = $this->criarTreinoEmagrecimento($exerciciosPorGrupo);
                break;
            case 'ganho_massa':
                $treinosSugeridos = $this->criarTreinoGanhoMassa($exerciciosPorGrupo);
                break;
            case 'manutencao':
                $treinosSugeridos = $this->criarTreinoManutencao($exerciciosPorGrupo);
                break;
        }

        return $treinosSugeridos;
    }

    private function criarTreinoEmagrecimento($exerciciosPorGrupo) {
        $treinos = [];

        // Treino A: Cardio + Core
        $treinoA = [
            'nome' => 'Treino Cardio + Core',
            'tipo' => 'cardio',
            'exercicios' => []
        ];

        if (isset($exerciciosPorGrupo['cardio']) && count($exerciciosPorGrupo['cardio']) >= 2) {
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['cardio'][0],
                'series' => 3,
                'repeticoes' => '20-30 min',
                'descanso' => 60
            ];
        }

        if (isset($exerciciosPorGrupo['core']) && count($exerciciosPorGrupo['core']) >= 2) {
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['core'][0],
                'series' => 3,
                'repeticoes' => '15-20',
                'descanso' => 45
            ];
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['core'][1],
                'series' => 3,
                'repeticoes' => '15-20',
                'descanso' => 45
            ];
        }

        if (!empty($treinoA['exercicios'])) {
            $treinos[] = $treinoA;
        }

        // Treino B: HIIT
        $treinoB = [
            'nome' => 'Treino HIIT',
            'tipo' => 'cardio',
            'exercicios' => []
        ];

        if (isset($exerciciosPorGrupo['cardio']) && count($exerciciosPorGrupo['cardio']) >= 3) {
            for ($i = 0; $i < 3; $i++) {
                $treinoB['exercicios'][] = [
                    'exercicio' => $exerciciosPorGrupo['cardio'][$i],
                    'series' => 4,
                    'repeticoes' => '30s sprint',
                    'descanso' => 30
                ];
            }
        }

        if (!empty($treinoB['exercicios'])) {
            $treinos[] = $treinoB;
        }

        return $treinos;
    }

    private function criarTreinoGanhoMassa($exerciciosPorGrupo) {
        $treinos = [];

        // Treino A: Peito + Tríceps
        $treinoA = [
            'nome' => 'Peito + Tríceps',
            'tipo' => 'forca',
            'exercicios' => []
        ];

        if (isset($exerciciosPorGrupo['peito']) && count($exerciciosPorGrupo['peito']) >= 2) {
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['peito'][0],
                'series' => 4,
                'repeticoes' => '8-12',
                'descanso' => 90
            ];
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['peito'][1],
                'series' => 3,
                'repeticoes' => '10-15',
                'descanso' => 75
            ];
        }

        if (isset($exerciciosPorGrupo['bracos']) && count($exerciciosPorGrupo['bracos']) >= 1) {
            $treinoA['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['bracos'][0],
                'series' => 3,
                'repeticoes' => '10-12',
                'descanso' => 75
            ];
        }

        if (!empty($treinoA['exercicios'])) {
            $treinos[] = $treinoA;
        }

        // Treino B: Costas + Bíceps
        $treinoB = [
            'nome' => 'Costas + Bíceps',
            'tipo' => 'forca',
            'exercicios' => []
        ];

        if (isset($exerciciosPorGrupo['costas']) && count($exerciciosPorGrupo['costas']) >= 2) {
            $treinoB['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['costas'][0],
                'series' => 4,
                'repeticoes' => '8-12',
                'descanso' => 90
            ];
            $treinoB['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['costas'][1],
                'series' => 3,
                'repeticoes' => '10-15',
                'descanso' => 75
            ];
        }

        if (isset($exerciciosPorGrupo['bracos']) && count($exerciciosPorGrupo['bracos']) >= 2) {
            $treinoB['exercicios'][] = [
                'exercicio' => $exerciciosPorGrupo['bracos'][1],
                'series' => 3,
                'repeticoes' => '10-12',
                'descanso' => 75
            ];
        }

        if (!empty($treinoB['exercicios'])) {
            $treinos[] = $treinoB;
        }

        return $treinos;
    }

    private function criarTreinoManutencao($exerciciosPorGrupo) {
        $treino = [
            'nome' => 'Treino Equilibrado',
            'tipo' => 'equilibrado',
            'exercicios' => []
        ];

        // Selecionar exercícios de diferentes grupos
        $grupos = ['peito', 'costas', 'pernas', 'ombros', 'bracos'];
        $exerciciosSelecionados = 0;

        foreach ($grupos as $grupo) {
            if (isset($exerciciosPorGrupo[$grupo]) && !empty($exerciciosPorGrupo[$grupo])) {
                $treino['exercicios'][] = [
                    'exercicio' => $exerciciosPorGrupo[$grupo][0],
                    'series' => 3,
                    'repeticoes' => '10-15',
                    'descanso' => 60
                ];
                $exerciciosSelecionados++;
                if ($exerciciosSelecionados >= 5) break;
            }
        }

        return !empty($treino['exercicios']) ? [$treino] : [];
    }
}
?>
