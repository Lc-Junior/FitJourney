<?php
/**
 * Controlador para notificações
 */
class ControleNotificacao {
    /**
     * Lista notificações do usuário
     */
    public function listar() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $notificacoes = Notificacao::buscarPorUsuarioId($usuarioId);
        $dados = [];

        foreach ($notificacoes as $notificacao) {
            $dados[] = [
                'id' => $notificacao->getId(),
                'titulo' => $notificacao->getTitulo(),
                'mensagem' => $notificacao->getMensagem(),
                'tipo' => $notificacao->getTipo(),
                'lida' => $notificacao->getLida(),
                'data_notificacao' => $notificacao->getDataNotificacao()
            ];
        }

        return Resposta::sucesso('Notificações listadas com sucesso.', $dados);
    }

    /**
     * Lista notificações não lidas
     */
    public function listarNaoLidas() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $notificacoes = Notificacao::buscarNaoLidasPorUsuario($usuarioId);
        $dados = [];

        foreach ($notificacoes as $notificacao) {
            $dados[] = [
                'id' => $notificacao->getId(),
                'titulo' => $notificacao->getTitulo(),
                'mensagem' => $notificacao->getMensagem(),
                'tipo' => $notificacao->getTipo(),
                'data_notificacao' => $notificacao->getDataNotificacao()
            ];
        }

        return Resposta::sucesso('Notificações não lidas listadas com sucesso.', $dados);
    }

    /**
     * Marca notificação como lida
     */
    public function marcarComoLida($id) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $notificacao = Notificacao::buscarPorId($id);
        if (!$notificacao || $notificacao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Notificação não encontrada.');
        }

        if ($notificacao->marcarComoLida()) {
            return Resposta::sucesso('Notificação marcada como lida.');
        }

        return Resposta::erro('Erro ao marcar notificação como lida.');
    }

    /**
     * Marca todas as notificações como lidas
     */
    public function marcarTodasComoLidas() {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $pdo = Conexao::getInstancia()->getPDO();
        $stmt = $pdo->prepare("UPDATE notificacoes SET lida = TRUE WHERE usuario_id = ? AND lida = FALSE");
        if ($stmt->execute([$usuarioId])) {
            return Resposta::sucesso('Todas as notificações foram marcadas como lidas.');
        }

        return Resposta::erro('Erro ao marcar notificações como lidas.');
    }

    /**
     * Exclui notificação
     */
    public function excluir($id) {
        $usuarioId = Funcoes::getUsuarioLogadoId();
        if (!$usuarioId) {
            return Resposta::erro('Usuário não logado.');
        }

        $notificacao = Notificacao::buscarPorId($id);
        if (!$notificacao || $notificacao->getUsuarioId() != $usuarioId) {
            return Resposta::erro('Notificação não encontrada.');
        }

        if ($notificacao->excluir()) {
            return Resposta::sucesso('Notificação excluída com sucesso.');
        }

        return Resposta::erro('Erro ao excluir notificação.');
    }

    /**
     * Cria notificação para usuário (usado internamente)
     */
    public function criarNotificacao($usuarioId, $titulo, $mensagem, $tipo = 'lembrete') {
        $notificacao = new Notificacao($usuarioId, $titulo, $mensagem, $tipo);
        return $notificacao->salvar();
    }

    /**
     * Lista todas as notificações (admin)
     */
    public function listarTodas() {
        $notificacoes = Notificacao::listarTodos();
        $dados = [];

        foreach ($notificacoes as $notificacao) {
            $dados[] = [
                'id' => $notificacao->getId(),
                'usuario_id' => $notificacao->getUsuarioId(),
                'titulo' => $notificacao->getTitulo(),
                'mensagem' => $notificacao->getMensagem(),
                'tipo' => $notificacao->getTipo(),
                'lida' => $notificacao->getLida(),
                'data_notificacao' => $notificacao->getDataNotificacao()
            ];
        }

        return Resposta::sucesso('Notificações listadas com sucesso.', $dados);
    }
}
?>
