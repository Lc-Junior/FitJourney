# FitJourney - Sistema de Acompanhamento Físico, Nutricional e Motivacional

## Descrição
FitJourney é um aplicativo web desenvolvido em PHP puro, seguindo a arquitetura MVC (Modelo, Visão, Controle). Ele permite aos usuários acompanhar sua jornada fitness, incluindo gerenciamento de perfis, medidas corporais, objetivos, refeições, conquistas e notificações.

## Funcionalidades Principais
- Cadastro e login de usuários com senha criptografada
- Gerenciamento de perfis (idade, sexo, altura, peso, nível de atividade)
- Registro de medidas corporais (peso, cintura, quadril, peito)
- Definição de objetivos (emagrecimento, manutenção, ganho de massa)
- Cadastro de alimentos e registro de refeições
- Sugestão de dieta baseada no perfil e objetivo
- Sincronização com dispositivos (passos, calorias, tempo de exercício)
- Sistema de gamificação com conquistas automáticas
- Relatórios e exportação de dados
- Notificações e lembretes
- Painel administrativo para CRUD geral e estatísticas
- Privacidade de dados (exportar e excluir conta)

## Estrutura do Projeto
- `/visao`: Camada de apresentação (HTML, CSS)
- `/controle`: Controladores (lógica de negócio)
- `/modelo`: Modelos de dados e DAO
- `/ajudantes`: Classes auxiliares (validação, resposta, funções)

## Requisitos Técnicos
- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Servidor web (XAMPP, Laragon ou similar)

## Instalação
1. Clone ou baixe o projeto para o diretório htdocs do seu servidor web.
2. Importe o arquivo `fitjourney.sql` para o MySQL.
3. Configure a conexão com o banco em `modelo/DAO/conexao.php`.
4. Acesse via navegador: `http://localhost/FitJourney/visao/index.php`

## Uso
- Página inicial: `index.php`
- Login: `paginas/login.php`
- Cadastro: `paginas/cadastro.php`
- Dashboard: `paginas/dashboard.php` (após login)

## Segurança
- Senhas criptografadas com `password_hash`
- Consultas SQL parametrizadas via PDO
- Validação de entrada de dados
- Sessões seguras

## Desenvolvimento
Todo o código está em português, bem comentado e organizado seguindo boas práticas de programação.

## Licença
Este projeto é de uso educacional e pessoal.
