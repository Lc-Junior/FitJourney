<?php
/**
 * Serviço para integração com APIs de nutrição
 */
class ApiNutricao {
    private $apiKey;
    private $apiId;
    private $baseUrl;

    public function __construct() {
        // Nutritionix API credentials (free tier)
        $this->apiKey = '83fc632482633d379264f1cabf563c9d'; // Substitua pela sua chave
        $this->apiId = '984f7f09';   // Substitua pelo seu app ID
        $this->baseUrl = 'https://trackapi.nutritionix.com/v2';
    }

    /**
     * Busca alimentos por termo de pesquisa
     */
    public function buscarAlimentos($termo, $limite = 10) {
        $url = $this->baseUrl . '/search/instant';

        $data = [
            'query' => $termo,
            'detailed' => true,
            'branded' => false,
            'common' => true
        ];

        $headers = [
            'Content-Type: application/json',
            'x-app-id: ' . $this->apiId,
            'x-app-key: ' . $this->apiKey
        ];

        $result = $this->fazerRequisicao($url, 'GET', $data, $headers);

        if ($result && isset($result['common'])) {
            $alimentos = [];
            foreach (array_slice($result['common'], 0, $limite) as $item) {
                $alimentos[] = [
                    'nome' => $item['food_name'],
                    'foto' => $item['photo']['thumb'] ?? null,
                    'serving_unit' => $item['serving_unit'],
                    'serving_qty' => $item['serving_qty']
                ];
            }
            return $alimentos;
        }

        return [];
    }

    /**
     * Obtém informações nutricionais detalhadas de um alimento
     */
    public function obterNutrientes($alimento, $quantidade = 100, $unidade = 'g') {
        $url = $this->baseUrl . '/natural/nutrients';

        $data = [
            'query' => $quantidade . $unidade . ' ' . $alimento
        ];

        $headers = [
            'Content-Type: application/json',
            'x-app-id: ' . $this->apiId,
            'x-app-key: ' . $this->apiKey
        ];

        $result = $this->fazerRequisicao($url, 'POST', $data, $headers);

        if ($result && isset($result['foods']) && !empty($result['foods'])) {
            $food = $result['foods'][0];

            return [
                'nome' => $food['food_name'],
                'calorias' => $food['nf_calories'] ?? 0,
                'proteinas' => $food['nf_protein'] ?? 0,
                'carboidratos' => $food['nf_total_carbohydrate'] ?? 0,
                'gorduras' => $food['nf_total_fat'] ?? 0,
                'fibras' => $food['nf_dietary_fiber'] ?? 0,
                'acucares' => $food['nf_sugars'] ?? 0,
                'sodio' => $food['nf_sodium'] ?? 0,
                'porcao' => $food['serving_weight_grams'] ?? $quantidade,
                'unidade' => $food['serving_unit'] ?? $unidade
            ];
        }

        return null;
    }

    /**
     * Calcula nutrientes para múltiplos alimentos
     */
    public function calcularRefeicao($alimentos) {
        $total = [
            'calorias' => 0,
            'proteinas' => 0,
            'carboidratos' => 0,
            'gorduras' => 0,
            'fibras' => 0,
            'acucares' => 0,
            'sodio' => 0
        ];

        foreach ($alimentos as $alimento) {
            $quantidade = $alimento['quantidade'] ?? 100;
            $unidade = $alimento['unidade'] ?? 'g';

            $nutrientes = $this->obterNutrientes($alimento['nome'], $quantidade, $unidade);

            if ($nutrientes) {
                $total['calorias'] += $nutrientes['calorias'];
                $total['proteinas'] += $nutrientes['proteinas'];
                $total['carboidratos'] += $nutrientes['carboidratos'];
                $total['gorduras'] += $nutrientes['gorduras'];
                $total['fibras'] += $nutrientes['fibras'];
                $total['acucares'] += $nutrientes['acucares'];
                $total['sodio'] += $nutrientes['sodio'];
            }
        }

        return $total;
    }

    /**
     * Faz requisição HTTP para a API
     */
    private function fazerRequisicao($url, $method = 'GET', $data = null, $headers = []) {
        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'GET' && $data) {
            $url .= '?' . http_build_query($data);
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para desenvolvimento
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            error_log("Erro na API de Nutrição: " . $error);
            return null;
        }

        if ($httpCode !== 200) {
            error_log("Erro HTTP na API de Nutrição: " . $httpCode . " - " . $response);
            return null;
        }

        return json_decode($response, true);
    }

    /**
     * Verifica se a API está funcionando
     */
    public function testarConexao() {
        $result = $this->buscarAlimentos('apple', 1);
        return !empty($result);
    }
}
?>
