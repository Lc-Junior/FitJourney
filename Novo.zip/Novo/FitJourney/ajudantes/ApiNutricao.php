<?php
/**
 * Serviço para integração com APIs de nutrição
 */
class ApiNutricao {
    private $apiKey;
    private $apiId;
    private $baseUrl;
    private $spoonacularApiKey;
    private $spoonacularBaseUrl;

    public function __construct() {
        // Nutritionix API credentials (free tier)
        $this->apiKey = '83fc632482633d379264f1cabf563c9d'; // Substitua pela sua chave
        $this->apiId = '984f7f09';   // Substitua pelo seu app ID
        $this->baseUrl = 'https://trackapi.nutritionix.com/v2';

        // Spoonacular API credentials
        $this->spoonacularApiKey = '82054678cd304c63a35f96e01b204270';
        $this->spoonacularBaseUrl = 'https://api.spoonacular.com';
    }

    /**
     * Busca alimentos por termo de pesquisa
     */
    public function buscarAlimentos($termo, $limite = 10) {
        $url = $this->baseUrl . '/search/instant';

        $data = [
            'query' => $termo,
            'detailed' => true,
            'branded' => false,
            'common' => true
        ];

        $headers = [
            'Content-Type: application/json',
            'x-app-id: ' . $this->apiId,
            'x-app-key: ' . $this->apiKey
        ];

        $result = $this->fazerRequisicao($url, 'GET', $data, $headers);

        if ($result && isset($result['common'])) {
            $alimentos = [];
            foreach (array_slice($result['common'], 0, $limite) as $item) {
                $alimentos[] = [
                    'nome' => $item['food_name'],
                    'foto' => $item['photo']['thumb'] ?? null,
                    'serving_unit' => $item['serving_unit'],
                    'serving_qty' => $item['serving_qty']
                ];
            }
            return $alimentos;
        }

        return [];
    }

    /**
     * Obtém informações nutricionais detalhadas de um alimento
     */
    public function obterNutrientes($alimento, $quantidade = 100, $unidade = 'g') {
        $url = $this->baseUrl . '/natural/nutrients';

        $data = [
            'query' => $quantidade . $unidade . ' ' . $alimento
        ];

        $headers = [
            'Content-Type: application/json',
            'x-app-id: ' . $this->apiId,
            'x-app-key' => $this->apiKey
        ];

        $result = $this->fazerRequisicao($url, 'POST', $data, $headers);

        if ($result && isset($result['foods']) && !empty($result['foods'])) {
            $food = $result['foods'][0];

            return [
                'nome' => $food['food_name'],
                'calorias' => $food['nf_calories'] ?? 0,
                'proteinas' => $food['nf_protein'] ?? 0,
                'carboidratos' => $food['nf_total_carbohydrate'] ?? 0,
                'gorduras' => $food['nf_total_fat'] ?? 0,
                'fibras' => $food['nf_dietary_fiber'] ?? 0,
                'acucares' => $food['nf_sugars'] ?? 0,
                'sodio' => $food['nf_sodium'] ?? 0,
                'porcao' => $food['serving_weight_grams'] ?? $quantidade,
                'unidade' => $food['serving_unit'] ?? $unidade
            ];
        }

        return null;
    }

    /**
     * Calcula nutrientes para múltiplos alimentos
     */
    public function calcularRefeicao($alimentos) {
        $total = [
            'calorias' => 0,
            'proteinas' => 0,
            'carboidratos' => 0,
            'gorduras' => 0,
            'fibras' => 0,
            'acucares' => 0,
            'sodio' => 0
        ];

        foreach ($alimentos as $alimento) {
            $quantidade = $alimento['quantidade'] ?? 100;
            $unidade = $alimento['unidade'] ?? 'g';

            $nutrientes = $this->obterNutrientes($alimento['nome'], $quantidade, $unidade);

            if ($nutrientes) {
                $total['calorias'] += $nutrientes['calorias'];
                $total['proteinas'] += $nutrientes['proteinas'];
                $total['carboidratos'] += $nutrientes['carboidratos'];
                $total['gorduras'] += $nutrientes['gorduras'];
                $total['fibras'] += $nutrientes['fibras'];
                $total['acucares'] += $nutrientes['acucares'];
                $total['sodio'] += $nutrientes['sodio'];
            }
        }

        return $total;
    }

    /**
     * Gera sugestões de alimentos para uma refeição usando Spoonacular
     */
    public function sugerirAlimentosRefeicao($tipoRefeicao, $caloriasObjetivo, $macronutrientesObjetivo = null) {
        // Para sugestões de alimentos individuais, vamos usar uma abordagem diferente
        // Busca ingredientes comuns para cada tipo de refeição

        $alimentosPorTipo = [
            'cafe_manha' => ['banana', 'ovo', 'aveia', 'pão', 'iogurte', 'café', 'cereal', 'leite'],
            'almoco' => ['arroz', 'feijão', 'carne', 'frango', 'peixe', 'salada', 'batata', 'macarrão'],
            'jantar' => ['arroz', 'feijão', 'carne', 'frango', 'peixe', 'salada', 'batata', 'macarrão'],
            'lanche' => ['banana', 'maçã', 'nozes', 'iogurte', 'biscoito', 'chocolate', 'suco']
        ];

        $alimentosSugeridos = $alimentosPorTipo[$tipoRefeicao] ?? ['banana', 'ovo', 'pão'];

        $sugestoes = [];
        foreach ($alimentosSugeridos as $alimentoNome) {
            // Busca informações do ingrediente
            $searchUrl = $this->spoonacularBaseUrl . '/food/ingredients/autocomplete';
            $searchParams = [
                'query' => $alimentoNome,
                'number' => 1,
                'metaInformation' => 'true'
            ];

            $searchResponse = $this->fazerRequisicaoSpoonacular($searchUrl, 'GET', $searchParams);

            if (!empty($searchResponse) && isset($searchResponse[0]['id'])) {
                $ingredienteId = $searchResponse[0]['id'];

                // Busca informações nutricionais
                $infoUrl = $this->spoonacularBaseUrl . '/food/ingredients/' . $ingredienteId . '/information';
                $infoParams = [
                    'amount' => 100, // 100g
                    'unit' => 'g'
                ];

                $infoResponse = $this->fazerRequisicaoSpoonacular($infoUrl, 'GET', $infoParams);

                if ($infoResponse && isset($infoResponse['nutrition'])) {
                    $nutricao = $this->extrairNutrientes($infoResponse['nutrition']['nutrients'] ?? []);

                    // Calcula quantidade aproximada para atingir as calorias objetivo
                    $caloriasPor100g = $nutricao['calorias'];
                    if ($caloriasPor100g > 0) {
                        $quantidadeSugerida = ($caloriasObjetivo / $caloriasPor100g) * 100;
                        // Limita a quantidade razoável (máximo 500g para evitar quantidades excessivas)
                        $quantidadeSugerida = min($quantidadeSugerida, 500);
                        $quantidadeSugerida = max($quantidadeSugerida, 10); // mínimo 10g

                        // Recalcula nutrientes com a quantidade sugerida
                        $fator = $quantidadeSugerida / 100;
                        $nutricaoAjustada = [
                            'calorias' => round($nutricao['calorias'] * $fator),
                            'proteinas' => round($nutricao['proteinas'] * $fator, 1),
                            'carboidratos' => round($nutricao['carboidratos'] * $fator, 1),
                            'gorduras' => round($nutricao['gorduras'] * $fator, 1),
                            'fibras' => round($nutricao['fibras'] * $fator, 1),
                            'acucares' => round($nutricao['acucares'] * $fator, 1),
                            'sodio' => round($nutricao['sodio'] * $fator, 1)
                        ];

                        $sugestoes[] = [
                            'titulo' => $infoResponse['name'] ?? $alimentoNome,
                            'imagem' => $infoResponse['image'] ?? '',
                            'quantidade_sugerida' => round($quantidadeSugerida, 1),
                            'unidade' => 'g',
                            'nutricao' => $nutricaoAjustada,
                            'fonte_url' => ''
                        ];
                    }
                }
            }
        }

        // Ordena por calorias mais próximas do objetivo
        usort($sugestoes, function($a, $b) use ($caloriasObjetivo) {
            $diffA = abs($a['nutricao']['calorias'] - $caloriasObjetivo);
            $diffB = abs($b['nutricao']['calorias'] - $caloriasObjetivo);
            return $diffA <=> $diffB;
        });

        // Limita a 6 sugestões
        return array_slice($sugestoes, 0, 6);
    }

    /**
     * Busca informações nutricionais de uma receita específica
     */
    private function obterNutricaoSpoonacular($recipeId) {
        $url = $this->spoonacularBaseUrl . '/recipes/' . $recipeId . '/nutritionWidget.json';

        $result = $this->fazerRequisicaoSpoonacular($url, 'GET', []);

        if ($result) {
            return [
                'calorias' => $result['calories'] ?? 0,
                'proteinas' => $result['protein'] ?? 0,
                'carboidratos' => $result['carbs'] ?? 0,
                'gorduras' => $result['fat'] ?? 0,
                'gorduras_saturadas' => $result['saturatedFat'] ?? 0,
                'fibras' => $result['fiber'] ?? 0,
                'acucares' => $result['sugar'] ?? 0,
                'sodio' => $result['sodium'] ?? 0
            ];
        }

        return null;
    }

    /**
     * Busca alimentos por termo usando Spoonacular
     */
    public function buscarAlimentosSpoonacular($termo, $limite = 10) {
        $url = $this->spoonacularBaseUrl . '/food/ingredients/autocomplete';

        $data = [
            'query' => $termo,
            'number' => $limite,
            'metaInformation' => 'true'
        ];

        $result = $this->fazerRequisicaoSpoonacular($url, 'GET', $data);

        if ($result && is_array($result)) {
            $alimentos = [];
            foreach ($result as $item) {
                $alimentos[] = [
                    'id' => $item['id'] ?? null,
                    'nome' => $item['name'] ?? '',
                    'imagem' => $item['image'] ?? null
                ];
            }
            return $alimentos;
        }

        return [];
    }

    /**
     * Obtém informações nutricionais detalhadas de um ingrediente
     */
    public function obterNutrientesIngrediente($ingredienteId, $quantidade = 100, $unidade = 'g') {
        $url = $this->spoonacularBaseUrl . '/food/ingredients/' . $ingredienteId . '/amount';

        $data = [
            'amount' => $quantidade,
            'unit' => $unidade
        ];

        $result = $this->fazerRequisicaoSpoonacular($url, 'GET', $data);

        if ($result && isset($result['nutrition'])) {
            $nutrients = $result['nutrition'];

            return [
                'nome' => $result['name'] ?? '',
                'calorias' => $this->extrairNutriente($nutrients['nutrients'], 'Calories'),
                'proteinas' => $this->extrairNutriente($nutrients['nutrients'], 'Protein'),
                'carboidratos' => $this->extrairNutriente($nutrients['nutrients'], 'Carbohydrates'),
                'gorduras' => $this->extrairNutriente($nutrients['nutrients'], 'Fat'),
                'fibras' => $this->extrairNutriente($nutrients['nutrients'], 'Fiber'),
                'acucares' => $this->extrairNutriente($nutrients['nutrients'], 'Sugar'),
                'sodio' => $this->extrairNutriente($nutrients['nutrients'], 'Sodium'),
                'porcao' => $quantidade,
                'unidade' => $unidade
            ];
        }

        return null;
    }

    /**
     * Extrai valor de nutriente da resposta da API
     */
    private function extrairNutriente($nutrients, $nome) {
        foreach ($nutrients as $nutrient) {
            if ($nutrient['name'] === $nome) {
                $amount = $nutrient['amount'] ?? 0;
                // Garante que seja numérico, removendo unidades se presentes
                if (is_string($amount)) {
                    $amount = preg_replace('/[^\d.]/', '', $amount);
                }
                return floatval($amount);
            }
        }
        return 0.0;
    }

    /**
     * Extrai nutrientes de uma lista de nutrientes
     */
    private function extrairNutrientes($nutrients) {
        return [
            'calorias' => $this->extrairNutriente($nutrients, 'Calories'),
            'proteinas' => $this->extrairNutriente($nutrients, 'Protein'),
            'carboidratos' => $this->extrairNutriente($nutrients, 'Carbohydrates'),
            'gorduras' => $this->extrairNutriente($nutrients, 'Fat'),
            'fibras' => $this->extrairNutriente($nutrients, 'Fiber'),
            'acucares' => $this->extrairNutriente($nutrients, 'Sugar'),
            'sodio' => $this->extrairNutriente($nutrients, 'Sodium')
        ];
    }

    /**
     * Faz requisição HTTP para a API Spoonacular
     */
    private function fazerRequisicaoSpoonacular($url, $method = 'GET', $data = []) {
        $ch = curl_init();

        // Adiciona chave da API aos parâmetros
        $data['apiKey'] = $this->spoonacularApiKey;

        if ($method === 'GET' && $data) {
            $url .= '?' . http_build_query($data);
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para desenvolvimento
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            error_log("Erro na API Spoonacular: " . $error);
            return null;
        }

        if ($httpCode !== 200) {
            error_log("Erro HTTP na API Spoonacular: " . $httpCode . " - " . $response);
            return null;
        }

        $decoded = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Erro ao decodificar JSON da Spoonacular: " . json_last_error_msg());
            return null;
        }

        return $decoded;
    }

    /**
     * Faz requisição HTTP para a API
     */
    private function fazerRequisicao($url, $method = 'GET', $data = null, $headers = []) {
        $ch = curl_init();

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'GET' && $data) {
            $url .= '?' . http_build_query($data);
        }

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Para desenvolvimento
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);

        curl_close($ch);

        if ($error) {
            error_log("Erro na API de Nutrição: " . $error);
            return null;
        }

        if ($httpCode !== 200) {
            error_log("Erro HTTP na API de Nutrição: " . $httpCode . " - " . $response);
            return null;
        }

        return json_decode($response, true);
    }

    /**
     * Verifica se a API está funcionando
     */
    public function testarConexao() {
        $result = $this->buscarAlimentos('apple', 1);
        return !empty($result);
    }
}
?>
