<?php
/**
 * Funções auxiliares gerais
 */
class Funcoes {
    /**
     * Inicia sessão se não estiver iniciada
     */
    public static function iniciarSessao() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }

    /**
     * Verifica se o usuário está logado
     */
    public static function usuarioLogado() {
        self::iniciarSessao();
        return isset($_SESSION['usuario_id']);
    }

    /**
     * Obtém o ID do usuário logado
     */
    public static function getUsuarioLogadoId() {
        self::iniciarSessao();
        return $_SESSION['usuario_id'] ?? null;
    }

    /**
     * Faz logout do usuário
     */
    public static function logout() {
        self::iniciarSessao();
        session_destroy();
    }

    /**
     * Redireciona para uma página
     */
    public static function redirecionar($url) {
        header("Location: $url");
        exit;
    }

    /**
     * Calcula IMC (Índice de Massa Corporal)
     */
    public static function calcularIMC($peso, $altura) {
        if ($altura > 0) {
            $alturaMetros = $altura / 100;
            return round($peso / ($alturaMetros * $alturaMetros), 2);
        }
        return 0;
    }

    /**
     * Classifica IMC
     */
    public static function classificarIMC($imc) {
        if ($imc < 18.5) return 'Abaixo do peso';
        if ($imc < 25) return 'Peso normal';
        if ($imc < 30) return 'Sobrepeso';
        if ($imc < 35) return 'Obesidade grau 1';
        if ($imc < 40) return 'Obesidade grau 2';
        return 'Obesidade grau 3';
    }

    /**
     * Calcula TMB (Taxa Metabólica Basal) - Fórmula Mifflin-St Jeor
     */
    public static function calcularTMB($peso, $altura, $idade, $sexo) {
        if ($sexo == 'masculino') {
            return 10 * $peso + 6.25 * $altura - 5 * $idade + 5;
        } else {
            return 10 * $peso + 6.25 * $altura - 5 * $idade - 161;
        }
    }

    /**
     * Calcula TDEE (Gasto Energético Total Diário)
     */
    public static function calcularTDEE($tmb, $nivelAtividade) {
        $fatores = [
            'sedentario' => 1.2,
            'leve' => 1.375,
            'moderado' => 1.55,
            'ativo' => 1.725,
            'muito_ativo' => 1.9
        ];
        return $tmb * ($fatores[$nivelAtividade] ?? 1.2);
    }

    /**
     * Calcula calorias para objetivo
     */
    public static function calcularCaloriasObjetivo($tdee, $objetivo) {
        switch ($objetivo) {
            case 'emagrecimento':
                return $tdee - 500; // Deficit de 500 kcal
            case 'ganho_massa':
                return $tdee + 300; // Superávit de 300 kcal
            default:
                return $tdee; // Manutenção
        }
    }

    /**
     * Formata data para exibição
     */
    public static function formatarData($data) {
        return date('d/m/Y', strtotime($data));
    }

    /**
     * Formata hora para exibição
     */
    public static function formatarHora($hora) {
        return date('H:i', strtotime($hora));
    }

    /**
     * Limpa entrada de dados
     */
    public static function limparEntrada($dados) {
        if (is_array($dados)) {
            return array_map('self::limparEntrada', $dados);
        }
        return trim(strip_tags($dados));
    }

    /**
     * Gera hash único
     */
    public static function gerarHash() {
        return md5(uniqid(mt_rand(), true));
    }

    /**
     * Verifica se é uma requisição AJAX
     */
    public static function isAjax() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }

    /**
     * Envia resposta JSON
     */
    public static function enviarJson($dados) {
        header('Content-Type: application/json');
        echo json_encode($dados);
        exit;
    }

    /**
     * Obtém IP do usuário
     */
    public static function getIpUsuario() {
        return $_SERVER['HTTP_CLIENT_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Verifica se o usuário logado é admin
     */
    public static function isAdmin() {
        $usuarioId = self::getUsuarioLogadoId();
        if (!$usuarioId) {
            return false;
        }
        // Assume admin se ID for 1 (primeiro usuário) ou email específico
        $usuario = Usuario::buscarPorId($usuarioId);
        return $usuario && ($usuario->getId() == 1 || $usuario->getEmail() == 'admin@fitjourney.com');
    }
}
?>
