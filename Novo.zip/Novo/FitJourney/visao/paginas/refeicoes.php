<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleRefeicao.php';
require_once '../../controle/ControleAdmin.php';
require_once '../../controle/ControleObjetivo.php';

$titulo = 'Refeições';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleRefeicao = new ControleRefeicao();
$controleAdmin = new ControleAdmin();
$controleObjetivo = new ControleObjetivo();

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'cadastrar_refeicao':
            $resposta = $controleRefeicao->cadastrar(Funcoes::limparEntrada($_POST));
            break;

        case 'adicionar_alimento':
            $resposta = $controleRefeicao->adicionarAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id'],
                $_POST['quantidade']
            );
            break;

        case 'remover_alimento':
            $resposta = $controleRefeicao->removerAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id']
            );
            break;

        case 'editar_alimento':
            $resposta = $controleRefeicao->editarAlimento(
                $_POST['refeicao_id'],
                $_POST['alimento_id'],
                $_POST['quantidade']
            );
            break;

        case 'adicionar_alimento_customizado':
            $resposta = $controleRefeicao->adicionarAlimentoCustomizado(
                $_POST['refeicao_id'],
                $_POST['nome_alimento'],
                $_POST['quantidade'],
                $_POST['unidade'] ?? 'g'
            );
            break;

        case 'excluir_refeicao':
            $resposta = $controleRefeicao->excluir($_POST['refeicao_id']);
            break;

        case 'gerar_sugestoes':
            $resposta = $controleRefeicao->sugerirAlimentosRefeicao(
                $_POST['tipo_refeicao_sugestao'],
                $_POST['calorias_objetivo'],
                isset($_POST['proteinas_objetivo']) ? [
                    'proteinas_g' => $_POST['proteinas_objetivo'],
                    'carboidratos_g' => $_POST['carboidratos_objetivo'] ?? 0,
                    'gorduras_g' => $_POST['gorduras_objetivo'] ?? 0
                ] : null
            );
            if ($resposta->getSucesso()) {
                $_SESSION['sugestoes_refeicao'] = $resposta->getDados();
                $_SESSION['sugestoes_refeicao']['tipo_refeicao'] = $_POST['tipo_refeicao_sugestao'];
                $_SESSION['sugestoes_refeicao']['calorias_objetivo'] = $_POST['calorias_objetivo'];
            }
            break;
    }

    if (isset($resposta)) {
        if ($resposta->getSucesso()) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'success';
        } else {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'error';
        }
    }
}

// Obtém dados
$refeicoesResposta = $controleRefeicao->listar();
$alimentosResposta = $controleAdmin->listarAlimentos();
$dietaResposta = $controleObjetivo->sugerirDieta();

$refeicoes = $refeicoesResposta->getSucesso() ? $refeicoesResposta->getDados() : [];
$alimentos = $alimentosResposta->getSucesso() ? $alimentosResposta->getDados() : [];
$dieta = $dietaResposta->getSucesso() ? $dietaResposta->getDados() : null;

// Verifica se é para mostrar detalhes
$detalhesRefeicao = null;
if (isset($_GET['action']) && $_GET['action'] == 'detalhes' && isset($_GET['id'])) {
    $detalhesResposta = $controleRefeicao->getDetalhes($_GET['id']);
    if ($detalhesResposta->getSucesso()) {
        $detalhesRefeicao = $detalhesResposta->getDados();
    }
}

// Verifica se há sugestões para mostrar
$sugestoesRefeicao = null;
if (isset($_SESSION['sugestoes_refeicao'])) {
    $sugestoesRefeicao = $_SESSION['sugestoes_refeicao'];
    // Não remove da sessão para manter as sugestões persistentes
}

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Gerenciar Refeições</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-refeicao').style.display='block'" class="btn btn-primary">Nova Refeição</button>
    <button onclick="document.getElementById('modal-sugestoes').style.display='block'" class="btn btn-info">Gerar Sugestões</button>
</div>

<?php if ($sugestoesRefeicao): ?>
<div class="card">
    <h2>Sugestões de Alimentos para <?php echo ucfirst(str_replace('_', ' ', $sugestoesRefeicao['tipo_refeicao'])); ?></h2>
    <p><strong>Calorias Objetivo:</strong> <?php echo $sugestoesRefeicao['calorias_objetivo']; ?> kcal</p>

    <?php if (!empty($sugestoesRefeicao['sugestoes'])): ?>
        <div class="sugestoes-grid">
            <?php foreach ($sugestoesRefeicao['sugestoes'] as $sugestao): ?>
                <div class="sugestao-card">
                    <h4><?php echo htmlspecialchars($sugestao['titulo']); ?></h4>
                    <?php if (!empty($sugestao['imagem'])): ?>
                        <img src="<?php echo htmlspecialchars($sugestao['imagem']); ?>" alt="<?php echo htmlspecialchars($sugestao['titulo']); ?>" style="max-width: 200px; height: auto;">
                    <?php endif; ?>
                    <p><strong>Quantidade Sugerida:</strong> <?php echo is_numeric($sugestao['quantidade_sugerida']) ? number_format($sugestao['quantidade_sugerida'], 1) : '0.0'; ?> <?php echo htmlspecialchars($sugestao['unidade'] ?? 'g'); ?></p>

                    <h5>Informações Nutricionais (por 100g):</h5>
                    <ul>
                        <li>Calorias: <?php echo is_numeric($sugestao['nutricao']['calorias']) ? number_format($sugestao['nutricao']['calorias'], 0) : '0'; ?> kcal</li>
                        <li>Proteínas: <?php echo is_numeric($sugestao['nutricao']['proteinas']) ? number_format($sugestao['nutricao']['proteinas'], 1) : '0.0'; ?>g</li>
                        <li>Carboidratos: <?php echo is_numeric($sugestao['nutricao']['carboidratos']) ? number_format($sugestao['nutricao']['carboidratos'], 1) : '0.0'; ?>g</li>
                        <li>Gorduras: <?php echo is_numeric($sugestao['nutricao']['gorduras']) ? number_format($sugestao['nutricao']['gorduras'], 1) : '0.0'; ?>g</li>
                    </ul>

                    <button onclick="adicionarAlimentoSugestao('<?php echo htmlspecialchars($sugestao['titulo']); ?>', <?php echo is_numeric($sugestao['nutricao']['calorias']) ? $sugestao['nutricao']['calorias'] : 0; ?>, <?php echo is_numeric($sugestao['nutricao']['proteinas']) ? $sugestao['nutricao']['proteinas'] : 0; ?>, <?php echo is_numeric($sugestao['nutricao']['carboidratos']) ? $sugestao['nutricao']['carboidratos'] : 0; ?>, <?php echo is_numeric($sugestao['nutricao']['gorduras']) ? $sugestao['nutricao']['gorduras'] : 0; ?>)" class="btn btn-success btn-sm">Adicionar à Refeição</button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Nenhuma sugestão encontrada. Tente ajustar os parâmetros.</p>
    <?php endif; ?>

    <a href="refeicoes.php" class="btn btn-secondary">Voltar</a>
</div>
<?php elseif ($detalhesRefeicao): ?>
<div class="card">
    <h2>Detalhes da Refeição</h2>
    <p><strong>Tipo:</strong> <?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $detalhesRefeicao['refeicao']['tipo'] ?? ''))); ?></p>
    <p><strong>Data:</strong> <?php echo htmlspecialchars(Funcoes::formatarData($detalhesRefeicao['refeicao']['data_refeicao'] ?? '')); ?></p>
    <p><strong>Hora:</strong> <?php echo htmlspecialchars($detalhesRefeicao['refeicao']['hora_refeicao'] ?? ''); ?></p>
    <p><strong>Calorias Totais:</strong> <?php echo htmlspecialchars(number_format($detalhesRefeicao['refeicao']['calorias_totais'] ?? 0, 0)); ?> kcal</p>

    <h3>Alimentos</h3>
    <?php if (!empty($detalhesRefeicao['itens'])): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Alimento</th>
                    <th>Quantidade (g)</th>
                    <th>Calorias</th>
                    <th>Proteínas (g)</th>
                    <th>Carboidratos (g)</th>
                    <th>Gorduras (g)</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detalhesRefeicao['itens'] as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['nome'] ?? ''); ?></td>
                        <td><?php echo ($item['quantidade'] ?? 0); ?>g</td>
                        <td><?php echo number_format(($item['calorias'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 0); ?> kcal</td>
                        <td><?php echo number_format(($item['proteinas'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td><?php echo number_format(($item['carboidratos'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td><?php echo number_format(($item['gorduras'] ?? 0) * ($item['quantidade'] ?? 0) / 100, 1); ?>g</td>
                        <td>
                            <button onclick="editarQuantidade(<?php echo $item['alimento_id'] ?? ''; ?>, <?php echo $item['quantidade'] ?? 0; ?>)" class="btn btn-warning btn-sm">Editar</button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="remover_alimento">
                                <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
                                <input type="hidden" name="alimento_id" value="<?php echo $item['alimento_id'] ?? ''; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Remover este alimento?')">Remover</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum alimento adicionado ainda.</p>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-alimento').style.display='block'" class="btn btn-success">Adicionar Alimento</button>
    <button onclick="document.getElementById('modal-custom').style.display='block'" class="btn btn-info">Buscar Alimento na API</button>
    <a href="refeicoes.php" class="btn btn-secondary">Voltar</a>
</div>
<?php else: ?>
<div class="card">
    <h2>Minhas Refeições</h2>
    <?php if (!empty($refeicoes)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Data</th>
                    <th>Hora</th>
                    <th>Calorias</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($refeicoes as $refeicao): ?>
                    <tr>
                        <td><?php echo ucfirst(str_replace('_', ' ', $refeicao['tipo'])); ?></td>
                        <td><?php echo Funcoes::formatarData($refeicao['data_refeicao']); ?></td>
                        <td><?php echo $refeicao['hora_refeicao']; ?></td>
                        <td><?php echo number_format($refeicao['calorias_totais'], 0); ?> kcal</td>
                        <td>
                            <a href="?action=detalhes&id=<?php echo $refeicao['id']; ?>" class="btn btn-secondary btn-sm">Ver</a>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="excluir_refeicao">
                                <input type="hidden" name="refeicao_id" value="<?php echo $refeicao['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Excluir esta refeição?')">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhuma refeição registrada ainda.</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Modal Nova Refeição -->
<div id="modal-refeicao" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-refeicao').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Nova Refeição</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="cadastrar_refeicao">
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select id="tipo" name="tipo" required>
                    <option value="cafe_manha">Café da Manhã</option>
                    <option value="almoco">Almoço</option>
                    <option value="jantar">Jantar</option>
                    <option value="lanche">Lanche</option>
                </select>
            </div>
            <div class="form-group">
                <label for="data_refeicao">Data:</label>
                <input type="date" id="data_refeicao" name="data_refeicao" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label for="hora_refeicao">Hora:</label>
                <input type="time" id="hora_refeicao" name="hora_refeicao">
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>
</div>

<!-- Modal Gerar Sugestões -->
<div id="modal-sugestoes" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px;">
        <span onclick="document.getElementById('modal-sugestoes').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Gerar Sugestões de Alimentos</h3>
        <p>Use sua dieta sugerida ou personalize os valores:</p>

        <?php if ($dieta): ?>
            <div class="dieta-info" style="background-color: #f0f0f0; padding: 10px; margin-bottom: 15px; border-radius: 5px;">
                <h4>Sua Dieta Sugerida:</h4>
                <p><strong>Calorias Totais:</strong> <?php echo number_format($dieta['calorias_totais'], 0); ?> kcal</p>
                <p><strong>Distribuição por Refeição:</strong></p>
                <ul>
                    <li>Café da Manhã: <?php echo number_format($dieta['distribuicao']['cafe_manha'], 0); ?> kcal</li>
                    <li>Almoço: <?php echo number_format($dieta['distribuicao']['almoco'], 0); ?> kcal</li>
                    <li>Jantar: <?php echo number_format($dieta['distribuicao']['jantar'], 0); ?> kcal</li>
                    <li>Lanches: <?php echo number_format($dieta['distribuicao']['lanches'], 0); ?> kcal</li>
                </ul>
                <p><strong>Macronutrientes por Refeição (aprox.):</strong></p>
                <ul>
                    <li>Proteínas: <?php echo number_format($dieta['macronutrientes']['proteinas_g'] / 4, 0); ?>g</li>
                    <li>Carboidratos: <?php echo number_format($dieta['macronutrientes']['carboidratos_g'] / 4, 0); ?>g</li>
                    <li>Gorduras: <?php echo number_format($dieta['macronutrientes']['gorduras_g'] / 4, 0); ?>g</li>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="acao" value="gerar_sugestoes">
            <div class="form-group">
                <label for="tipo_refeicao_sugestao">Tipo de Refeição:</label>
                <select id="tipo_refeicao_sugestao" name="tipo_refeicao_sugestao" required onchange="preencherCalorias(this.value)">
                    <option value="">Selecione...</option>
                    <option value="cafe_manha">Café da Manhã</option>
                    <option value="almoco">Almoço</option>
                    <option value="jantar">Jantar</option>
                    <option value="lanche">Lanche</option>
                </select>
            </div>
            <div class="form-group">
                <label for="calorias_objetivo">Calorias Objetivo:</label>
                <input type="number" id="calorias_objetivo" name="calorias_objetivo" min="50" max="2000" required>
            </div>
            <div class="form-group">
                <label>Macronutrientes (opcional):</label>
                <div style="display: flex; gap: 10px;">
                    <div>
                        <label for="proteinas_objetivo">Proteínas (g):</label>
                        <input type="number" id="proteinas_objetivo" name="proteinas_objetivo" min="0" step="0.1">
                    </div>
                    <div>
                        <label for="carboidratos_objetivo">Carboidratos (g):</label>
                        <input type="number" id="carboidratos_objetivo" name="carboidratos_objetivo" min="0" step="0.1">
                    </div>
                    <div>
                        <label for="gorduras_objetivo">Gorduras (g):</label>
                        <input type="number" id="gorduras_objetivo" name="gorduras_objetivo" min="0" step="0.1">
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Sugestões</button>
        </form>
    </div>
</div>

<!-- Modal Adicionar Alimento -->
<div id="modal-alimento" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-alimento').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Adicionar Alimento</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_alimento">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <div class="form-group">
                <label for="alimento_id">Alimento:</label>
                <select id="alimento_id" name="alimento_id" required>
                    <?php foreach ($alimentos as $alimento): ?>
                        <option value="<?php echo $alimento['id']; ?>"><?php echo htmlspecialchars($alimento['nome']); ?> (<?php echo $alimento['calorias']; ?> kcal/100g)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="quantidade">Quantidade (gramas):</label>
                <input type="number" id="quantidade" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar</button>
        </form>
    </div>
</div>

<!-- Modal Buscar Alimento na API -->
<div id="modal-custom" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px;">
        <span onclick="document.getElementById('modal-custom').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Buscar Alimento na API</h3>
        <p><small>Exemplo: "80g banana", "50g pão", "200ml leite"</small></p>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_alimento_customizado">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <div class="form-group">
                <label for="nome_alimento">Nome do Alimento:</label>
                <input type="text" id="nome_alimento" name="nome_alimento" placeholder="Ex: banana, pão" required>
            </div>
            <div class="form-group">
                <label for="quantidade_custom">Quantidade (gramas):</label>
                <input type="number" id="quantidade_custom" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <div class="form-group">
                <label for="unidade">Unidade:</label>
                <select id="unidade" name="unidade">
                    <option value="g">Gramas (g)</option>
                    <option value="ml">Mililitros (ml)</option>
                    <option value="oz">Onças (oz)</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Buscar e Adicionar</button>
        </form>
    </div>
</div>

<!-- Modal Editar Quantidade -->
<div id="modal-editar" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-editar').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Editar Quantidade</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="editar_alimento">
            <input type="hidden" name="refeicao_id" value="<?php echo $detalhesRefeicao['refeicao']['id'] ?? ''; ?>">
            <input type="hidden" id="editar_alimento_id" name="alimento_id" value="">
            <div class="form-group">
                <label for="editar_quantidade">Nova Quantidade (gramas):</label>
                <input type="number" id="editar_quantidade" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
</div>

<!-- Modal Adicionar Alimento Sugerido -->
<div id="modal-adicionar-sugerido" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-adicionar-sugerido').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Adicionar Alimento Sugerido</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_alimento_customizado">
            <input type="hidden" id="sugerido_refeicao_id" name="refeicao_id" value="">
            <input type="hidden" id="sugerido_nome" name="nome_alimento" value="">
            <input type="hidden" id="sugerido_calorias" name="calorias" value="">
            <input type="hidden" id="sugerido_proteinas" name="proteinas" value="">
            <input type="hidden" id="sugerido_carboidratos" name="carboidratos" value="">
            <input type="hidden" id="sugerido_gorduras" name="gorduras" value="">
            <div class="form-group">
                <label for="sugerido_quantidade">Quantidade (gramas):</label>
                <input type="number" id="sugerido_quantidade" name="quantidade" step="0.1" min="0.1" required>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar à Refeição</button>
        </form>
    </div>
</div>

<script>
function editarQuantidade(alimentoId, quantidadeAtual) {
    document.getElementById('editar_alimento_id').value = alimentoId;
    document.getElementById('editar_quantidade').value = quantidadeAtual;
    document.getElementById('modal-editar').style.display = 'block';
}

function preencherCalorias(tipo) {
    const dieta = <?php echo json_encode($dieta); ?>;
    const inputCalorias = document.getElementById('calorias_objetivo');

    if (dieta && dieta.distribuicao) {
        const mapeamento = {
            'cafe_manha': dieta.distribuicao.cafe_manha,
            'almoco': dieta.distribuicao.almoco,
            'jantar': dieta.distribuicao.jantar,
            'lanche': dieta.distribuicao.lanches
        };

        if (mapeamento[tipo]) {
            inputCalorias.value = Math.round(mapeamento[tipo]);
        }
    }
}

function adicionarAlimentoSugestao(nome, calorias, proteinas, carboidratos, gorduras) {
    // Primeiro, verificar se há uma refeição ativa ou criar uma nova
    if (confirm('Deseja adicionar "' + nome + '" a uma refeição existente ou criar uma nova?')) {
        // Redirecionar para criar nova refeição ou mostrar lista
        window.location.href = 'refeicoes.php?action=detalhes&id=' + (<?php echo $detalhesRefeicao ? $detalhesRefeicao['refeicao']['id'] : 'null'; ?> || prompt('Digite o ID da refeição:'));
    }
}
</script>

<style>
.sugestoes-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.sugestao-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    background-color: #f9f9f9;
}

.sugestao-card h4 {
    margin-top: 0;
    color: #333;
}

.sugestao-card ul {
    list-style-type: none;
    padding: 0;
}

.sugestao-card li {
    margin-bottom: 5px;
}
</style>

<?php include '../includes/rodape.php'; ?>
