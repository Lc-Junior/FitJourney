<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Medida.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Alimento.php';
require_once '../../modelo/Refeicao.php';
require_once '../../modelo/Conquista.php';
require_once '../../modelo/Notificacao.php';
require_once '../../controle/ControleConquista.php';

$titulo = 'Conquistas';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleConquista = new ControleConquista();

// Obtém dados
$conquistasResposta = $controleConquista->listarPorUsuario();
$xpResposta = $controleConquista->calcularXpTotal();

$conquistas = $conquistasResposta->getSucesso() ? $conquistasResposta->getDados() : [];
$xpTotal = $xpResposta->getSucesso() ? $xpResposta->getDados()['xp_total'] : 0;

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Minhas Conquistas</h2>
    <div class="metric-card" style="margin-bottom: 20px;">
        <h3>XP Total</h3>
        <div class="value"><?php echo $xpTotal; ?></div>
        <p>Pontos de experiência acumulados</p>
    </div>
</div>

<div class="card">
    <h2>Conquistas Disponíveis</h2>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
        <?php foreach ($conquistas as $conquista): ?>
            <div class="achievement-item <?php echo $conquista['desbloqueada'] ? '' : 'locked'; ?>">
                <div class="icon">
                    <?php echo $conquista['desbloqueada'] ? '🏆' : '🔒'; ?>
                </div>
                <div class="info">
                    <h4><?php echo htmlspecialchars($conquista['nome']); ?></h4>
                    <p><?php echo htmlspecialchars($conquista['descricao']); ?></p>
                    <div class="xp">XP: <?php echo $conquista['xp']; ?></div>
                    <?php if ($conquista['desbloqueada']): ?>
                        <div style="color: #5DB075; font-weight: bold; margin-top: 5px;">
                            Desbloqueada em <?php echo Funcoes::formatarData($conquista['data_conquista']); ?>
                        </div>
                    <?php else: ?>
                        <div style="color: #666; margin-top: 5px;">
                            Ainda não desbloqueada
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="card">
    <h2>Como Ganhar XP</h2>
    <ul>
        <li><strong>Complete seu perfil:</strong> Ganhe XP preenchendo todas as informações do seu perfil.</li>
        <li><strong>Registre refeições:</strong> Cada refeição registrada dá pontos de experiência.</li>
        <li><strong>Defina objetivos:</strong> Criar e manter objetivos fitness aumenta seu XP.</li>
        <li><strong>Seja consistente:</strong> Manter uma rotina regular de registros e acompanhamento.</li>
        <li><strong>Alcance metas:</strong> Conquistas especiais por atingir objetivos específicos.</li>
    </ul>
</div>

<?php include '../includes/rodape.php'; ?>
