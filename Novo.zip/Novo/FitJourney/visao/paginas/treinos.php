<?php
require_once '../../modelo/DAO/conexao.php';
require_once '../../ajudantes/Funcoes.php';
require_once '../../ajudantes/Validador.php';
require_once '../../ajudantes/Resposta.php';
require_once '../../modelo/Usuario.php';
require_once '../../modelo/Perfil.php';
require_once '../../modelo/Objetivo.php';
require_once '../../modelo/Treino.php';
require_once '../../modelo/Exercicio.php';
require_once '../../controle/ControleTreino.php';

$titulo = 'Treinos';

// Verifica se está logado
if (!Funcoes::usuarioLogado()) {
    Funcoes::redirecionar('login.php');
}

$controleTreino = new ControleTreino();

$mensagem = '';
$tipoMensagem = '';

// Processa ações
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $acao = $_POST['acao'] ?? '';

    switch ($acao) {
        case 'cadastrar_treino':
            $resposta = $controleTreino->cadastrar(Funcoes::limparEntrada($_POST));
            break;

        case 'editar_treino':
            $resposta = $controleTreino->editar(Funcoes::limparEntrada($_POST));
            break;

        case 'adicionar_exercicio':
            $resposta = $controleTreino->adicionarExercicio(Funcoes::limparEntrada($_POST));
            break;

        case 'remover_exercicio':
            $resposta = $controleTreino->removerExercicio(Funcoes::limparEntrada($_POST));
            break;

        case 'excluir_treino':
            $resposta = $controleTreino->excluir($_POST['treino_id']);
            break;

        case 'gerar_sugestoes':
            $resposta = $controleTreino->sugerirTreinos();
            if ($resposta->getSucesso()) {
                $_SESSION['sugestoes_treino'] = $resposta->getDados();
            }
            break;
    }

    if (isset($resposta)) {
        if ($resposta->getSucesso()) {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'success';
        } else {
            $mensagem = $resposta->getMensagem();
            $tipoMensagem = 'error';
        }
    }
}

// Obtém dados
$treinosResposta = $controleTreino->listar();
$exerciciosResposta = $controleTreino->listarExercicios();

$treinos = $treinosResposta->getSucesso() ? $treinosResposta->getDados() : [];
$exercicios = $exerciciosResposta->getSucesso() ? $exerciciosResposta->getDados() : [];

// Verifica se é para mostrar detalhes
$detalhesTreino = null;
if (isset($_GET['action']) && $_GET['action'] == 'detalhes' && isset($_GET['id'])) {
    $detalhesResposta = $controleTreino->getDetalhes($_GET['id']);
    if ($detalhesResposta->getSucesso()) {
        $detalhesTreino = $detalhesResposta->getDados();
    }
}

// Verifica se há sugestões para mostrar
$sugestoesTreino = null;
if (isset($_SESSION['sugestoes_treino'])) {
    $sugestoesTreino = $_SESSION['sugestoes_treino'];
    // Não remove da sessão para manter as sugestões persistentes
}

include '../includes/cabecalho.php';
?>

<div class="card">
    <h2>Gerenciar Treinos</h2>

    <?php if ($mensagem): ?>
        <div class="alert alert-<?php echo $tipoMensagem; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-treino').style.display='block'" class="btn btn-primary">Novo Treino</button>
    <button onclick="document.getElementById('modal-sugestoes').style.display='block'" class="btn btn-info">Gerar Sugestões</button>
</div>

<?php if ($sugestoesTreino): ?>
<div class="card">
    <h2>Sugestões de Treinos</h2>

    <?php if (!empty($sugestoesTreino)): ?>
        <div class="treinos-sugeridos-grid">
            <?php foreach ($sugestoesTreino as $treinoSugestao): ?>
                <div class="treino-sugerido-card">
                    <h4><?php echo htmlspecialchars($treinoSugestao['nome']); ?></h4>
                    <p><strong>Tipo:</strong> <?php echo ucfirst($treinoSugestao['tipo']); ?></p>

                    <h5>Exercícios Sugeridos:</h5>
                    <ul>
                        <?php foreach ($treinoSugestao['exercicios'] as $exercicio): ?>
                            <li>
                                <strong><?php echo htmlspecialchars($exercicio['exercicio']->getNome()); ?></strong>
                                - <?php echo $exercicio['series']; ?> séries de <?php echo $exercicio['repeticoes']; ?>
                                (descanso: <?php echo $exercicio['descanso']; ?>s)
                                <br><small><?php echo htmlspecialchars($exercicio['exercicio']->getGrupoMuscular()); ?> • <?php echo ucfirst($exercicio['exercicio']->getDificuldade()); ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                    <button onclick="adicionarTreinoSugerido('<?php echo htmlspecialchars($treinoSugestao['nome']); ?>', '<?php echo $treinoSugestao['tipo']; ?>', <?php echo htmlspecialchars(json_encode($treinoSugestao['exercicios'])); ?>)" class="btn btn-success btn-sm">Criar Este Treino</button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>Nenhuma sugestão encontrada. Verifique se você possui um objetivo definido.</p>
    <?php endif; ?>

    <a href="treinos.php" class="btn btn-secondary">Voltar</a>
</div>
<?php elseif ($detalhesTreino): ?>
<div class="card">
    <h2>Detalhes do Treino</h2>
    <p><strong>Nome:</strong> <?php echo htmlspecialchars($detalhesTreino['treino']['nome']); ?></p>
    <p><strong>Tipo:</strong> <?php echo ucfirst($detalhesTreino['treino']['tipo']); ?></p>
    <p><strong>Duração Estimada:</strong> <?php echo $detalhesTreino['treino']['duracao_calculada']; ?> minutos</p>
    <?php if ($detalhesTreino['treino']['descricao']): ?>
        <p><strong>Descrição:</strong> <?php echo htmlspecialchars($detalhesTreino['treino']['descricao']); ?></p>
    <?php endif; ?>

    <h3>Exercícios</h3>
    <?php if (!empty($detalhesTreino['exercicios'])): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Ordem</th>
                    <th>Exercício</th>
                    <th>Grupo Muscular</th>
                    <th>Séries</th>
                    <th>Repetições</th>
                    <th>Descanso (s)</th>
                    <th>Dificuldade</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($detalhesTreino['exercicios'] as $exercicio): ?>
                    <tr>
                        <td><?php echo $exercicio['ordem']; ?></td>
                        <td><?php echo htmlspecialchars($exercicio['nome']); ?></td>
                        <td><?php echo htmlspecialchars($exercicio['grupo_muscular']); ?></td>
                        <td><?php echo $exercicio['series']; ?></td>
                        <td><?php echo $exercicio['repeticoes']; ?></td>
                        <td><?php echo $exercicio['descanso']; ?></td>
                        <td><?php echo ucfirst($exercicio['dificuldade']); ?></td>
                        <td>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="remover_exercicio">
                                <input type="hidden" name="treino_id" value="<?php echo $detalhesTreino['treino']['id']; ?>">
                                <input type="hidden" name="exercicio_id" value="<?php echo $exercicio['exercicio_id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Remover este exercício?')">Remover</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum exercício adicionado ainda.</p>
    <?php endif; ?>

    <button onclick="document.getElementById('modal-adicionar-exercicio').style.display='block'" class="btn btn-success">Adicionar Exercício</button>
    <a href="treinos.php" class="btn btn-secondary">Voltar</a>
</div>
<?php else: ?>
<div class="card">
    <h2>Meus Treinos</h2>
    <?php if (!empty($treinos)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Tipo</th>
                    <th>Duração Estimada</th>
                    <th>Data Criação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($treinos as $treino): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($treino->getNome()); ?></td>
                        <td><?php echo ucfirst($treino->getTipo()); ?></td>
                        <td><?php echo $treino->getDuracaoEstimada() ? $treino->getDuracaoEstimada() . ' min' : 'N/A'; ?></td>
                        <td><?php echo date('d/m/Y', strtotime($treino->getDataCriacao())); ?></td>
                        <td>
                            <a href="?action=detalhes&id=<?php echo $treino->getId(); ?>" class="btn btn-secondary btn-sm">Ver</a>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="acao" value="excluir_treino">
                                <input type="hidden" name="treino_id" value="<?php echo $treino->getId(); ?>">
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Excluir este treino?')">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Nenhum treino cadastrado ainda.</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Modal Novo Treino -->
<div id="modal-treino" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 500px;">
        <span onclick="document.getElementById('modal-treino').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Novo Treino</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="cadastrar_treino">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select id="tipo" name="tipo" required>
                    <option value="forca">Força</option>
                    <option value="cardio">Cardio</option>
                    <option value="flexibilidade">Flexibilidade</option>
                    <option value="equilibrado">Equilibrado</option>
                </select>
            </div>
            <div class="form-group">
                <label for="duracao_estimada">Duração Estimada (minutos):</label>
                <input type="number" id="duracao_estimada" name="duracao_estimada" min="15" max="180">
            </div>
            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <textarea id="descricao" name="descricao" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
        </form>
    </div>
</div>

<!-- Modal Gerar Sugestões -->
<div id="modal-sugestoes" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px;">
        <span onclick="document.getElementById('modal-sugestoes').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Gerar Sugestões de Treinos</h3>
        <p>As sugestões serão baseadas no seu objetivo atual e nível de atividade.</p>

        <form method="POST">
            <input type="hidden" name="acao" value="gerar_sugestoes">
            <button type="submit" class="btn btn-primary">Gerar Sugestões</button>
        </form>
    </div>
</div>

<!-- Modal Adicionar Exercício -->
<div id="modal-adicionar-exercicio" class="modal" style="display: none; position: fixed; z-index: 1; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
    <div style="background-color: #fefefe; margin: 15% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 600px;">
        <span onclick="document.getElementById('modal-adicionar-exercicio').style.display='none'" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
        <h3>Adicionar Exercício</h3>
        <form method="POST">
            <input type="hidden" name="acao" value="adicionar_exercicio">
            <input type="hidden" name="treino_id" value="<?php echo $detalhesTreino['treino']['id'] ?? ''; ?>">
            <div class="form-group">
                <label for="exercicio_id">Exercício:</label>
                <select id="exercicio_id" name="exercicio_id" required>
                    <?php foreach ($exercicios as $exercicio): ?>
                        <option value="<?php echo $exercicio->getId(); ?>">
                            <?php echo htmlspecialchars($exercicio->getNome()); ?>
                            (<?php echo htmlspecialchars($exercicio->getGrupoMuscular()); ?> - <?php echo ucfirst($exercicio->getDificuldade()); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="series">Séries:</label>
                <input type="number" id="series" name="series" min="1" max="10" required>
            </div>
            <div class="form-group">
                <label for="repeticoes">Repetições:</label>
                <input type="text" id="repeticoes" name="repeticoes" placeholder="Ex: 10-12 ou até falha" required>
            </div>
            <div class="form-group">
                <label for="descanso">Descanso (segundos):</label>
                <input type="number" id="descanso" name="descanso" min="15" max="300" required>
            </div>
            <button type="submit" class="btn btn-primary">Adicionar</button>
        </form>
    </div>
</div>

<script>
function adicionarTreinoSugerido(nome, tipo, exercicios) {
    // Criar treino e adicionar exercícios
    fetch('treinos.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'acao=cadastrar_treino&nome=' + encodeURIComponent(nome) + '&tipo=' + tipo
    })
    .then(response => response.text())
    .then(data => {
        // Recarregar página para mostrar o novo treino
        location.reload();
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro ao criar treino sugerido');
    });
}
</script>

<style>
.treinos-sugeridos-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(400px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.treino-sugerido-card {
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px;
    background-color: #f9f9f9;
}

.treino-sugerido-card h4 {
    margin-top: 0;
    color: #333;
}

.treino-sugerido-card ul {
    list-style-type: none;
    padding: 0;
}

.treino-sugerido-card li {
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}
</style>

<?php include '../includes/rodape.php'; ?>
