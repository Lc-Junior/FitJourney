</main>
    <footer>
        <div class="container">
            <p>&copy; 2025 FitJourney - Sistema de Acompanhamento Fitness. Todos os direitos reservados.</p>
        </div>
    </footer>
    <script>
        // Funções JavaScript básicas
        function mostrarMensagem(mensagem, tipo = 'success') {
            const alertDiv = document.createElement('div');
            alertDiv.className = `alert alert-${tipo}`;
            alertDiv.textContent = mensagem;

            const container = document.querySelector('.container');
            container.insertBefore(alertDiv, container.firstChild);

            setTimeout(() => {
                alertDiv.remove();
            }, 5000);
        }

        function confirmarAcao(mensagem) {
            return confirm(mensagem);
        }

        // Remove mensagens após 5 segundos
        document.addEventListener('DOMContentLoaded', function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }, 5000);
            });
        });
    </script>
</body>
</html>
