<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();

// Teste debug da busca de ingrediente com metaInformation
$searchUrl = 'https://api.spoonacular.com/food/ingredients/autocomplete?apiKey=82054678cd304c63a35f96e01b204270&query=banana&number=1&metaInformation=true';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $searchUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "Search response with metaInformation:\n";
echo "HTTP Code: $httpCode\n";
echo "Error: $error\n";
$result = json_decode($response, true);
print_r($result);

if (!empty($result) && isset($result[0]['id'])) {
    $ingredienteId = $result[0]['id'];
    echo "\nIngrediente ID: $ingredienteId\n";

    // Teste da busca de informações nutricionais
    $infoUrl = 'https://api.spoonacular.com/food/ingredients/' . $ingredienteId . '/information?apiKey=82054678cd304c63a35f96e01b204270&amount=100&unit=g';

    $ch2 = curl_init();
    curl_setopt($ch2, CURLOPT_URL, $infoUrl);
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
    $response2 = curl_exec($ch2);
    $httpCode2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
    $error2 = curl_error($ch2);
    curl_close($ch2);

    echo "\nInfo response:\n";
    echo "HTTP Code: $httpCode2\n";
    echo "Error: $error2\n";
    $result2 = json_decode($response2, true);
    print_r($result2);
}
?>
