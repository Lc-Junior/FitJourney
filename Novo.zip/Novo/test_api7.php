<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();

// Teste da sugestão de alimentos para café da manhã com 800 calorias
$sugestoes = $api->sugerirAlimentosRefeicao('cafe_manha', 800);

echo "Sugestões para café da manhã (800 calorias):\n";
print_r($sugestoes);
?>
