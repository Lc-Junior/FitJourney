<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();

// Teste debug da requisição
$url = 'https://api.spoonacular.com/food/ingredients/autocomplete?query=banana&number=3&metaInformation=true&apiKey=82054678cd304c63a35f96e01b204270';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "Direct API call:\n";
echo "HTTP Code: $httpCode\n";
echo "Error: $error\n";
$result_direct = json_decode($response, true);
echo "Result: ";
print_r($result_direct);

echo "\n\nOur method call:\n";
$result_method = $api->buscarAlimentosSpoonacular('banana', 3);
echo "Result: ";
print_r($result_method);

echo "\n\nChecking if result is array: " . (is_array($result_method) ? 'YES' : 'NO') . "\n";
echo "Checking if result_direct is array: " . (is_array($result_direct) ? 'YES' : 'NO') . "\n";

echo "\n\nComparing first item:\n";
echo "Direct: id = " . ($result_direct[0]['id'] ?? 'NULL') . "\n";
echo "Method: id = " . ($result_method[0]['id'] ?? 'NULL') . "\n";
?>
