<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();

// Teste debug da requisição
$url = 'https://api.spoonacular.com/food/ingredients/autocomplete?query=banana&number=3&metaInformation=true&apiKey=82054678cd304c63a35f96e01b204270';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "Direct API call:\n";
echo "HTTP Code: $httpCode\n";
echo "Error: $error\n";
$result_direct = json_decode($response, true);
echo "Result: ";
print_r($result_direct);

echo "\n\nOur method call:\n";
$result_method = $api->buscarAlimentosSpoonacular('banana', 3);
echo "Result: ";
print_r($result_method);

echo "\n\nDebugging our fazerRequisicaoSpoonacular:\n";
$api2 = new ApiNutricao();
$url2 = 'https://api.spoonacular.com/food/ingredients/autocomplete';
$data2 = [
    'query' => 'banana',
    'number' => 3,
    'metaInformation' => true
];

$result_debug = $api2->fazerRequisicaoSpoonacular($url2, 'GET', $data2);
echo "Debug result: ";
print_r($result_debug);
?>
