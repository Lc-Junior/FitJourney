<?php
require_once('FitJourney/ajudantes/ApiNutricao.php');

$api = new ApiNutricao();
$result = $api->sugerirAlimentosRefeicao('cafe_manha', 800);
print_r($result);
?>
