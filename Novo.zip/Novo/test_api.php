<?php
require_once 'FitJourney/ajudantes/ApiNutricao.php';

$api = new ApiNutricao();
$result = $api->sugerirAlimentosRefeicao('cafe_manha', 800);

echo "Resultado da API:\n";
print_r($result);
?>
